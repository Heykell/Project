<?php
namespace Yay_Currency\Engine;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\ExchangeRateAPIHelper;

defined( 'ABSPATH' ) || exit;

class Ajax {
	use SingletonTrait;

	public $exchange_rate_api;
	private $converted_currencies = array();
	protected function __construct() {

		add_action( 'wp_ajax_yayCurrency_get_all_data', array( $this, 'get_all_data' ) );
		add_action( 'wp_ajax_yayCurrency_set_all_data', array( $this, 'set_all_data' ) );
		add_action( 'wp_ajax_yayCurrency_update_exchange_rate', array( $this, 'update_exchange_rate' ) );
		add_action( 'wp_ajax_yayCurrency_delete_currency', array( $this, 'delete_currency' ) );

	}

	public function get_all_data() {
		check_ajax_referer( 'yay-currency-nonce', 'nonce', true );
		$currency_manage_tab_data = $this->get_currency_manage_tab_data();
		wp_send_json(
			apply_filters(
				'yay_currency_wpml_polylang_compatible',
				array(
					'list_countries'           => WC()->countries->countries,
					'woo_current_settings'     => Helper::get_woo_current_settings(),
					'currency_manage_tab_data' => $currency_manage_tab_data,
				)
			)
		);
	}

	public function set_all_data() {
		check_ajax_referer( 'yay-currency-nonce', 'nonce', true );
		if ( isset( $_POST['data'] ) ) {
			$all_currencies_settings_data = Helper::sanitize( $_POST );
			$this->set_currency_manage_settings( $all_currencies_settings_data['currencies'] );
			$this->set_checkout_options_settings( $all_currencies_settings_data );
			$this->set_display_options_settings( $all_currencies_settings_data );
			$this->set_settings( $all_currencies_settings_data );
			\WC_Cache_Helper::get_transient_version( 'product', true ); // Update product price (currency) after change value.
		}
		$this->get_all_data();
	}

	public function update_exchange_rate() {
		check_ajax_referer( 'yay-currency-nonce', 'nonce', true );
		if ( isset( $_POST['data'] ) ) {
			$currency_object = Helper::sanitize( $_POST );
			$exchange_rate   = array();
			try {
				if ( 'all' === $currency_object['type'] ) {
					$currencies       = $currency_object['currencies'];
					$default_currency = get_option( 'woocommerce_currency' );
					foreach ( $currencies as $currency ) {
						if ( $default_currency !== $currency ) {
							if ( '' === $currency ) {
								array_push( $exchange_rate, 'N/A' );
							} else {
								$currency_params_template = array(
									'$src'  => get_option( 'woocommerce_currency' ),
									'$dest' => $currency,
								);
								$json_data                = ExchangeRateAPIHelper::get_exchange_rates( $currency_params_template );
								if ( 200 !== $json_data['response']['code'] ) {
									array_push( $exchange_rate, 'N/A' );
									continue;
								}
								$decoded_json_data = json_decode( $json_data['body'] );
								if ( isset( $decoded_json_data->chart->result[0]->indicators->quote[0]->close ) ) {
									array_push( $exchange_rate, $decoded_json_data->chart->result[0]->indicators->quote[0]->close[0] );
								} else {
									array_push( $exchange_rate, $decoded_json_data->chart->result[0]->meta->previousClose );
								}
							}
						} else {
							array_push( $exchange_rate, 1 );
						}
					}
					wp_send_json_success(
						array(
							'success'      => true,
							'exchangeRate' => $exchange_rate,
						)
					);
				}
				$currency_params_template = array(
					'$src'  => $currency_object['srcCurrency'],
					'$dest' => $currency_object['destCurrency'],
				);
				$json_data                = ExchangeRateAPIHelper::get_exchange_rates( $currency_params_template );
				if ( 200 !== $json_data['response']['code'] ) {
					wp_send_json_error();
				}
				$decoded_json_data = json_decode( $json_data['body'] );
				if ( isset( $decoded_json_data->chart->result[0]->indicators->quote[0]->close ) ) {
					$exchange_rate = $decoded_json_data->chart->result[0]->indicators->quote[0]->close[0];
				} else {
					$exchange_rate = $decoded_json_data->chart->result[0]->meta->previousClose;
				}
				wp_send_json_success(
					array(
						'exchangeRate' => $exchange_rate,
					)
				);
			} catch ( \Exception $e ) {
				wp_send_json_error( $e );
			}
		}
	}

	public function get_currency_manage_tab_data() {
		$converted_currencies = array();
		$currencies           = Helper::get_currencies_post_type();
		if ( $currencies ) {
			$converted_currencies = Helper::converted_currencies( $currencies );
		} else {
			$default_currency = Helper::get_default_currency();
			array_push( $converted_currencies, $default_currency );
		}

		$default_fallback_currency      = isset( $converted_currencies[0]['default'] ) ? ( isset( $converted_currencies[1]['currency'] ) ? $converted_currencies[1]['currency'] : $converted_currencies[0]['currency'] ) : $converted_currencies[0]['currency'];
		$time_update_exchange_rate_auto = get_option( 'yay_currency_time_update_exchange_rate_auto', 0 );
		$paymentMethodsOptions          = array();

		$installed_payment_methods = WC()->payment_gateways->get_available_payment_gateways();
		foreach ( $installed_payment_methods as $key => $value ) {
			$paymentMethodsOptions[ $key ] = $value->title;
		}
		return array(
			'isCheckoutDifferentCurrency'         => get_option( 'yay_currency_checkout_different_currency', 0 ),
			'checkoutFallbackCurrency'            => get_option( 'yay_currency_checkout_fallback_currency', $default_fallback_currency ),
			'isSetFixedPrice'                     => get_option( 'yay_currency_set_fixed_price', 0 ),
			'isUpdateExchangeRateAuto'            => get_option( 'yay_currency_update_exchange_rate_auto', 0 ),
			'isShowOnSingleProductPage'           => get_option( 'yay_currency_show_single_product_page', 1 ),
			'switcherPositionOnSingleProductPage' => get_option( 'yay_currency_switcher_position_on_single_product_page', 'after_description' ),
			'isShowFlagInSwitcher'                => get_option( 'yay_currency_show_flag_in_switcher', 1 ),
			'isShowCurrencyNameInSwitcher'        => get_option( 'yay_currency_show_currency_name_in_switcher', 1 ),
			'isShowCurrencySymbolInSwitcher'      => get_option( 'yay_currency_show_currency_symbol_in_switcher', 1 ),
			'isShowCurrencyCodeInSwitcher'        => get_option( 'yay_currency_show_currency_code_in_switcher', 1 ),
			'switcherSize'                        => get_option( 'yay_currency_switcher_size', 'medium' ),
			'currencyUnitType'                    => get_option( 'yay_currency_currency_unit_type', 'symbol' ),
			'isAutoSelectCurrencyByCountries'     => get_option( 'yay_currency_auto_select_currency_by_countries', 0 ),
			'isWPMLCompatible'                    => get_option( 'yay_currency_wpml_compatible', 0 ),
			'isPolylangCompatible'                => get_option( 'yay_currency_polylang_compatible', 0 ),
			'timeUpdateExchangeRateAuto'          => $time_update_exchange_rate_auto ? maybe_unserialize( $time_update_exchange_rate_auto ) : array(
				'value' => '30',
				'type'  => 'mins',
			),
			'showNotice'                          => get_option( 'yay_currency_setting_show_notice', 0 ),
			'noticeText'                          => get_option(
				'yay_currency_setting_notice_text',
				'You are from %current-country%, price will be in %current-currency% (%current-currency-symbol%).'
			),
			'currencies'                          => $converted_currencies,
			'paymentMethods'                      => $paymentMethodsOptions,
		);

	}

	public function set_currency_manage_settings( $currencies ) {
		$currencies_array = Helper::sanitize_array( $currencies );
		foreach ( $currencies_array as $key => $currency ) {
			if ( isset( $currency['ID'] ) ) {
				$update_currency = array(
					'ID'         => $currency['ID'],
					'post_title' => $currency['currency'],
					'menu_order' => $key,
				);
				wp_update_post( $update_currency );
				Helper::update_post_meta_currency( $currency['ID'], $currency );
			} else {
				$new_currency    = array(
					'post_title'  => $currency['currency'],
					'post_type'   => Helper::get_post_type(),
					'post_status' => 'publish',
					'menu_order'  => $key,
				);
				$new_currency_ID = wp_insert_post( $new_currency );
				if ( ! is_wp_error( $new_currency_ID ) ) {
					Helper::update_post_meta_currency( $new_currency_ID, $currency );
				}
			}
		}
	}

	public function set_checkout_options_settings( $all_currencies_settings_data ) {
		$currencies_array               = Helper::sanitize_array( $all_currencies_settings_data['currencies'] );
		$is_checkout_different_currency = sanitize_text_field( $all_currencies_settings_data['isCheckoutDifferentCurrency'] ) === '1' ? 1 : 0;
		$checkout_fallback_currency     = sanitize_text_field( $all_currencies_settings_data['checkoutFallbackCurrency'] );
		update_option( 'yay_currency_checkout_different_currency', $is_checkout_different_currency );
		update_option( 'yay_currency_checkout_fallback_currency', $checkout_fallback_currency );
		foreach ( $currencies_array as $currency ) {
			if ( isset( $currency['ID'] ) ) {
				update_post_meta( $currency['ID'], 'status', '1' === $currency['status'] ? 1 : 0 );
				update_post_meta( $currency['ID'], 'payment_methods', $currency['paymentMethods'] );
			}
		}
	}

	public function set_display_options_settings( $all_currencies_settings_data ) {
		$is_show_on_single_product_page           = sanitize_text_field( $all_currencies_settings_data['isShowOnSingleProductPage'] ) === '1' ? 1 : 0;
		$switcher_position_on_single_product_page = sanitize_text_field( $all_currencies_settings_data['switcherPositionOnSingleProductPage'] );
		$is_show_flag_in_switcher                 = sanitize_text_field( $all_currencies_settings_data['isShowFlagInSwitcher'] ) === '1' ? 1 : 0;
		$is_show_currency_name_in_switcher        = sanitize_text_field( $all_currencies_settings_data['isShowCurrencyNameInSwitcher'] ) === '1' ? 1 : 0;
		$is_show_currency_symbol_in_switcher      = sanitize_text_field( $all_currencies_settings_data['isShowCurrencySymbolInSwitcher'] ) === '1' ? 1 : 0;
		$is_show_currency_code_in_switcher        = sanitize_text_field( $all_currencies_settings_data['isShowCurrencyCodeInSwitcher'] ) === '1' ? 1 : 0;
		$switcher_size                            = sanitize_text_field( $all_currencies_settings_data['switcherSize'] );
		$currency_unit_type                       = sanitize_text_field( $all_currencies_settings_data['currencyUnitType'] );

		update_option( 'yay_currency_show_single_product_page', $is_show_on_single_product_page );
		update_option( 'yay_currency_switcher_position_on_single_product_page', $switcher_position_on_single_product_page );
		update_option( 'yay_currency_show_flag_in_switcher', $is_show_flag_in_switcher );
		update_option( 'yay_currency_show_currency_name_in_switcher', $is_show_currency_name_in_switcher );
		update_option( 'yay_currency_show_currency_symbol_in_switcher', $is_show_currency_symbol_in_switcher );
		update_option( 'yay_currency_show_currency_code_in_switcher', $is_show_currency_code_in_switcher );
		update_option( 'yay_currency_switcher_size', $switcher_size );
		update_option( 'yay_currency_currency_unit_type', $currency_unit_type );
	}

	public function set_settings( $all_currencies_settings_data ) {
		$currencies_array                     = Helper::sanitize_array( $all_currencies_settings_data['currencies'] );
		$is_auto_select_currency_by_countries = sanitize_text_field( $all_currencies_settings_data['isAutoSelectCurrencyByCountries'] );
		$is_update_exchange_rate_auto         = sanitize_text_field( $all_currencies_settings_data['isUpdateExchangeRateAuto'] );
		$is_set_fixed_price                   = sanitize_text_field( $all_currencies_settings_data['isSetFixedPrice'] );
		$is_wpml_compatible                   = sanitize_text_field( $all_currencies_settings_data['isWPMLCompatible'] );
		$is_polylang_compatible               = sanitize_text_field( $all_currencies_settings_data['isPolylangCompatible'] );
		$time_update_exchange_rate_auto       = maybe_serialize( $all_currencies_settings_data['timeUpdateExchangeRateAuto'] );
		$is_show_notice                       = sanitize_text_field( $all_currencies_settings_data['showNotice'] );
		$notice_text                          = wp_kses_post( $all_currencies_settings_data['noticeText'] );
		$currencies_by_languages_wpml         = isset( $all_currencies_settings_data['listCurrentWpmlLanguages'] ) ? Helper::sanitize_array( $all_currencies_settings_data['listCurrentWpmlLanguages'] ) : array();
		$currencies_by_languages_polylang     = isset( $all_currencies_settings_data['listCurrentPolylangLanguages'] ) ? Helper::sanitize_array( $all_currencies_settings_data['listCurrentPolylangLanguages'] ) : array();
		update_option( 'yay_currency_auto_select_currency_by_countries', $is_auto_select_currency_by_countries );
		update_option( 'yay_currency_set_fixed_price', $is_set_fixed_price );
		update_option( 'yay_currency_update_exchange_rate_auto', $is_update_exchange_rate_auto );
		update_option( 'yay_currency_time_update_exchange_rate_auto', $time_update_exchange_rate_auto );
		if ( 'false' === $is_show_notice ) {
			delete_option( 'yay_currency_setting_show_notice' );
		} else {
			update_option( 'yay_currency_setting_show_notice', $is_show_notice );
		}
		update_option( 'yay_currency_setting_notice_text', $notice_text );
		update_option( 'yay_currency_wpml_compatible', $is_wpml_compatible );
		update_option( 'yay_currency_polylang_compatible', $is_polylang_compatible );
		update_option( 'yay_currency_currencies_by_languages_wpml', $currencies_by_languages_wpml );
		update_option( 'yay_currency_currencies_by_languages_polylang', $currencies_by_languages_polylang );
		foreach ( $currencies_array as $currency ) {
			if ( isset( $currency['ID'] ) ) {
				update_post_meta( $currency['ID'], 'countries', $currency['countries'] );
			}
		}
	}

	public function delete_currency() {
		check_ajax_referer( 'yay-currency-nonce', 'nonce', true );
		if ( isset( $_POST['data'] ) ) {
			$currency_ID = isset( $_POST['data']['ID'] ) ? sanitize_text_field( $_POST['data']['ID'] ) : false;
			if ( ! $currency_ID ) {
				$currency_code = isset( $_POST['data']['currency'] ) ? sanitize_text_field( $_POST['data']['currency'] ) : false;
				$currency_data = YayCurrencyHelper::get_currency_by_currency_code( $currency_code );
				$currency_ID   = $currency_data ? $currency_data['ID'] : false;
			}
			$is_deleted = $currency_ID ? wp_delete_post( $currency_ID ) : false;
			wp_send_json(
				array(
					'status' => $is_deleted,
				)
			);
		}
	}

}
