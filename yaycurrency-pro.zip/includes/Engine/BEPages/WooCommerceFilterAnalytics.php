<?php
namespace Yay_Currency\Engine\BEPages;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

use \Automattic\WooCommerce\Admin\API\Reports\Categories\DataStore as CategoriesDataStore;
use \Automattic\WooCommerce\Admin\API\Reports\Coupons\DataStore as CouponsDataStore;
use \Automattic\WooCommerce\Admin\API\Reports\Customers\DataStore as CustomersDataStore;
use \Automattic\WooCommerce\Admin\API\Reports\Products\DataStore as ProductsDataStore;

defined( 'ABSPATH' ) || exit;

class WooCommerceFilterAnalytics {

	use SingletonTrait;

	public $default_currency;
	private $converted_currency;
	public function __construct() {
		add_action( 'init', array( $this, 'add_currencies_dropdown_filter' ) );
	}

	public function add_currencies_dropdown_filter() {

		$this->default_currency   = get_option( 'woocommerce_currency' );
		$this->converted_currency = YayCurrencyHelper::converted_currency();

		add_filter( 'woocommerce_analytics_report_should_use_cache', array( $this, 'woocommerce_analytics_report_should_use_cache' ), 20, 2 );

		// args
		$query_args = Helper::analytics_query_args();
		foreach ( $query_args as $field ) {
			add_filter( 'woocommerce_analytics_' . $field . '_query_args', array( $this, 'filter_stats_by_currency' ) );
		}
		$subquery_args = Helper::analytics_subquery_args();
		foreach ( $subquery_args as  $field ) {
			// join
			add_filter( 'woocommerce_analytics_clauses_join_' . $field . '_subquery', array( $this, 'concat_join_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_join_' . $field . '_stats_total', array( $this, 'concat_join_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_join_' . $field . '_stats_interval', array( $this, 'concat_join_subquery' ) );
			// where
			add_filter( 'woocommerce_analytics_clauses_where_' . $field . '_subquery', array( $this, 'concat_where_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_where_' . $field . '_stats_total', array( $this, 'concat_where_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_where_' . $field . '_stats_interval', array( $this, 'concat_where_subquery' ) );
			// select
			add_filter( 'woocommerce_analytics_clauses_select_' . $field . '_subquery', array( $this, 'concat_select_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_select_' . $field . '_stats_total', array( $this, 'concat_select_subquery' ) );
			add_filter( 'woocommerce_analytics_clauses_select_' . $field . '_stats_interval', array( $this, 'concat_select_subquery' ) );
		}
		// OVERVIEW ANALYTICS
		add_filter( 'woocommerce_leaderboards', array( $this, 'custom_leaderboards_analytics' ), 20, 5 );
		// PRODUCTS ANALYTICS
		add_filter( 'woocommerce_analytics_products_select_query', array( $this, 'woocommerce_analytics_products_select_query' ), 20, 2 );
		add_filter( 'woocommerce_analytics_products_stats_select_query', array( $this, 'woocommerce_analytics_products_stats_select_query' ), 20, 2 );
		// REVENUE ANALYTICS
		add_filter( 'woocommerce_analytics_revenue_select_query', array( $this, 'woocommerce_analytics_revenue_select_query' ), 20, 2 );
		// ORDERS ANALYTICS
		add_filter( 'woocommerce_analytics_orders_select_query', array( $this, 'woocommerce_analytics_orders_select_query' ), 20, 2 );
		add_filter( 'woocommerce_analytics_orders_stats_select_query', array( $this, 'woocommerce_analytics_orders_stats_select_query' ), 20, 2 );
		// VARIATIONS ANALYTICS
		add_filter( 'woocommerce_analytics_variations_stats_select_query', array( $this, 'woocommerce_analytics_variations_stats_select_query' ), 20, 2 );
		add_filter( 'woocommerce_analytics_variations_select_query', array( $this, 'woocommerce_analytics_variations_select_query' ), 20, 2 );
		// CATEGORIES ANALYTICS
		add_filter( 'woocommerce_analytics_categories_select_query', array( $this, 'woocommerce_analytics_categories_select_query' ), 20, 2 );
		// COUPONS ANALYTICS
		add_filter( 'woocommerce_analytics_coupons_select_query', array( $this, 'woocommerce_analytics_coupons_select_query' ), 20, 2 );
		// TAXES ANALYTICS
		add_filter( 'woocommerce_analytics_taxes_stats_select_query', array( $this, 'woocommerce_analytics_taxes_stats_select_query' ), 20, 2 );
		add_filter( 'woocommerce_analytics_taxes_select_query', array( $this, 'woocommerce_analytics_taxes_select_query' ), 20, 2 );

		if ( is_admin() ) {
			$converted_currencies = Helper::analytics_currencies();
			wp_enqueue_script( 'yay-currency-analytics', YAY_CURRENCY_PLUGIN_URL . 'src/analytics.js', array(), YAY_CURRENCY_VERSION, true );
			wp_localize_script(
				'yay-currency-analytics',
				'yayCurrencyAnalytics',
				array(
					'defaultCurrency' => 'all_currency',
					'currencies'      => $converted_currencies,
				)
			);
			$data_registry = \Automattic\WooCommerce\Blocks\Package::container()->get( \Automattic\WooCommerce\Blocks\Assets\AssetDataRegistry::class );
			$data_registry->add( 'multiCurrency', Helper::analytics_dropdown_currencies( $converted_currencies ) );
		}
	}

	public function woocommerce_analytics_report_should_use_cache( $flag, $cache_key ) {
		$flag = false;
		return $flag;
	}

	public function filter_stats_by_currency( $args ) {
		if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
			$currency = $this->default_currency;

			if ( isset( $_GET['currency'] ) ) {
				$currency = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
			}
			$args['currency'] = $currency;
		}

		return $args;
	}

	public function concat_join_subquery( $clauses ) {
		if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
			global $wpdb;
			$clauses[] = "JOIN {$wpdb->postmeta} currency_postmeta ON {$wpdb->prefix}wc_order_stats.order_id = currency_postmeta.post_id";
		}
		return $clauses;
	}

	public function concat_where_subquery( $clauses ) {
		if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
			global $wpdb;
			$currency = $this->default_currency;
			$pattern  = '/^[a-zA-Z]{3}+$/';
			if ( ! empty( $_GET['currency'] ) ) {
				$currency = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
			}
			if ( preg_match( $pattern, $currency ) ) {
				$clauses[] = $wpdb->prepare( "AND currency_postmeta.meta_key = '_order_currency' AND currency_postmeta.meta_value = %s", $currency );
			}
		}
		return $clauses;
	}

	public function concat_select_subquery( $clauses ) {
		if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
			$currency = $this->default_currency;
			if ( isset( $_GET['currency'] ) ) {
				$currency = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
			}
			$clauses[] = ', currency_postmeta.meta_value AS currency';
		}
		return $clauses;
	}

	public function get_excluded_statuses() {
		$excluded_statuses = \WC_Admin_Settings::get_option( 'woocommerce_excluded_report_order_statuses', array( 'pending', 'failed', 'cancelled' ) );
		$excluded_statuses = array_merge( array( 'auto-draft', 'trash' ), array_map( 'esc_sql', $excluded_statuses ) );
		$excluded_statuses = preg_filter( '/^/', 'wc-', $excluded_statuses );
		return $excluded_statuses;
	}


	public function prepare_excluded_statuses() {
		$excluded_statuses = $this->get_excluded_statuses();

		return implode(
			',',
			array_map(
				function ( $value ) {
					global $wpdb;
					return $wpdb->prepare( '%s', $value );
				},
				$excluded_statuses
			)
		);

	}

	public function get_order_product_lookup_results( $args, $type = false ) {
		global $wpdb;

		$before_date       = isset( $args['before'] ) ? get_gmt_from_date( $args['before'], 'Y-m-d H:i:s' ) : '';
		$after_date        = isset( $args['after'] ) ? get_gmt_from_date( $args['after'], 'Y-m-d H:i:s' ) : '';
		$excluded_statuses = $this->prepare_excluded_statuses();
		$date_type         = ! $type ? 'date_created' : get_option( 'woocommerce_date_type', 'date_paid' );
		switch ( $date_type ) {
			case 'date_created':
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT `table_name`.*
					FROM {$wpdb->prefix}wc_order_product_lookup as `table_name`
					JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
					WHERE `order_table`.`status` NOT IN (%s) 
					AND `order_table`.`date_created` >= %s 
					AND `order_table`.`date_created` <= %s",
						$excluded_statuses,
						$after_date,
						$before_date
					),
					ARRAY_A
				);
				break;
			case 'date_paid':
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT `table_name`.*
					FROM {$wpdb->prefix}wc_order_product_lookup as `table_name`
					JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
					WHERE `order_table`.`status` NOT IN (%s) 
					AND `order_table`.`date_paid` >= %s 
					AND `order_table`.`date_paid` <= %s",
						$excluded_statuses,
						$after_date,
						$before_date
					),
					ARRAY_A
				);
				break;
			case 'date_completed':
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT `table_name`.*
					FROM {$wpdb->prefix}wc_order_product_lookup as `table_name`
					JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
					WHERE `order_table`.`status` NOT IN (%s) 
					AND `order_table`.`date_completed` >= %s 
					AND `order_table`.`date_completed` <= %s",
						$excluded_statuses,
						$after_date,
						$before_date
					),
					ARRAY_A
				);
				break;
			default:
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT `table_name`.*
				FROM {$wpdb->prefix}wc_order_product_lookup as `table_name`
				JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
				WHERE `order_table`.`status` NOT IN (%s) 
				AND `order_table`.`date_created` >= %s 
				AND `order_table`.`date_created` <= %s",
						$excluded_statuses,
						$after_date,
						$before_date
					),
					ARRAY_A
				);
				break;
		}

		return $results;
	}

	public function get_order_coupon_lookup_results( $args ) {
		global $wpdb;
		$before_date       = isset( $args['before'] ) ? get_gmt_from_date( $args['before'], 'Y-m-d H:i:s' ) : '';
		$after_date        = isset( $args['after'] ) ? get_gmt_from_date( $args['after'], 'Y-m-d H:i:s' ) : '';
		$excluded_statuses = $this->prepare_excluded_statuses();

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT `table_name`.*
			FROM {$wpdb->prefix}wc_order_coupon_lookup as `table_name`
			JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
			WHERE `order_table`.`status` NOT IN ( %s )
			  AND `order_table`.`date_created` >= %s
			  AND `order_table`.`date_created` <= %s",
				$excluded_statuses,
				$after_date,
				$before_date
			),
			ARRAY_A
		);
		return $results;
	}

	public function get_order_tax_lookup_results( $args ) {
		global $wpdb;
		$before_date       = isset( $args['before'] ) ? get_gmt_from_date( $args['before'], 'Y-m-d H:i:s' ) : '';
		$after_date        = isset( $args['after'] ) ? get_gmt_from_date( $args['after'], 'Y-m-d H:i:s' ) : '';
		$excluded_statuses = $this->prepare_excluded_statuses();

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT `table_name`.*
			FROM {$wpdb->prefix}wc_order_tax_lookup as `table_name`
			JOIN {$wpdb->prefix}wc_order_stats as `order_table` ON `table_name`.`order_id` = `order_table`.`order_id` 
			WHERE `order_table`.`status` NOT IN ( %s )
			  AND `order_table`.`date_created` >= %s
			  AND `order_table`.`date_created` <= %s",
				$excluded_statuses,
				$after_date,
				$before_date
			),
			ARRAY_A
		);
		return $results;
	}

	public function get_net_revenue_lookup_by_product_id( $args, $variation = false ) {
		$results          = $this->get_order_product_lookup_results( $args );
		$args_net_revenue = array();
		foreach ( $results as $key => $value ) {
			$product_id    = intval( $value['product_id'] );
			$rate_fee      = $this->get_rate_fee_by_order_currency( $value['order_id'] );
			$product_price = (float) $value['product_net_revenue'] / $rate_fee;
			if ( $variation ) {
				$variation_id = intval( $value['variation_id'] ) ? $value['variation_id'] : 0;
				if ( ! isset( $args_net_revenue[ $variation_id ] ) ) {
					$args_net_revenue[ $variation_id ] = $product_price;
				} else {
					$args_net_revenue[ $variation_id ] = $args_net_revenue[ $variation_id ] + $product_price;
				}
			} else {
				if ( ! isset( $args_net_revenue[ $product_id ] ) ) {
					$args_net_revenue[ $product_id ] = $product_price;
				} else {
					$args_net_revenue[ $product_id ] = $args_net_revenue[ $product_id ] + $product_price;
				}
			}
		}
		return $args_net_revenue;
	}

	public function get_net_revenue_lookup_by_category_id( $args, $category_id ) {
		$net_revenue = 0;
		$data        = $this->get_order_product_lookup_results( $args );
		foreach ( $data as $key => $value ) {
			$product_cats_ids = wc_get_product_term_ids( $value['product_id'], 'product_cat' );
			if ( in_array( $category_id, $product_cats_ids ) ) {
				$rate_fee     = $this->get_rate_fee_by_order_currency( $value['order_id'] );
				$net_revenue += (float) $value['product_net_revenue'] / $rate_fee;
			}
		}
		return $net_revenue;
	}

	public function get_amount_lookup_by_coupon_id( $args ) {
		$data                 = $this->get_order_coupon_lookup_results( $args );
		$args_discount_amount = array();
		foreach ( $data as $key => $value ) {
			$coupon_id       = intval( $value['coupon_id'] );
			$rate_fee        = $this->get_rate_fee_by_order_currency( $value['order_id'] );
			$discount_amount = (float) $value['discount_amount'] / $rate_fee;
			if ( ! isset( $args_discount_amount[ $coupon_id ] ) ) {
				$args_discount_amount[ $coupon_id ] = $discount_amount;
			} else {
				$args_discount_amount[ $coupon_id ] = $args_discount_amount[ $coupon_id ] + $discount_amount;
			}
		}
		return $args_discount_amount;
	}

	public function get_tax_info_lookup_by_tax_id( $args ) {
		$data       = $this->get_order_tax_lookup_results( $args );
		$args_taxes = array();
		foreach ( $data as $key => $value ) {
			$tax_id       = intval( $value['tax_rate_id'] );
			$rate_fee     = $this->get_rate_fee_by_order_currency( $value['order_id'] );
			$shipping_tax = (float) $value['shipping_tax'] / $rate_fee;
			$order_tax    = (float) $value['order_tax'] / $rate_fee;
			$total_tax    = (float) $value['total_tax'] / $rate_fee;
			if ( ! isset( $args_taxes[ $tax_id ] ) ) {
				$args_taxes[ $tax_id ] = array(
					'shipping_tax' => $shipping_tax,
					'order_tax'    => $order_tax,
					'total_tax'    => $total_tax,
				);
			} else {
				$args_taxes[ $tax_id ]['shipping_tax'] = $args_taxes[ $tax_id ]['shipping_tax'] + $shipping_tax;
				$args_taxes[ $tax_id ]['order_tax']    = $args_taxes[ $tax_id ]['order_tax'] + $order_tax;
				$args_taxes[ $tax_id ]['total_tax']    = $args_taxes[ $tax_id ]['total_tax'] + $total_tax;
			}
		}
		return $args_taxes;
	}

	public function apply_for_all_currency() {
		return ! isset( $_GET['currency'] ) || empty( $_GET['currency'] ) || 'all_currency' === $_GET['currency'] ? true : false;
	}

	public function get_rate_fee_by_order_currency( $order_id ) {
		$order_currency = YayCurrencyHelper::get_order_currency_by_order_id( $order_id, $this->converted_currency );
		if ( ! $order_currency || $this->default_currency === $order_currency['currency'] ) {
			return 1;
		}

		$rate = YayCurrencyHelper::get_rate_fee( $order_currency );
		return $rate;

	}

	public function woocommerce_analytics_products_stats_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$args_data   = $this->get_order_product_lookup_results( $args );
			$net_revenue = 0;
			foreach ( $args_data as $key => $value ) {
				$rate_fee     = $this->get_rate_fee_by_order_currency( $value['order_id'] );
				$net_revenue += (float) $value['product_net_revenue'] / $rate_fee;
			}
			$results->totals->net_revenue = $net_revenue;
		}

		return $results;
	}

	public function woocommerce_analytics_products_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			if ( ! isset( $results->data ) ) {
				return $results;
			}
			$args_net_revenue = $this->get_net_revenue_lookup_by_product_id( $args );
			foreach ( $results->data as $key => $value ) {
				$product_id                           = intval( $value['product_id'] );
				$results->data[ $key ]['net_revenue'] = Helper::get_value_form_args( $args_net_revenue, $product_id, 0 );
			}
		}
		return $results;
	}

	public function get_analytics_revenue_info( $args, $type = false ) {
		$args_data       = $this->get_order_product_lookup_results( $args, $type );
		$net_revenue     = 0;
		$total_sales     = 0;
		$shipping_totals = 0;
		$tax_amounts     = 0;
		$coupon_amounts  = 0;
		foreach ( $args_data as $key => $value ) {
			$tax              = (float) $value['tax_amount'] + (float) $value['shipping_tax_amount'];
			$rate_fee         = $this->get_rate_fee_by_order_currency( $value['order_id'] );
			$net_revenue     += (float) $value['product_net_revenue'] / $rate_fee;
			$total_sales     += (float) $value['product_gross_revenue'] / $rate_fee;
			$shipping_totals += (float) $value['shipping_amount'] / $rate_fee;
			$tax_amounts     += $tax / $rate_fee;
			$coupon_amounts  += (float) $value['coupon_amount'] / $rate_fee;
		}
		$gross_sales = $coupon_amounts > 0 ? $net_revenue + $coupon_amounts : $net_revenue;
		return array(
			'gross_sales' => $gross_sales,
			'net_revenue' => $net_revenue,
			'total_sales' => $total_sales,
			'shipping'    => $shipping_totals,
			'taxes'       => $tax_amounts,
			'coupon'      => $coupon_amounts,
		);
	}

	public function woocommerce_analytics_revenue_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$data                             = $this->get_analytics_revenue_info( $args, 'revenue' );
			$results->totals->gross_sales     = $data['gross_sales'];
			$results->totals->net_revenue     = $data['net_revenue'];
			$results->totals->total_sales     = $data['total_sales'];
			$results->totals->shipping        = $data['shipping'];
			$results->totals->taxes           = $data['taxes'];
			$results->totals->avg_order_value = ( isset( $results->totals ) && isset( $results->totals->orders_count ) && $results->totals->orders_count > 0 ) ? $data['net_revenue'] / $results->totals->orders_count : 0;
			$results->totals->coupons         = $data['coupon'];
			if ( isset( $results->intervals ) && ! empty( $results->intervals ) ) {
				foreach ( $results->intervals as $interval_key => $interval ) {
					$interval_data = $this->get_analytics_revenue_info(
						array(
							'before' => $interval['date_end'],
							'after'  => $interval['date_start'],
						),
						'revenue'
					);

					$results->intervals[ $interval_key ]['subtotals']->gross_sales = $interval_data['gross_sales'];
					$results->intervals[ $interval_key ]['subtotals']->net_revenue = $interval_data['net_revenue'];
					$results->intervals[ $interval_key ]['subtotals']->taxes       = $interval_data['taxes'];
					$results->intervals[ $interval_key ]['subtotals']->shipping    = $interval_data['shipping'];
					$results->intervals[ $interval_key ]['subtotals']->total_sales = $interval_data['total_sales'];
					$results->intervals[ $interval_key ]['subtotals']->coupons     = $interval_data['coupon'];

				}
			}
		}
		return $results;
	}

	public function custom_leaderboards_analytics( $leaderboards, $per_page, $after, $before, $persisted_query ) {
		$leaderboards = array(
			$this->get_categories_leaderboard( $per_page, $after, $before, $persisted_query ),
			$this->get_products_leaderboard( $per_page, $after, $before, $persisted_query ),
			$this->get_coupons_leaderboard( $per_page, $after, $before, $persisted_query ),
			$this->get_customers_leaderboard( $per_page, $after, $before, $persisted_query ),
		);
		return $leaderboards;
	}

	public function leaderboards_categories_by_currency( $currency, $category, $args ) {
		$currency_symbol = YayCurrencyHelper::get_symbol_by_currency( $this->default_currency, $this->converted_currency );
		$args_data       = $this->get_order_product_lookup_results( $args );
		$net_revenue     = 0;
		$item_sold       = 0;
		if ( $currency ) {
			$apply_currency = YayCurrencyHelper::filtered_by_currency_code( $currency, $this->converted_currency );
			if ( ! empty( $apply_currency ) ) {
				$currency_symbol = $apply_currency['symbol'];
			}
		}

		foreach ( $args_data as $key => $value ) {
			$product_cats_ids = wc_get_product_term_ids( intval( $value['product_id'] ), 'product_cat' );
			if ( in_array( $category['category_id'], $product_cats_ids ) ) {
				$product_net_revenue = (float) $value['product_net_revenue'];
				$order               = wc_get_order( $value['order_id'] );
				$currency_code       = YayCurrencyHelper::get_currency_code_by_order( $order );

				if ( $currency ) {
					if ( $currency === $currency_code ) {
						$net_revenue += $product_net_revenue;
						$item_sold    = $item_sold + intval( $value['product_qty'] );
					}
				} else {
					$order_currency = YayCurrencyHelper::filtered_by_currency_code( $currency_code, $this->converted_currency );
					if ( ! empty( $order_currency ) ) {
						$net_revenue += $product_net_revenue ? $product_net_revenue / YayCurrencyHelper::get_rate_fee( $order_currency ) : 0;
						$item_sold    = $item_sold + intval( $value['product_qty'] );
					}
				}
			}
		}
		$category['net_revenue']     = $net_revenue;
		$category['items_sold']      = $item_sold;
		$category['currency_symbol'] = $currency_symbol;
		return $category;
	}

	public function get_categories_leaderboard( $per_page, $after, $before, $persisted_query ) {
		$categories_data_store = new CategoriesDataStore();
		$categories_data       = $per_page > 0 ? $categories_data_store->get_data(
			apply_filters(
				'woocommerce_analytics_categories_query_args',
				array(
					'orderby'       => 'items_sold',
					'order'         => 'desc',
					'after'         => $after,
					'before'        => $before,
					'per_page'      => $per_page,
					'extended_info' => true,
				)
			)
		)->data : array();

		$rows = array();

		foreach ( $categories_data as $category ) {
			$url_query     = wp_parse_args(
				array(
					'filter'     => 'single_category',
					'categories' => $category['category_id'],
				),
				$persisted_query
			);
			$category_url  = wc_admin_url( '/analytics/categories', $url_query );
			$category_name = isset( $category['extended_info'] ) && isset( $category['extended_info']['name'] ) ? $category['extended_info']['name'] : '';

			$currency = isset( $_GET['currency'] ) && ! empty( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ? sanitize_text_field( wp_unslash( $_GET['currency'] ) ) : false;
			$args     = array(
				'after'  => $after,
				'before' => $before,
			);
			$category = $this->leaderboards_categories_by_currency( $currency, $category, $args );

			$rows[] = array(
				array(
					'display' => '<a href="' . esc_attr( $category_url ) . '">' . esc_html( $category_name ) . '</a>',
					'value'   => $category_name,
				),
				array(
					'display' => wc_admin_number_format( $category['items_sold'] ),
					'value'   => $category['items_sold'],
				),
				array(
					'display' => wp_kses_post( html_entity_decode( '~' . $category['currency_symbol'] . number_format( $category['net_revenue'], 2, '.', ',' ) ) ),
					'value'   => $category['net_revenue'],
				),
			);
		}

		return array(
			'id'      => 'categories',
			'label'   => __( 'Top Categories - Items Sold', 'woocommerce' ),
			'headers' => array(
				array(
					'label' => __( 'Category', 'woocommerce' ),
				),
				array(
					'label' => __( 'Items Sold', 'woocommerce' ),
				),
				array(
					'label' => __( 'Net Sales', 'woocommerce' ),
				),
			),
			'rows'    => $rows,
		);
	}

	public function get_products_leaderboard( $per_page, $after, $before, $persisted_query ) {
		$products_data_store = new ProductsDataStore();
		$products_data       = $per_page > 0 ? $products_data_store->get_data(
			apply_filters(
				'woocommerce_analytics_products_query_args',
				array(
					'orderby'       => 'items_sold',
					'order'         => 'desc',
					'after'         => $after,
					'before'        => $before,
					'per_page'      => $per_page,
					'extended_info' => true,
				)
			)
		)->data : array();

		$rows = array();

		$currency_symbol = YayCurrencyHelper::get_symbol_by_currency( $this->default_currency, $this->converted_currency );

		foreach ( $products_data as $product ) {
			$url_query    = wp_parse_args(
				array(
					'filter'   => 'single_product',
					'products' => $product['product_id'],
				),
				$persisted_query
			);
			$product_url  = wc_admin_url( '/analytics/products', $url_query );
			$product_name = isset( $product['extended_info'] ) && isset( $product['extended_info']['name'] ) ? $product['extended_info']['name'] : '';
			if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
				$currency        = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
				$currency_symbol = YayCurrencyHelper::get_symbol_by_currency_code( $currency );
			} else {
				$args                   = array(
					'after'  => $after,
					'before' => $before,
				);
				$args_net_revenue       = $this->get_net_revenue_lookup_by_product_id( $args );
				$product['net_revenue'] = Helper::get_value_form_args( $args_net_revenue, $product['product_id'], 0 );
			}
			$rows[] = array(
				array(
					'display' => '<a href="' . esc_attr( $product_url ) . '">' . esc_html( $product_name ) . '</a>',
					'value'   => $product_name,
				),
				array(
					'display' => wc_admin_number_format( $product['items_sold'] ),
					'value'   => $product['items_sold'],
				),
				array(
					'display' => wp_kses_post( html_entity_decode( '~' . $currency_symbol . number_format( $product['net_revenue'], 2, '.', ',' ) ) ),
					'value'   => $product['net_revenue'],
				),
			);
		}

		return array(
			'id'      => 'products',
			'label'   => __( 'Top Products - Items Sold', 'woocommerce' ),
			'headers' => array(
				array(
					'label' => __( 'Product', 'woocommerce' ),
				),
				array(
					'label' => __( 'Items Sold', 'woocommerce' ),
				),
				array(
					'label' => __( 'Net Sales', 'woocommerce' ),
				),
			),
			'rows'    => $rows,
		);
	}

	public function get_apply_currencies_info() {
		$all_apply_currencies  = Helper::get_currencies_post_type();
		$currencies_meta_value = array();

		foreach ( $all_apply_currencies as $currency ) {
			$currency_meta                                  = get_post_meta( $currency->ID, '', true );
			$currencies_meta_value[ $currency->post_title ] = array(
				'rate' => $currency_meta['rate'][0],
				'fee'  => maybe_unserialize( $currency_meta['fee'][0] ),
			);
		}
		return array(
			'all_apply_currencies'  => $all_apply_currencies,
			'currencies_meta_value' => $currencies_meta_value,
		);
	}

	public function get_coupons_leaderboard( $per_page, $after, $before, $persisted_query ) {
		$coupons_data_store = new CouponsDataStore();
		$coupons_data       = $per_page > 0 ? $coupons_data_store->get_data(
			apply_filters(
				'woocommerce_analytics_coupons_query_args',
				array(
					'orderby'       => 'orders_count',
					'order'         => 'desc',
					'after'         => $after,
					'before'        => $before,
					'per_page'      => $per_page,
					'extended_info' => true,
				)
			)
		)->data : array();

		$rows = array();

		$currency_symbol = YayCurrencyHelper::get_symbol_by_currency( $this->default_currency, $this->converted_currency );

		foreach ( $coupons_data as $coupon ) {
			$url_query   = wp_parse_args(
				array(
					'filter'  => 'single_coupon',
					'coupons' => $coupon['coupon_id'],
				),
				$persisted_query
			);
			$coupon_url  = wc_admin_url( '/analytics/coupons', $url_query );
			$coupon_code = isset( $coupon['extended_info'] ) && isset( $coupon['extended_info']['code'] ) ? $coupon['extended_info']['code'] : '';
			if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
				$currency                  = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
				$all_apply_currencies_info = $this->get_apply_currencies_info();
				$rate                      = $all_apply_currencies_info['currencies_meta_value'][ $currency ]['rate'];
				$fee                       = 'percentage' === $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['type'] ? ( $coupon['amount'] ) / ( $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['value'] / 100 ) : ( $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['value'] * $coupon['amount'] );
				$currency_symbol           = YayCurrencyHelper::get_symbol_by_currency( $currency, $this->converted_currency );
				$coupon['amount']          = ( $coupon['amount'] * $rate ) + $fee;
			}
			$rows[] = array(
				array(
					'display' => '<a href="' . esc_attr( $coupon_url ) . '">' . esc_html( $coupon_code ) . '</a>',
					'value'   => $coupon_code,
				),
				array(
					'display' => wc_admin_number_format( $coupon['orders_count'] ),
					'value'   => $coupon['orders_count'],
				),
				array(
					'display' => wp_kses_post( html_entity_decode( '~' . $currency_symbol . number_format( $coupon['amount'], 2, '.', ',' ) ) ),
					'value'   => $coupon['amount'],
				),
			);
		}

		return array(
			'id'      => 'coupons',
			'label'   => __( 'Top Coupons - Number of Orders', 'woocommerce' ),
			'headers' => array(
				array(
					'label' => __( 'Coupon Code', 'woocommerce' ),
				),
				array(
					'label' => __( 'Orders', 'woocommerce' ),
				),
				array(
					'label' => __( 'Amount Discounted', 'woocommerce' ),
				),
			),
			'rows'    => $rows,
		);
	}

	public function get_customers_leaderboard( $per_page, $after, $before, $persisted_query ) {
		$currency             = $this->default_currency;
		$customers_data_store = new CustomersDataStore();
		$customers_data       = $per_page > 0 ? $customers_data_store->get_data(
			apply_filters(
				'woocommerce_analytics_customers_query_args',
				array(
					'orderby'      => 'total_spend',
					'order'        => 'desc',
					'order_after'  => $after,
					'order_before' => $before,
					'per_page'     => $per_page,
				)
			)
		)->data : array();

		$rows = array();

		$currency_symbol = YayCurrencyHelper::get_symbol_by_currency( $this->default_currency, $this->converted_currency );

		foreach ( $customers_data as $customer ) {
			$url_query    = wp_parse_args(
				array(
					'filter'    => 'single_customer',
					'customers' => $customer['id'],
				),
				$persisted_query
			);
			$customer_url = wc_admin_url( '/analytics/customers', $url_query );
			if ( isset( $_GET['currency'] ) && 'all_currency' !== $_GET['currency'] ) {
				$currency                  = sanitize_text_field( wp_unslash( $_GET['currency'] ) );
				$all_apply_currencies_info = $this->get_apply_currencies_info();
				$rate                      = $all_apply_currencies_info['currencies_meta_value'][ $currency ]['rate'];
				$fee                       = 'percentage' === $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['type'] ? ( $customer['total_spend'] ) / ( $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['value'] / 100 ) : ( $all_apply_currencies_info['currencies_meta_value'][ $currency ]['fee']['value'] * $customer['orders_count'] );
				$currency_symbol           = YayCurrencyHelper::get_symbol_by_currency( $currency, $this->converted_currency );
				$customer['total_spend']   = ( $customer['total_spend'] * $rate ) + $fee;
			}
			$rows[] = array(
				array(
					'display' => '<a href="' . esc_attr( $customer_url ) . '">' . esc_html( $customer['name'] ) . '</a>',
					'value'   => $customer['name'],
				),
				array(
					'display' => $customer['orders_count'],
					'value'   => $customer['orders_count'],
				),
				array(
					'display' => wp_kses_post( html_entity_decode( '~' . $currency_symbol . number_format( $customer['total_spend'], 2, '.', ',' ) ) ),
					'value'   => $customer['total_spend'],
				),
			);
		}

		return array(
			'id'      => 'customers',
			'label'   => __( 'Top Customers - Total Spend', 'woocommerce' ),
			'headers' => array(
				array(
					'label' => __( 'Customer Name', 'woocommerce' ),
				),
				array(
					'label' => __( 'Orders', 'woocommerce' ),
				),
				array(
					'label' => __( 'Total Spend', 'woocommerce' ),
				),
			),
			'rows'    => $rows,
		);
	}

	public function woocommerce_analytics_orders_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {

			foreach ( $results->data as $key => $value ) {
				$rate_fee = $this->get_rate_fee_by_order_currency( $value['order_id'] );
				if ( 1 !== $rate_fee ) {
					$results->data[ $key ]['net_total']   = (float) $value['net_total'] / $rate_fee;
					$results->data[ $key ]['total_sales'] = (float) $value['total_sales'] / $rate_fee;
				}
			}
		}
		return $results;
	}

	public function woocommerce_analytics_orders_stats_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$data                             = $this->get_analytics_revenue_info( $args, 'orders' );
			$results->totals->gross_sales     = $data['gross_sales'];
			$results->totals->net_revenue     = $data['net_revenue'];
			$results->totals->total_sales     = $data['total_sales'];
			$results->totals->shipping        = $data['shipping'];
			$results->totals->taxes           = $data['taxes'];
			$results->totals->avg_order_value = $results->totals->orders_count > 0 ? $data['net_revenue'] / $results->totals->orders_count : 0;
			$results->totals->coupons         = $data['coupon'];
		}
		return $results;
	}

	public function get_net_revenue_analytics_variations_by_date( $args ) {
		$data        = $this->get_order_product_lookup_results( $args );
		$net_revenue = 0;
		foreach ( $data as $key => $value ) {
			$variation_id = isset( $value['variation_id'] ) && ! empty( $value['variation_id'] ) ? intval( $value['variation_id'] ) : false;
			if ( $variation_id ) {
				$rate_fee     = $this->get_rate_fee_by_order_currency( $value['order_id'] );
				$net_revenue += (float) $value['product_net_revenue'] / $rate_fee;
			}
		}
		return $net_revenue;
	}

	public function woocommerce_analytics_variations_stats_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$net_revenue                  = $this->get_net_revenue_analytics_variations_by_date( $args );
			$results->totals->net_revenue = $net_revenue;
			if ( isset( $results->intervals ) && ! empty( $results->intervals ) ) {
				foreach ( $results->intervals as $interval_key => $interval ) {
					$interval_net_revenue = $this->get_net_revenue_analytics_variations_by_date(
						array(
							'before' => $interval['date_end'],
							'after'  => $interval['date_start'],
						)
					);

					$results->intervals[ $interval_key ]['subtotals']->net_revenue = $interval_net_revenue;

				}
			}
		}

		return $results;
	}

	public function woocommerce_analytics_variations_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			if ( ! isset( $results->data ) ) {
				return $results;
			}
			$args_net_revenue = $this->get_net_revenue_lookup_by_product_id( $args, true );
			foreach ( $results->data as $key => $value ) {
				$variation_id = Helper::get_value_form_args( $value, 'variation_id', 0 );
				if ( $variation_id ) {
					$results->data[ $key ]['net_revenue'] = Helper::get_value_form_args( $args_net_revenue, $variation_id, 0 );
				}
			}
		}
		return $results;
	}

	public function woocommerce_analytics_categories_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			if ( ! isset( $results->data ) ) {
				return $results;
			}
			foreach ( $results->data as $category_key => $category ) {
				$results->data[ $category_key ]['net_revenue'] = $this->get_net_revenue_lookup_by_category_id( $args, $category['category_id'] );
			}
		}
		return $results;
	}

	public function woocommerce_analytics_coupons_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$data = $this->get_amount_lookup_by_coupon_id( $args );
			if ( isset( $results->totals ) ) {
				$results->totals->amount = $data ? array_sum( $data ) : 0;
			} else {
				if ( ! isset( $results->data ) ) {
					return $results;
				}
				foreach ( $results->data as $coupon_key => $coupon ) {
					$coupon_id                              = intval( $coupon['coupon_id'] );
					$results->data[ $coupon_key ]['amount'] = Helper::get_value_form_args( $data, $coupon_id, 0 );
				}
			}
		}
		return $results;
	}

	public function woocommerce_analytics_taxes_stats_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			$data                      = $this->get_order_product_lookup_results( $args );
			$total_shipping_tax_amount = 0;
			$total_order_tax           = 0;
			foreach ( $data as $key => $value ) {
				$rate_fee                   = $this->get_rate_fee_by_order_currency( $value['order_id'] );
				$total_shipping_tax_amount += (float) $value['shipping_tax_amount'] / $rate_fee;
				$total_order_tax           += (float) $value['tax_amount'] / $rate_fee;
			}

			$results->totals->order_tax    = $total_order_tax;
			$results->totals->shipping_tax = $total_shipping_tax_amount;
			$results->totals->total_tax    = $total_shipping_tax_amount + $total_order_tax;

		}
		return $results;
	}

	public function woocommerce_analytics_taxes_select_query( $results, $args ) {
		if ( $this->apply_for_all_currency() ) {
			if ( ! isset( $results->data ) ) {
				return $results;
			}
			$data = $this->get_tax_info_lookup_by_tax_id( $args );
			foreach ( $results->data as $tax_key => $tax ) {
				$tax_id = intval( $tax['tax_rate_id'] );
				if ( isset( $data[ $tax_id ] ) ) {
					$results->data[ $tax_key ]['shipping_tax'] = Helper::get_value_form_args( $data[ $tax_id ], 'shipping_tax', 0 );
					$results->data[ $tax_key ]['order_tax']    = Helper::get_value_form_args( $data[ $tax_id ], 'order_tax', 0 );
					$results->data[ $tax_key ]['total_tax']    = Helper::get_value_form_args( $data[ $tax_id ], 'total_tax', 0 );
				}
			}
		}
		return $results;
	}

}
