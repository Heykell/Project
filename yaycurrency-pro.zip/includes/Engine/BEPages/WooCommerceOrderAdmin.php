<?php

namespace Yay_Currency\Engine\BEPages;

use Yay_Currency\Utils\SingletonTrait;

use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class WooCommerceOrderAdmin {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {
		add_action( 'current_screen', array( $this, 'get_current_screen' ) );
	}

	public function get_current_screen() {
		$screen = get_current_screen();

		if ( in_array( $screen->id, array( 'woocommerce_page_wc-orders', 'edit-shop_order' ) ) ) {
			add_filter( 'woocommerce_get_formatted_order_total', array( $this, 'get_formatted_order_total' ), 10, 4 );
		}

	}

	public function get_formatted_order_total( $formatted_total, $order, $tax_display, $display_refunded ) {

		$total_refunded = $order->get_total_refunded();

		if ( $total_refunded && $display_refunded ) {
			return $formatted_total;
		}

		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );

		if ( ! empty( $yay_currency_checkout_currency ) && Helper::default_currency_code() !== $yay_currency_checkout_currency ) {

			$converted_currency = YayCurrencyHelper::converted_currency();
			$convert_currency   = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $converted_currency, array(), $yay_currency_checkout_currency );

			if ( ! $convert_currency ) {
				return $formatted_total;
			}

			$total = YayCurrencyHelper::get_total_by_order( $order );

			$formatted_total = YayCurrencyHelper::get_formatted_total_by_convert_currency( $total, $convert_currency, $yay_currency_checkout_currency );

			if ( wc_tax_enabled() && 'incl' === $tax_display ) {
				$formatted_tax   = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_total_tax(), $convert_currency, $yay_currency_checkout_currency );
				$formatted_total = $formatted_total . ' (includes ' . $formatted_tax . ' Tax)';
			}
		}

		return $formatted_total;

	}

}
