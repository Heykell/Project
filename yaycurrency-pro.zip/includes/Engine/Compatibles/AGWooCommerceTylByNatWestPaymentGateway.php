<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;
defined( 'ABSPATH' ) || exit;

// Link plugin: https://weareag.co.uk/product/tyl-by-natwest-for-woocommerce/

class AGWooCommerceTylByNatWestPaymentGateway {

	use SingletonTrait;
	private $apply_currency = array();
	public function __construct() {

		if ( ! class_exists( 'AG_Tyl_init' ) ) {
			return;
		}
		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_filter( 'yay_currency_woocommerce_currency_priority', array( $this, 'yay_currency_woocommerce_currency_priority' ), 10, 1 );
		add_filter( 'yay_currency_woocommerce_currency', array( $this, 'convert_to_default_currency' ), 999, 2 );

		// Side Cart WooCommerce (Floating cart)
		add_filter( 'woocommerce_cart_item_price', array( $this, 'custom_cart_item_price_mini_cart' ), 10, 3 );
		add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'custom_cart_item_subtotal' ), 10, 3 );
		add_filter( 'woocommerce_cart_subtotal', array( $this, 'custom_cart_subtotal_mini_cart' ), 10, 3 );
		add_filter( 'woocommerce_order_get_total', array( $this, 'convert_woocommerce_order_get_total' ), 9999, 2 );

	}

	public function yay_currency_woocommerce_currency_priority( $priority ) {
		$priority = 9999;
		return $priority;
	}

	public function convert_to_default_currency( $currency, $is_dis_checkout_diff_currency ) {
		if ( $is_dis_checkout_diff_currency || doing_action( 'woocommerce_receipt_ag_tyl_checkout' ) ) {
			$currency = Helper::default_currency_code();
		}

		return $currency;
	}

	public function convert_woocommerce_order_get_total( $order_total, $order ) {

		if ( 'ag_tyl_checkout' === $order->get_payment_method() && doing_action( 'woocommerce_receipt_ag_tyl_checkout' ) ) {
			$order_id       = $order->get_id();
			$order_currency = YayCurrencyHelper::get_order_currency_by_order_id( $order_id );

			if ( ! $order_currency ) {
				return $order_total;
			}

			// Convert to Order Total Default Currency
			$order_total = $order_total / YayCurrencyHelper::get_rate_fee( $order_currency );
		}

		return $order_total;

	}

	public function detect_ajax_menu_mini_cart() {
		$xoo_wsc_update_item = isset( $_REQUEST['wc-ajax'] ) && 'xoo_wsc_update_item_quantity' === $_REQUEST['wc-ajax'];
		$pvtfw_add_to_cart   = isset( $_REQUEST['action'] ) && 'pvtfw_woocommerce_ajax_add_to_cart' === $_REQUEST['action'];
		return $xoo_wsc_update_item || $pvtfw_add_to_cart;
	}

	public function custom_cart_item_price_mini_cart( $price, $cart_item, $cart_item_key ) {
		if ( wp_doing_ajax() && $this->detect_ajax_menu_mini_cart() ) {
			$product_price = apply_filters( 'yay_currency_get_cart_item_price', 0, $cart_item, $this->apply_currency );
			$price         = YayCurrencyHelper::format_price( $product_price );
		}
		return $price;
	}

	public function custom_cart_item_subtotal( $price, $cart_item, $cart_item_key ) {
		if ( wp_doing_ajax() && $this->detect_ajax_menu_mini_cart() ) {
			$product_price = apply_filters( 'yay_currency_get_cart_item_price', 0, $cart_item, $this->apply_currency );
			$price         = YayCurrencyHelper::format_price( $product_price * $cart_item['quantity'] );
		}
		return $price;
	}

	public function custom_cart_subtotal_mini_cart( $cart_subtotal, $compound, $cart ) {
		if ( wp_doing_ajax() && $this->detect_ajax_menu_mini_cart() ) {
			$subtotal      = apply_filters( 'yay_currency_get_cart_subtotal', $cart_subtotal, $this->apply_currency );
			$cart_subtotal = YayCurrencyHelper::format_price( $subtotal );
		}
		return $cart_subtotal;
	}
}
