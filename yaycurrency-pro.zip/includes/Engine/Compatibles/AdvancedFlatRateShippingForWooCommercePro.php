<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class AdvancedFlatRateShippingForWooCommercePro {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( ! defined( 'AFRSM_PRO_PLUGIN_VERSION' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();

		add_action( 'advance_flat_rate_shipping_new_total', array( $this, 'custom_new_total' ), 10, 1 );

	}

	public function custom_new_total( $new_total ) {
		$rate_fee = YayCurrencyHelper::get_rate_fee( $this->apply_currency );
		if ( $rate_fee > 0 ) {
			$new_total = $new_total / $rate_fee;
		}
		return $new_total;
	}
}
