<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class BreakdanceTheme {

	use SingletonTrait;
	private $apply_currency = array();
	public function __construct() {
		// Compatible with Breakdance Zero Theme
		if ( 'breakdance-zero' === wp_get_theme()->template ) {
			$this->apply_currency = YayCurrencyHelper::detect_current_currency();
			if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'my_add_to_cart' === $_REQUEST['action'] ) {
				add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'woocommerce_cart_item_price' ), 999, 3 );
				add_filter( 'woocommerce_cart_item_price', array( $this, 'woocommerce_cart_item_price' ), 999, 3 );
				add_filter( 'woocommerce_cart_subtotal', array( $this, 'woocommerce_cart_subtotal' ), 999, 3 );
				add_filter( 'woocommerce_currency_symbol', array( $this, 'change_existing_currency_symbol' ), 10, 2 );
				add_filter( 'woocommerce_gzd_cart_taxes', array( $this, 'woocommerce_gzd_cart_taxes' ), 999, 3 );
			}
		}

	}

	public function change_existing_currency_symbol( $currency_symbol, $currency ) {
		if ( isset( $this->apply_currency['currency'] ) ) {
			$currency_symbol = wp_kses_post( html_entity_decode( $this->apply_currency['symbol'] ) );
		}

		return $currency_symbol;
	}

	public function woocommerce_cart_item_price( $price, $cart_item, $cart_item_key ) {
		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'my_add_to_cart' === $_REQUEST['action'] ) {
			$product_id          = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
			$product_obj         = wc_get_product( $product_id );
			$product_fixed_price = FixedPriceHelper::product_is_set_fixed_price_by_currency( $product_obj, $this->apply_currency );
			$product_fixed_price = $product_fixed_price ? $product_fixed_price : YayCurrencyHelper::calculate_price_by_currency( $product_obj->get_price( 'edit' ), false, $this->apply_currency );
			$price               = YayCurrencyHelper::format_price( $product_fixed_price );

		}
		return $price;
	}

	public function get_cart_subtotal( $cart_contents, $apply_currency ) {
		$subtotal = 0;
		foreach ( $cart_contents  as $key => $value ) {
			$product_id    = $value['variation_id'] ? $value['variation_id'] : $value['product_id'];
			$wc_product    = wc_get_product( $product_id );
			$price_fixed   = FixedPriceHelper::product_is_set_fixed_price_by_currency( $wc_product, $apply_currency );
			$product_price = $price_fixed ? $price_fixed : YayCurrencyHelper::calculate_price_by_currency( $wc_product->get_price( 'edit' ), false, $apply_currency );
			$subtotal      = $subtotal + ( $product_price * $value['quantity'] );
		}
		return $subtotal;
	}

	public function woocommerce_cart_subtotal( $cart_subtotal, $compound, $cart ) {

		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'my_add_to_cart' === $_REQUEST['action'] ) {
			$cart_contents = WC()->cart->get_cart_contents();
			$subtotal      = $this->get_cart_subtotal( $cart_contents, $this->apply_currency );
			$cart_subtotal = YayCurrencyHelper::format_price( $subtotal );
		}

		return $cart_subtotal;
	}

	public function woocommerce_gzd_cart_taxes( $tax_array, $cart, $include_shipping_taxes ) {
		foreach ( $tax_array as $key => $tax ) {
			$tax_array[ $key ]['amount']                = YayCurrencyHelper::calculate_price_by_currency( $tax_array[ $key ]['amount'], false, $this->apply_currency );
			$tax_array[ $key ]['tax']->amount           = $tax_array[ $key ]['amount'];
			$tax_array[ $key ]['tax']->formatted_amount = YayCurrencyHelper::format_price( $tax_array[ $key ]['amount'] );
		}
		return $tax_array;
	}
}
