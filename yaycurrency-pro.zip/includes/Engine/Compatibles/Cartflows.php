<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class Cartflows {
	use SingletonTrait;

	private $apply_currency = array();
	public function __construct() {

		if ( ! class_exists( 'Cartflows_Loader' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();

		add_action( 'woocommerce_before_calculate_totals', array( $this, 'custom_price_to_cart_item' ), 9999 );
		add_filter( 'yay_currency_product_price_3rd_with_condition', array( $this, 'get_price_with_options' ), 10, 2 );
		add_filter( 'yay_currency_get_fixed_product_price_3rd_plugin', array( $this, 'get_product_price_fixed_3rd_plugin' ), 10, 3 );
	}

	public function custom_price_to_cart_item( $cart_object ) {
		if ( wp_doing_ajax() && ! WC()->session->__isset( 'reload_checkout' ) ) {

			foreach ( $cart_object->cart_contents as $key => $value ) {
				$product_obj = $value['data'];
				$fixed_price = FixedPriceHelper::product_is_set_fixed_price_by_currency( $product_obj, $this->apply_currency );
				if ( isset( $value['custom_price'] ) && $fixed_price ) {
					$custom_price                                     = floatval( $value['custom_price'] );
					$product_obj->yay_currency_cart_flow_custom_price = $custom_price;
				}
			}
		}
	}

	public function get_price_with_options( $price, $product ) {

		if ( isset( $product->yay_currency_cart_flow_custom_price ) ) {
			return $product->yay_currency_cart_flow_custom_price;
		}
		return $price;
	}

	public function get_product_price_fixed_3rd_plugin( $fixed_product_price, $product, $apply_currency ) {

		if ( isset( $product->yay_currency_cart_flow_custom_price ) ) {
			$fixed_product_price = $product->yay_currency_cart_flow_custom_price;
		}

		return $fixed_product_price;
	}

}
