<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\SupportHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://hivepress.io/

class HivePress {
	use SingletonTrait;
	private $apply_currency = array();

	public function __construct() {

		if ( ! function_exists( 'hivepress' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();

		add_filter( 'woocommerce_get_cart_contents', array( $this, 'custom_woocommerce_get_cart_contents' ), 10, 1 );
		add_filter( 'yay_currency_get_price_default_in_checkout_page', array( $this, 'get_price_default_in_checkout_page' ), 10, 2 );
		add_filter( 'yay_currency_product_price_3rd_with_condition', array( $this, 'get_price_with_options' ), 10, 2 );

		add_filter( 'hivepress/v1/fields/currency/display_value', array( $this, 'custom_hivepress_price' ), 10, 2 );
		//HivePress Marketplace
		add_filter( 'formatted_woocommerce_price', array( $this, 'formatted_woocommerce_price' ), 10, 6 );

		add_filter( 'yay_currency_get_price_options_by_cart_item', array( $this, 'get_price_options_by_cart_item' ), 10, 5 );
		add_filter( 'yay_currency_get_price_options_default_by_cart_item', array( $this, 'get_price_options_default_by_cart_item' ), 10, 4 );

	}

	public function get_price_options_by_cart_item( $price_options, $cart_item, $product_id, $original_price, $apply_currency ) {

		if ( isset( $cart_item['data']->yay_currency_hp_price_change_by_currency ) ) {
			$price_options = $cart_item['data']->yay_currency_hp_price_change_by_currency;
		}

		return $price_options;
	}

	public function get_price_options_default_by_cart_item( $price_options, $cart_item, $product_id, $original_price ) {

		if ( isset( $cart_item['data']->yay_currency_hp_price_change_by_default ) ) {
			$price_options = $cart_item['data']->yay_currency_hp_price_change_by_default;
		}

		return $price_options;
	}

	public function custom_woocommerce_get_cart_contents( $cart_contents ) {

		foreach ( $cart_contents as $key => $cart_item ) {
			$hp_price_change = isset( $cart_item['hp_price_change'] ) ? $cart_item['hp_price_change'] : false;
			if ( $hp_price_change ) {
				$hp_price_change_by_currency = YayCurrencyHelper::calculate_price_by_currency( $hp_price_change, false, $this->apply_currency );
				$cart_contents[ $key ]['data']->yay_currency_hp_price_change_by_currency = $hp_price_change_by_currency;
				$cart_contents[ $key ]['data']->yay_currency_hp_price_change_by_default  = $hp_price_change;

				$product_id            = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
				$product_price_default = SupportHelper::get_product_price( $product_id );

				$product_price_product_fixed = SupportHelper::product_is_set_fixed_price( $this->apply_currency, $product_id );
				$product_price_with_currency = $product_price_product_fixed ? $product_price_product_fixed : YayCurrencyHelper::calculate_price_by_currency( $product_price_default, false, $this->apply_currency );
				$cart_contents[ $key ]['data']->yay_currency_hp_product_price_by_currency = $product_price_with_currency + $hp_price_change_by_currency;
				$cart_contents[ $key ]['data']->yay_currency_hp_product_price_by_default  = $product_price_default + $hp_price_change;
			}
		}
		return $cart_contents;
	}

	public function get_price_default_in_checkout_page( $price, $product ) {
		if ( isset( $product->yay_currency_hp_product_price_by_default ) ) {
			$price = $product->yay_currency_hp_product_price_by_default;
		}
		return $price;
	}

	public function get_price_with_options( $price, $product ) {
		if ( isset( $product->yay_currency_hp_product_price_by_currency ) ) {
			$price = $product->yay_currency_hp_product_price_by_currency;
		}
		return $price;
	}

	public function custom_hivepress_price( $price, $data ) {
		$price = YayCurrencyHelper::calculate_price_by_currency( $data->get_value(), false, $this->apply_currency );
		return YayCurrencyHelper::format_price( $price );
	}

	public function formatted_woocommerce_price( $price_format, $price, $decimals, $decimal_separator, $thousand_separator, $original_price ) {

		if ( doing_filter( 'hivepress/v1/forms/listing_buy' ) || ( doing_filter( 'template_include' ) && isset( $_REQUEST['_extras'] ) && ! empty( $_REQUEST['_extras'] ) ) ) {
			$price        = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
			$price_format = number_format( $price, $this->apply_currency['numberDecimal'], $this->apply_currency['decimalSeparator'], $this->apply_currency['thousandSeparator'] );
		}

		return $price_format;
	}

}
