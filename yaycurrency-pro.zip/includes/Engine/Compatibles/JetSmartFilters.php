<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://crocoblock.com/plugins/jetsmartfilters/

class JetSmartFilters {
	use SingletonTrait;

	private $apply_currency = null;

	public function __construct() {

		if ( ! class_exists( 'Jet_Smart_Filters' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();

		add_filter( 'jet-smart-filters/filter-instance/args', array( $this, 'custom_query_args' ), 10, 2 );
		add_filter( 'jet-smart-filters/query/final-query', array( $this, 'custom_final_query' ) );
		add_filter( 'woocommerce_get_price_html', array( $this, 'custom_price_html_ajax' ), 10, 2 );
		add_filter( 'woocommerce_variable_price_html', array( $this, 'custom_price_html_variable_ajax' ), 99999, 2 );
		add_filter( 'wcml_raw_price_amount', array( $this, 'raw_price_amount' ), 10, 1 );

	}

	public function raw_price_amount( $price ) {
		$converted_price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
		$converted_price = (float) number_format( $converted_price, (int) $this->apply_currency['numberDecimal'], null, '' );
		return $converted_price;
	}

	public function custom_query_args( $args ) {

		if ( '_price' === $args['query_var'] ) {
			$converted_args_min_price = YayCurrencyHelper::calculate_price_by_currency( $args['min'], false, $this->apply_currency );
			$converted_args_max_price = YayCurrencyHelper::calculate_price_by_currency( $args['max'], false, $this->apply_currency );
			$args['min']              = (float) number_format( $converted_args_min_price, (int) $this->apply_currency['numberDecimal'], null, '' );
			$args['max']              = (float) number_format( $converted_args_max_price, (int) $this->apply_currency['numberDecimal'], null, '' );
		}
		return $args;
	}

	public function custom_final_query( $args ) {

		$providers     = strtok( $args['jet_smart_filters'], '/' );
		$provider_list = array( 'jet-woo-products-grid', 'jet-woo-products-list', 'epro-products', 'epro-archive-products', 'woocommerce-shortcode', 'woocommerce-archive' );

		if ( in_array( $providers, $provider_list ) ) {

			if ( ! empty( $args['meta_query'] ) && is_array( $args['meta_query'] ) ) {

				foreach ( $args['meta_query'] as $index => $value ) {

					if ( '_price' === $args['meta_query'][ $index ]['key'] && ! empty( $args['meta_query'][ $index ]['value'] ) ) {

						if ( is_array( $args['meta_query'][ $index ]['value'] ) ) {
							$original_min_price = YayCurrencyHelper::reverse_calculate_price_by_currency( $args['meta_query'][ $index ]['value'][0] );
							$original_max_price = YayCurrencyHelper::reverse_calculate_price_by_currency( $args['meta_query'][ $index ]['value'][1] );

							$args['meta_query'][ $index ]['value'][0] = $original_min_price;
							$args['meta_query'][ $index ]['value'][1] = $original_max_price;
						}
					}
				}
			}
		}

		return $args;

	}

	public function custom_price_html_ajax( $price_html, $product ) {
		$action = isset( $_REQUEST['action'] ) && 'jet_smart_filters' === $_REQUEST['action'];
		if ( wp_doing_ajax() && $action && 'simple' === $product->get_type() ) {
			$product_price             = $product->get_price();
			$product_price_by_currency = YayCurrencyHelper::calculate_price_by_currency( $product_price, false, $this->apply_currency );

			if ( floatval( $product->get_sale_price() ) > 0 ) {
				$regular_price = YayCurrencyHelper::calculate_price_by_currency( $product->get_regular_price(), false, $this->apply_currency );
				$price_html    = YayCurrencyHelper::format_sale_price( $regular_price, $product_price_by_currency );
			} else {
				$price_html = YayCurrencyHelper::format_price( $product_price_by_currency );
			}

			if ( FixedPriceHelper::is_set_fixed_price() ) {
				$custom_fixed_prices = ! empty( get_post_meta( $product->get_ID(), 'yay_currency_custom_fixed_prices', true ) ) ? get_post_meta( $product->get_ID(), 'yay_currency_custom_fixed_prices', true ) : false;
				if ( $custom_fixed_prices && ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['price'] ) ) {
					$regular_price = ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['regular_price'] ) ? $custom_fixed_prices[ $this->apply_currency['currency'] ]['regular_price'] : $product->get_regular_price();
					if ( floatval( $product->get_sale_price() ) > 0 ) {
						if ( ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['sale_price'] ) ) {
							$sale_price = $custom_fixed_prices[ $this->apply_currency['currency'] ]['sale_price'];
						} else {
							$sale_price = $product->get_sale_price();
						}
						$price_html = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
					} else {
						$price_html = YayCurrencyHelper::format_price( $regular_price );
					}
				}
			}
		}
		return $price_html;
	}

	public function custom_price_html_variable_ajax( $price_html, $product ) {
		if ( wp_doing_ajax() ) {
			$min_price = YayCurrencyHelper::calculate_price_by_currency( $product->get_variation_price( 'min', true ), false, $this->apply_currency );
			$max_price = YayCurrencyHelper::calculate_price_by_currency( $product->get_variation_price( 'max', true ), false, $this->apply_currency );

			$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
			$formatted_max_price = YayCurrencyHelper::format_price( $max_price );
			if ( $min_price == $max_price ) {
				$price_html = $formatted_min_price;
			} else {
				$price_html = $formatted_min_price . ' - ' . $formatted_max_price;
			}
			if ( FixedPriceHelper::is_set_fixed_price() ) {
				$variation_ids = $product->get_children();
				$flag          = false;
				$sale_price    = false;
				$regular_price = false;
				$max_price     = 0;
				foreach ( $variation_ids as $id ) {
					$custom_fixed_prices = get_post_meta( $id, 'yay_currency_custom_fixed_prices', true );
					$price_by_currency   = ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['price'] ) ? $custom_fixed_prices[ $this->apply_currency['currency'] ]['price'] : false;
					if ( $custom_fixed_prices && $price_by_currency ) {
						$flag      = true;
						$min_price = min( $min_price, $price_by_currency );
						$max_price = max( $max_price, $price_by_currency );

						$sale_price    = ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['sale_price'] ) ? $custom_fixed_prices[ $this->apply_currency['currency'] ]['sale_price'] : false;
						$regular_price = ! empty( $custom_fixed_prices[ $this->apply_currency['currency'] ]['regular_price'] ) ? $custom_fixed_prices[ $this->apply_currency['currency'] ]['regular_price'] : false;

					}
				}
				if ( ! $flag ) {
					return $price_html;
				}
				$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
				$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

				if ( $min_price == $max_price ) {
					if ( $sale_price && $regular_price ) {
						$price_html = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
					} else {
						$price_html = $formatted_min_price;
					}
				} else {
					$price_html = $formatted_min_price . ' - ' . $formatted_max_price;
				}
			}
		}
		return $price_html;
	}

}
