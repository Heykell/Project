<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// link plugin :

class LearnPress {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( ! class_exists( '\LP_Admin_Assets' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_filter( 'learn-press/course/price', array( $this, 'custom_course_price' ), 10, 2 );
		add_filter( 'learn-press/course/regular-price', array( $this, 'custom_course_regular_price' ), 10, 2 );
		add_filter( 'learn_press_currency_symbol', array( $this, 'learn_press_currency_symbol' ), 10, 2 );
	}

	public function learn_press_currency_symbol( $currency_symbol, $currency ) {
		return isset( $this->apply_currency['symbol'] ) ? $this->apply_currency['symbol'] : $currency_symbol;
	}

	public function custom_course_price( $price, $product_id ) {
		$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
		return $price;
	}

	public function custom_course_regular_price( $price, $product_id ) {
		$has_symbol = ! is_numeric( $price );
		$price      = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
		if ( $has_symbol && function_exists( 'learn_press_format_price' ) && function_exists( 'learn_press_format_price' ) ) {
			return learn_press_format_price( $price, true );
		}
		return $price;
	}
}
