<?php

namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://wordpress.org/plugins/litespeed-cache/

class LiteSpeedCache {
	use SingletonTrait;

	private static $yay_cookies = array(
		'yay_currency_widget',
		'yay_currency_current_language',
	);

	public function __construct() {
		if ( ! defined( 'LSCWP_V' ) ) {
			return;
		}

		// Filter `litespeed_vary_curr_cookies` to generate current in use vary, which will be used for response vary header.
		add_filter( 'litespeed_vary_curr_cookies', array( $this, 'vary_curr_cookies' ) );
		// Filter `litespeed_vary_cookies` to register the final vary cookies, which will be written to rewrite rule. (litespeed_vary_curr_cookies are always equal to or less than litespeed_vary_cookies)
		add_filter( 'litespeed_vary_cookies', array( $this, 'vary_cookies' ) );

	}

	public function vary_curr_cookies( $list ) {
		return array_merge( $list, self::$yay_cookies );
	}

	public function vary_cookies( $list ) {
		return array_merge( $list, self::$yay_cookies );
	}

}
