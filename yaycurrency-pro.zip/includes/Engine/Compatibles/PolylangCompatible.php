<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class PolylangCompatible {

	use SingletonTrait;
	private $language;
	private $currencies_by_languages;

	public function __construct() {
		if ( ! Helper::polylang_active() ) {
			return;
		}
		add_filter( 'locale', array( $this, 'yay_currency_set_current_language' ), 99999 );
		add_filter( 'yay_currency_wpml_polylang_compatible', array( $this, 'get_polylang_data' ), 10, 1 );
		$this->currencies_by_languages = get_option( 'yay_currency_currencies_by_languages_polylang', array() );
	}

	public function yay_currency_set_current_language( $locale ) {
		// Set current Language with Ajax
		if ( wp_doing_ajax() && isset( $_COOKIE['yay_currency_current_language'] ) && get_option( 'yay_currency_polylang_compatible', array() ) ) {
			$locale = sanitize_text_field( $_COOKIE['yay_currency_current_language'] );
		}

		return $locale;
	}

	public function get_polylang_data( $data ) {
		$list_current_polylang_languages   = pll_languages_list( array( 'fields' => array() ) );
		$converted_list_polylang_languages = array();
		foreach ( $list_current_polylang_languages as $language ) {
			$flag = false;

			if ( $this->currencies_by_languages ) {
				$converted_language = YayCurrencyHelper::get_filtered_currency_by_language( $this->currencies_by_languages, $language->locale );
				if ( $converted_language ) {
					$converted_language = array_shift( $converted_language );
					$flag               = true;
				}
			}

			if ( ! $flag ) {
				$converted_language = array(
					'code'     => $language->locale,
					'language' => $language->name,
					'currency' => 'default',
				);
			}

			array_push( $converted_list_polylang_languages, $converted_language );
		}

		$data['currency_manage_tab_data']['listCurrentPolylangLanguages'] = $converted_list_polylang_languages;
		return $data;
	}

}
