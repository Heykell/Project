<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;

use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://wordpress.org/plugins/pakkelabels-for-woocommerce/
class ShipmondoWooCommerce {

	use SingletonTrait;
	private $apply_currency = array();
	public function __construct() {

		if ( ! function_exists( 'shipmondo_init' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_filter( 'woocommerce_shipping_shipmondo_instance_option', array( $this, 'shipmondo_instance_option' ), 20, 3 );
	}

	public function shipmondo_instance_option( $value, $key, $shipping ) {
		if ( is_admin() || 'free_shipping_total' !== $key ) {
			return $value;
		}

		$value = YayCurrencyHelper::calculate_price_by_currency( $value, false, $this->apply_currency );
		return $value;

	}

}
