<?php

namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class WooCommerceEmailSymbol {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		$flag = defined( 'WCQP_VERSION' ) || function_exists( 'Mollie\WooCommerce\mollie_wc_plugin_autoload' ) || class_exists( 'KCO' );
		if ( ! apply_filters( 'yay_currency_email_change_currency_symbol', $flag ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_action( 'woocommerce_email_order_details', array( $this, 'set_order_id' ), 9, 4 );
		add_filter( 'yay_currency_woocommerce_currency_symbol', array( $this, 'get_currency_symbol' ), 999999, 3 );
	}

	public function set_order_id( $order, $sent_to_admin, $plain_text, $email ) {
		$order_id                                = $order->get_id();
		$_REQUEST['yay_currency_email_order_id'] = $order_id;
	}

	public function get_currency_symbol( $currency_symbol, $currency, $apply_currency ) {
		if ( doing_action( 'woocommerce_email_order_details' ) && isset( $_REQUEST['yay_currency_email_order_id'] ) ) {
			$order_id = sanitize_text_field( $_REQUEST['yay_currency_email_order_id'] );
			$order_id = intval( $order_id );
			if ( $order_id ) {
				$order_currency  = YayCurrencyHelper::get_order_currency_by_order_id( $order_id );
				$currency_symbol = $order_currency ? wp_kses_post( html_entity_decode( $order_currency['symbol'] ) ) : $currency_symbol;
			}
		}
		return $currency_symbol;
	}

}
