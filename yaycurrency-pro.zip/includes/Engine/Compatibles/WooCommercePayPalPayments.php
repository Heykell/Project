<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://woocommerce.com/products/woocommerce-paypal-payments/

class WooCommercePayPalPayments {

	use SingletonTrait;
	private $apply_currency   = array();
	private $default_currency = '';
	private $is_dis_checkout_diff_currency;
	public function __construct() {

		if ( ! class_exists( 'WooCommerce\PayPalCommerce\PPCP' ) ) {
			return;
		}

		$this->apply_currency                = YayCurrencyHelper::detect_current_currency();
		$this->default_currency              = Helper::default_currency_code();
		$this->is_dis_checkout_diff_currency = YayCurrencyHelper::is_dis_checkout_diff_currency( $this->apply_currency );

		add_filter( 'woocommerce_paypal_args', array( $this, 'custom_request_paypal' ), 10, 2 );

		if ( $this->is_dis_checkout_diff_currency ) {
			add_filter( 'yay_currency_woocommerce_currency', array( $this, 'custom_currency_paypal_method' ), 10, 2 );
			add_filter( 'yay_currency_is_original_default_currency', array( $this, 'is_original_default_currency' ), 20, 2 );
			add_filter( 'body_class', array( $this, 'add_class_hide_paypal_button' ) );

			// CALCULATE WITH FALLBACK CURRENCY
			add_filter( 'yay_currency_get_price_fallback_in_checkout_page', array( $this, 'get_price_fallback_in_checkout_page' ), 20, 3 );
			add_filter( 'yay_currency_get_coupon_amount_fallback_currency', array( $this, 'get_coupon_amount_fallback_currency' ), 20, 2 );
			add_filter( 'yay_currency_recalculate_cart_fees_fallback_currency', array( $this, 'recalculate_cart_fees_fallback_currency' ), 20, 2 );

		}

	}

	public function is_calculate_total_default_currency() {
		$flag = false;

		if ( wp_doing_ajax() && ! apply_filters( 'yay_currency_calculated_total_again', false ) ) {
			$args_ajax = array( 'ppc-create-order', 'ppc-save-checkout-form' );
			if ( isset( $_REQUEST['wc-ajax'] ) && in_array( $_REQUEST['wc-ajax'], $args_ajax ) ) {
				return true;
			}
		}

		return $flag;
	}

	public function is_original_default_currency( $flag, $apply_currency ) {

		if ( $this->is_calculate_total_default_currency() ) {
			$flag = true;
		}

		return $flag;
	}

	public function custom_currency_paypal_method( $currency, $is_dis_checkout_diff_currency ) {

		if ( $is_dis_checkout_diff_currency ) {

			$fallback_currency = YayCurrencyHelper::get_fallback_currency( YayCurrencyHelper::converted_currency() );
			if ( ! $fallback_currency || $fallback_currency['currency'] === $this->default_currency ) {
				$currency = $this->default_currency;
			} else {
				$currency = $fallback_currency['currency'];
			}
		}

		return $currency;

	}

	public function custom_request_paypal( $args, $order ) {
		if ( $this->is_dis_checkout_diff_currency ) {
			$fallback_currency = YayCurrencyHelper::get_fallback_currency( YayCurrencyHelper::converted_currency() );
			if ( ! $fallback_currency || $fallback_currency['currency'] === $this->default_currency ) {
				$currency_code = $this->default_currency;
			} else {
				$currency_code = $fallback_currency['currency'];
			}
		} else {
			$currency_code = isset( $this->apply_currency['currency'] ) ? $this->apply_currency['currency'] : Helper::default_currency_code();
		}
		$args['currency_code'] = $currency_code;
		return $args;
	}

	public function add_class_hide_paypal_button( $classes ) {
		if ( is_product() || is_singular( 'product' ) ) {
			$classes[] = 'yay-currency-product-page';
		}
		return $classes;
	}

	public function get_price_fallback_in_checkout_page( $price, $product, $fallback_currency ) {
		if ( $this->is_calculate_total_default_currency() ) {
			$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $fallback_currency );
			$price = FixedPriceHelper::get_price_fixed_by_apply_currency( $product, $price, $fallback_currency );
		} else {
			$price = apply_filters( 'yay_currency_get_price_default_in_checkout_page', $price, $product );
		}
		return $price;
	}

	public function get_coupon_amount_fallback_currency( $price, $fallback_currency ) {
		if ( $this->is_calculate_total_default_currency() ) {
			$price = YayCurrencyHelper::calculate_price_by_currency( $price, true, $fallback_currency );
		}
		return $price;
	}

	public function recalculate_cart_fees_fallback_currency( $cart, $fallback_currency ) {

		if ( $this->is_calculate_total_default_currency() ) {
			foreach ( $cart->get_fees() as $fee ) {
				$amount      = YayCurrencyHelper::calculate_price_by_currency( $fee->amount, true, $fallback_currency );
				$fee->amount = $amount;
			}
		}

	}


}
