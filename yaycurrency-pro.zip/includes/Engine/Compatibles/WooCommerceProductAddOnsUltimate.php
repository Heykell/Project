<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\SupportHelper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://pluginrepublic.com/wordpress-plugins/woocommerce-product-add-ons-ultimate/

class WooCommerceProductAddOnsUltimate {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( ! defined( 'PEWC_PLUGIN_VERSION' ) ) {
			return;
		}
		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_filter( 'pewc_after_add_cart_item_data', array( $this, 'pewc_after_add_cart_item_data' ), 10, 1 );
		add_filter( 'yay_currency_product_price_3rd_with_condition', array( $this, 'get_price_with_options' ), 10, 2 );
		add_filter( 'yay_currency_get_price_default_in_checkout_page', array( $this, 'get_price_default_in_checkout_page' ), 10, 2 );
		// set subscription_renewal price and subscription_resubscribe price to cart contents
		add_filter( 'woocommerce_get_cart_contents', array( $this, 'custom_woocommerce_get_cart_contents' ), 10, 1 );
	}

	public function custom_woocommerce_get_cart_contents( $cart_contents ) {

		foreach ( $cart_contents as $key => $cart_item ) {
			$product_extras = isset( $cart_item['product_extras'] ) ? $cart_item['product_extras'] : false;
			if ( $product_extras && isset( $product_extras['yay_currency'] ) ) {
				$product_id                  = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
				$price_with_extras_default   = SupportHelper::get_product_price( $product_id );
				$product_price_product_fixed = SupportHelper::product_is_set_fixed_price( $this->apply_currency, $product_id );
				$product_price_with_currency = $product_price_product_fixed ? $product_price_product_fixed : YayCurrencyHelper::calculate_price_by_currency( $price_with_extras_default, false, $this->apply_currency );
				$price_with_extras           = $product_extras['yay_currency'] === $this->apply_currency['currency'] ? $product_extras['price_with_extras'] : $product_price_with_currency;
				$cart_contents[ $key ]['data']->yay_currency_product_price_with_extras_by_currency = $price_with_extras;
				$cart_contents[ $key ]['data']->yay_currency_product_price_with_extras_by_default  = $price_with_extras_default;
			}
		}
		return $cart_contents;
	}

	public function pewc_after_add_cart_item_data( $cart_item_data ) {
		$product_extras = isset( $cart_item_data['product_extras'] ) && ! empty( $cart_item_data['product_extras'] ) ? $cart_item_data['product_extras'] : false;
		if ( $product_extras ) {
			$cart_item_data['product_extras']['yay_currency'] = $this->apply_currency['currency'];
		}
		return $cart_item_data;
	}

	public function get_price_with_options( $price, $product ) {

		if ( isset( $product->yay_currency_product_price_with_extras_by_currency ) ) {
			$price = $product->yay_currency_product_price_with_extras_by_currency;
		}
		return $price;
	}

	public function get_price_default_in_checkout_page( $price, $product ) {

		if ( isset( $product->yay_currency_product_price_with_extras_by_default ) ) {
			$price = $product->yay_currency_product_price_with_extras_by_default;
		}
		return $price;
	}

}
