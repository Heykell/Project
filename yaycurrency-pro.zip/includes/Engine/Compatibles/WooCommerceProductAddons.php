<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Helpers\SupportHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://woocommerce.com/products/product-add-ons/

class WooCommerceProductAddons {
	use SingletonTrait;

	private $converted_currency = array();
	private $apply_currency     = array();

	public function __construct() {

		if ( ! defined( 'WC_PRODUCT_ADDONS_VERSION' ) ) {
			return;
		}

		$this->converted_currency = YayCurrencyHelper::converted_currency();
		$this->apply_currency     = YayCurrencyHelper::get_apply_currency( $this->converted_currency );

		add_filter( 'yay_currency_price_options', array( $this, 'get_price_options' ), 10, 2 );

		add_filter( 'woocommerce_product_addons_option_price_raw', array( $this, 'custom_product_addons_option_price' ), 10, 2 );
		add_filter( 'woocommerce_product_addons_get_item_data', array( $this, 'custom_cart_item_addon_data' ), 10, 3 );
		// Place Order
		add_filter( 'woocommerce_product_addons_order_line_item_meta', array( $this, 'custom_order_line_item_meta' ), 10, 4 );

		add_filter( 'yay_currency_get_price_default_in_checkout_page', array( $this, 'get_price_default_in_checkout_page' ), 10, 2 );
		add_filter( 'yay_currency_product_price_3rd_with_condition', array( $this, 'get_price_with_options' ), 10, 2 );

		add_filter( 'yay_currency_get_price_options_by_cart_item', array( $this, 'get_price_options_by_cart_item' ), 10, 5 );
		add_filter( 'yay_currency_get_price_options_default_by_cart_item', array( $this, 'get_price_options_default_by_cart_item' ), 10, 4 );

		add_filter( 'yay_currency_get_fixed_product_price_3rd_plugin', array( $this, 'get_product_price_fixed_3rd_plugin' ), 10, 3 );
		// set subscription_renewal price and subscription_resubscribe price to cart contents
		add_filter( 'woocommerce_get_cart_contents', array( $this, 'custom_woocommerce_get_cart_contents' ), 10, 1 );
	}

	public function custom_woocommerce_get_cart_contents( $cart_contents ) {

		foreach ( $cart_contents as $key => $cart_item ) {
			$addons = isset( $cart_item['addons'] ) ? $cart_item['addons'] : false;
			if ( $addons ) {
				$data_details                   = $this->calculate_price_options_by_cart_item( $cart_item, $this->apply_currency );
				$price_options_current_currency = $data_details['price_options_current_currency'];
				$price_options_default_currency = $data_details['price_options_default_currency'];
				$cart_contents[ $key ]['data']->yay_currency_addon_original_price_options    = $price_options_default_currency;
				$cart_contents[ $key ]['data']->yay_currency_addon_price_options_by_currency = $price_options_current_currency;

				$cart_contents[ $key ]['data']->yay_currency_addon_set_options_price_default      = $price_options_default_currency;
				$cart_contents[ $key ]['data']->yay_currency_addon_set_price_with_options_default = $data_details['product_price_with_option_default_currency'];
				$cart_contents[ $key ]['data']->yay_currency_addon_set_options_price              = $price_options_current_currency;
				$cart_contents[ $key ]['data']->yay_currency_addon_set_price_with_options         = $data_details['product_price_with_option_current_currency'];

			}
		}
		return $cart_contents;
	}

	public function get_price_options( $price_options, $product ) {
		if ( isset( $product->yay_currency_addon_set_options_price ) ) {
			$price_options = $product->yay_currency_addon_set_options_price;
		}
		return $price_options;
	}

	public function custom_product_addons_option_price( $price, $option ) {
		if ( 'percentage_based' !== $option['price_type'] ) {
			$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
		}
		return $price;
	}

	public function custom_formatted_item_fee( $args_price_option, $apply_currency, $addon ) {
		$item_fee = isset( $args_price_option['price_options_current_currency'] ) ? $args_price_option['price_options_current_currency'] : (float) $addon['price'];

		$formatted_item_fee = YayCurrencyHelper::format_price( $item_fee );

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $apply_currency ) ) {

			$item_fee = isset( $args_price_option['price_options_default_currency'] ) ? $args_price_option['price_options_default_currency'] : (float) $addon['price'];

			if ( YayCurrencyHelper::is_checkout_in_fallback() ) {
				$fallback_currency  = YayCurrencyHelper::get_fallback_currency( $this->converted_currency );
				$formatted_item_fee = YayCurrencyHelper::calculate_price_by_currency_html( $fallback_currency, $item_fee );
			} else {
				$formatted_item_fee = wc_price( $item_fee );
			}
		}
		return $addon['value'] . ' (+ ' . $formatted_item_fee . ')';
	}

	public function custom_cart_item_addon_data( $addon_data, $addon, $cart_item ) {
		$addon_price = isset( $addon['price'] ) && ! empty( $addon['price'] ) ? $addon['price'] : false;
		if ( $addon_price ) {

			$args = $this->calculate_price_options_by_cart_item( $cart_item, $this->apply_currency, $addon['value'] );
			if ( ! $args ) {
				return $addon_data;
			}

			$addon_data['value'] = $this->custom_formatted_item_fee( $args, $this->apply_currency, $addon );

		}

		return $addon_data;

	}

	public function custom_order_line_item_meta( $meta_data, $addon, $item, $cart_item ) {

		$addon_price = isset( $addon['price'] ) && ! empty( $addon['price'] ) ? $addon['price'] : false;

		if ( ! $addon_price ) {
			return $meta_data;
		}

		$args = $this->calculate_price_options_by_cart_item( $cart_item, $this->apply_currency, $addon['value'] );

		if ( ! $args ) {
			return $meta_data;
		}

		$meta_data['value'] = $this->custom_formatted_item_fee( $args, $this->apply_currency, $addon );

		return $meta_data;

	}

	public function calculate_price_options_by_cart_item( $cart_item, $apply_currency, $addon_value = false ) {

		$price_options_default_currency = 0;
		$price_options_current_currency = 0;

		$product_id    = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
		$product_price = SupportHelper::get_product_price( $product_id );

		$product_price_by_currency = YayCurrencyHelper::calculate_price_by_currency( $product_price, false, $apply_currency );
		$product_price_by_currency = FixedPriceHelper::get_price_fixed_by_apply_currency( $cart_item['data'], $product_price_by_currency, $this->apply_currency );

		if ( ! $addon_value ) {
			foreach ( $cart_item['addons'] as $key => $addon ) {
				if ( isset( $addon['price_type'] ) ) {
					if ( 'percentage_based' !== $addon['price_type'] ) {
						$price_options_default_currency += (float) $addon['price'];
						$price_options_current_currency += YayCurrencyHelper::calculate_price_by_currency( $addon['price'], false, $apply_currency );
					} else {
						$price_options_default_currency += $product_price * ( $addon['price'] / 100 );
						$price_options_current_currency += $product_price_by_currency * ( $addon['price'] / 100 );
					}
				}
			}
		} else {
			$result = array_filter(
				$cart_item['addons'],
				function ( $option ) use ( $addon_value ) {
					if ( $option['value'] === $addon_value ) {
						return true;
					}
					return false;
				}
			);

			if ( $result ) {
				$addon = $result ? array_shift( $result ) : false;
				if ( 'percentage_based' !== $addon['price_type'] ) {
					$price_options_default_currency = (float) $addon['price'];
					$price_options_current_currency = YayCurrencyHelper::calculate_price_by_currency( $addon['price'], false, $apply_currency );
				} else {
					$price_options_default_currency = $product_price * ( $addon['price'] / 100 );
					$price_options_current_currency = $product_price_by_currency * ( $addon['price'] / 100 );
				}
			}
		}

		$data = array(
			'price_options_default_currency'             => $price_options_default_currency,
			'price_options_current_currency'             => $price_options_current_currency,
			'product_price_with_option_default_currency' => $product_price + $price_options_default_currency,
			'product_price_with_option_current_currency' => $product_price_by_currency + $price_options_current_currency,
		);
		return $data;
	}


	public function get_price_default_in_checkout_page( $price, $product ) {

		if ( isset( $product->yay_currency_addon_set_price_with_options_default ) ) {
			$price = $product->yay_currency_addon_set_price_with_options_default;
		}
		return $price;
	}

	public function get_price_with_options( $price, $product ) {

		if ( isset( $product->yay_currency_addon_set_price_with_options ) ) {
			$price = $product->yay_currency_addon_set_price_with_options;
		}
		return $price;
	}

	public function get_price_options_by_cart_item( $price_options, $cart_item, $product_id, $original_price, $apply_currency ) {
		$addons = isset( $cart_item['addons'] ) ? $cart_item['addons'] : false;
		if ( ! $addons ) {
			return $price_options;
		}

		$data_details = $this->calculate_price_options_by_cart_item( $cart_item, $this->apply_currency );

		return isset( $data_details['price_options_current_currency'] ) ? $data_details['price_options_current_currency'] : 0;
	}

	public function get_price_options_default_by_cart_item( $price_options, $cart_item, $product_id, $original_price ) {
		$addons = isset( $cart_item['addons'] ) ? $cart_item['addons'] : false;
		if ( ! $addons ) {
			return $price_options;
		}
		$data_details = $this->calculate_price_options_by_cart_item( $cart_item, $this->apply_currency );
		return isset( $data_details['price_options_default_currency'] ) ? $data_details['price_options_default_currency'] : 0;
	}

	public function get_product_price_fixed_3rd_plugin( $fixed_product_price, $product, $apply_currency ) {
		if ( isset( $product->yay_currency_addon_set_price_with_options ) ) {
			$fixed_product_price = $product->yay_currency_addon_set_price_with_options;
		}
		return $fixed_product_price;
	}

}
