<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://barn2.com/wordpress-plugins/woocommerce-product-table/

class WooCommerceProductTable {

	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( ! function_exists( 'Barn2\Plugin\WC_Product_Table\wpt' ) ) {
			return;
		}
		$this->apply_currency = YayCurrencyHelper::detect_current_currency();
		add_filter( 'wc_price', array( $this, 'custom_wc_price' ), 999, 5 );

	}

	public function custom_wc_price( $return, $price, $args, $unformatted_price, $original_price ) {
		if ( Helper::default_currency_code() !== $this->apply_currency && wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'wcpt_load_products' === $_REQUEST['action'] ) {
			$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
			$price = YayCurrencyHelper::format_price_currency( $price, $this->apply_currency );

			if ( apply_filters( 'woocommerce_price_trim_zeros', false ) && $this->apply_currency['numberDecimal'] > 0 ) {
				$price = wc_trim_zeros( $price );
			}
			$negative        = $price < 0;
			$price_format    = YayCurrencyHelper::format_currency_symbol( $this->apply_currency );
			$formatted_price = ( $negative ? '-' : '' ) . sprintf( $price_format, '<span class="woocommerce-Price-currencySymbol">' . get_woocommerce_currency_symbol( $this->apply_currency['currency'] ) . '</span>', $price );
			$return          = '<span class="woocommerce-Price-amount amount"><bdi>' . $formatted_price . '</bdi></span>';
			if ( $args['ex_tax_label'] && wc_tax_enabled() ) {
				$return .= ' <small class="woocommerce-Price-taxLabel tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
			}
		}

		return $return;
	}

}
