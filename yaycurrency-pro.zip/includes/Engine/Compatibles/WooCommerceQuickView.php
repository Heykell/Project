<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class WooCommerceQuickView {
	use SingletonTrait;
	private $apply_currency     = array();
	private $is_set_fixed_price = false;
	public function __construct() {
		$current_theme = Helper::get_current_theme();
		// WPC Smart Quick View for WooCommerce
		if ( defined( 'WOOSQ_VERSION' ) || in_array( $current_theme, array( 'salient', 'woodmart' ) ) ) {
			$this->apply_currency     = YayCurrencyHelper::detect_current_currency();
			$this->is_set_fixed_price = FixedPriceHelper::is_set_fixed_price();
			$actions                  = array( 'woosq_quickview', 'woodmart_quick_view', 'nectar_woo_get_product' );
			if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && in_array( $_REQUEST['action'], $actions ) ) {
				add_filter( 'woocommerce_get_price_html', array( $this, 'custom_woocommerce_get_price_html' ), 10, 2 );
				add_filter( 'woocommerce_available_variation', array( $this, 'custom_woocommerce_available_variation' ), 10, 3 );
				add_filter( 'woocommerce_grouped_price_html', array( $this, 'custom_fixed_price_string_grouped_product' ), 10, 3 );
				add_filter( 'woocommerce_currency_symbol', array( $this, 'custom_yay_currency_woocommerce_currency_symbol' ), 10, 2 );
			}
		}
	}

	public function get_format_price_for_simple_product( $price, $product, $apply_currency ) {
		$product_price       = YayCurrencyHelper::calculate_price_by_currency( $product->get_price( 'edit' ), false, $apply_currency );
		$product_fixed_price = FixedPriceHelper::product_is_set_fixed_price_by_currency( $product, $apply_currency );
		if ( $this->is_set_fixed_price && $product_fixed_price ) {
			$price = apply_filters( 'yay_currency_fixed_price_simple_product', $product_price, $product, $apply_currency );
		} else {
			if ( $product->is_on_sale() ) {
				$regular_price = YayCurrencyHelper::calculate_price_by_currency( $product->get_regular_price(), false, $apply_currency );
				$sale_price    = YayCurrencyHelper::calculate_price_by_currency( $product->get_sale_price(), false, $apply_currency );
				$price         = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
			} else {
				$price = YayCurrencyHelper::format_price( $product_price );
			}
		}
		return $price;
	}

	public function get_format_price_for_variable_product( $price, $product, $apply_currency ) {
		$min_price     = $product->get_variation_price( 'min', true );
		$max_price     = $product->get_variation_price( 'max', true );
		$variation_ids = $product->get_children();
		if ( $this->is_set_fixed_price ) {
			foreach ( $variation_ids as $id ) {
				$custom_fixed_prices = get_post_meta( $id, 'yay_currency_custom_fixed_prices', true );
				if ( $custom_fixed_prices && ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
					if ( $min_price == $max_price ) {
						$min_price = min( $min_price, $custom_fixed_prices[ $apply_currency['currency'] ]['price'] );
					} else {
						$min_price = max( $min_price, $custom_fixed_prices[ $apply_currency['currency'] ]['price'] );
					}
					$max_price     = max( $max_price, $custom_fixed_prices[ $apply_currency['currency'] ]['price'] );
					$sale_price    = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] : '';
					$regular_price = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] : '';
				}
			}
			$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
			$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

			if ( $min_price == $max_price ) {
				if ( ! empty( $sale_price ) && ! empty( $regular_price ) ) {
					$price = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
				} else {
					$price = $formatted_min_price;
				}
			} else {
				$price = $formatted_min_price . ' - ' . $formatted_max_price;
			}
		}

		if ( ! isset( $sale_price ) && ! isset( $regular_price ) ) {
			$min_price = YayCurrencyHelper::calculate_price_by_currency_cookie( $product->get_variation_price( 'min', true ) );
			$max_price = YayCurrencyHelper::calculate_price_by_currency_cookie( $product->get_variation_price( 'max', true ) );

			$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
			$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

			$price = $formatted_min_price . ' - ' . $formatted_max_price;
		}

		return $price;
	}

	public function get_format_price_for_grouped_product( $price, $product, $child_prices, $apply_currency ) {
		$min_price          = YayCurrencyHelper::calculate_price_by_currency( min( $child_prices ), false, $this->apply_currency );
		$max_price          = YayCurrencyHelper::calculate_price_by_currency( max( $child_prices ), false, $this->apply_currency );
		$linked_product_ids = $product->get_children();
		$fixed_prices_array = array();
		if ( $this->is_set_fixed_price ) {
			foreach ( $linked_product_ids as $id ) {
				$custom_fixed_prices = get_post_meta( $id, 'yay_currency_custom_fixed_prices', true );
				if ( $custom_fixed_prices && ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
					array_push( $fixed_prices_array, $custom_fixed_prices[ $apply_currency['currency'] ]['price'] );
				}
			}
		}

		if ( ! empty( $fixed_prices_array ) ) {
			$min_price = min( $fixed_prices_array );
			$max_price = max( $fixed_prices_array );
		}

		$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
		$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

		$price = $min_price == $max_price ? $formatted_min_price : $formatted_min_price . ' - ' . $formatted_max_price;

		return $price;
	}

	public function custom_woocommerce_get_price_html( $price, $product ) {
		$product_type = $product->get_type();

		if ( Helper::default_currency_code() === $this->apply_currency['currency'] ) {
			return $price;
		}

		switch ( $product_type ) {

			case 'variable':
			case 'variable-subscription':
				$price = $this->get_format_price_for_variable_product( $price, $product, $this->apply_currency );
				break;
			case 'grouped':
				break;
			default:
				$price = $this->get_format_price_for_simple_product( $price, $product, $this->apply_currency );
				break;
		}

		return $price;
	}

	public function custom_fixed_price_string_grouped_product( $price, $product, $child_prices ) {
		if ( Helper::default_currency_code() === $this->apply_currency['currency'] ) {
			return $price;
		}

		$price = $this->get_format_price_for_grouped_product( $price, $product, $child_prices, $this->apply_currency );
		return $price;
	}

	public function custom_woocommerce_available_variation( $available_variation, $product, $product_variation ) {
		$price                             = $product_variation->get_price( 'edit' );
		$price                             = $this->get_format_price_for_simple_product( $price, $product_variation, $this->apply_currency );
		$available_variation['price_html'] = $price;
		return $available_variation;
	}

	public function custom_yay_currency_woocommerce_currency_symbol( $currency_symbol, $currency ) {
		$currency_symbol = wp_kses_post( html_entity_decode( $this->apply_currency['symbol'] ) );
		return $currency_symbol;
	}

}
