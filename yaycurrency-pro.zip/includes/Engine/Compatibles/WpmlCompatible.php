<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class WpmlCompatible {

	use SingletonTrait;

	private $language;
	private $currencies_by_languages;

	public function __construct() {

		if ( ! Helper::wpml_language_active() ) {
			return;
		}

		add_filter( 'yay_currency_wpml_polylang_compatible', array( $this, 'get_wpml_data' ), 10, 1 );
		$this->currencies_by_languages = get_option( 'yay_currency_currencies_by_languages_wpml', array() );

	}


	public function get_wpml_data( $data ) {
		$list_current_wpml_languages   = icl_get_languages();
		$converted_list_wpml_languages = array();
		foreach ( $list_current_wpml_languages as $key => $value ) {
			$flag = false;
			if ( $this->currencies_by_languages ) {
				$converted_language = YayCurrencyHelper::get_filtered_currency_by_language( $this->currencies_by_languages, $key );
				if ( $converted_language ) {
					$converted_language = array_shift( $converted_language );
					$flag               = true;
				}
			}
			if ( ! $flag ) {
				$converted_language = array(
					'code'     => $key,
					'language' => $value['native_name'],
					'currency' => 'default',
				);
			}
			array_push( $converted_list_wpml_languages, $converted_language );
		}

		$data['currency_manage_tab_data']['listCurrentWpmlLanguages'] = $converted_list_wpml_languages;
		return $data;
	}
}
