<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\FixedPriceHelper;

defined( 'ABSPATH' ) || exit;

// Link plugin: https://yithemes.com/themes/plugins/yith-easy-order-page-for-woocommerce/

class YITHEasyOrderPageForWooCommerce {

	use SingletonTrait;

	private $set_fixed_price;
	private $cookie_name;

	public function __construct() {

		if ( ! function_exists( 'yith_wceop_init' ) ) {
			return;
		}

		$this->set_fixed_price = FixedPriceHelper::is_set_fixed_price();
		$this->cookie_name     = YayCurrencyHelper::get_cookie_name();
		if ( wp_doing_ajax() ) {
			add_filter( 'woocommerce_cart_product_price', array( $this, 'custom_cart_product_price' ), 10, 2 );
			add_filter( 'woocommerce_cart_get_subtotal', array( $this, 'custom_cart_get_subtotal' ), 10, 1 );
		}
	}

	public function custom_cart_get_subtotal( $subtotal ) {
		$subtotal = 0;
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( $this->set_fixed_price ) {
				$custom_fixed_prices = $cart_item['data']->get_meta( 'yay_currency_custom_fixed_prices' );
				if ( ! empty( $custom_fixed_prices ) ) {
					if ( isset( $_COOKIE[ $this->cookie_name ] ) ) {
						$currency_ID    = sanitize_key( $_COOKIE[ $this->cookie_name ] );
						$apply_currency = YayCurrencyHelper::get_currency_by_ID( $currency_ID );
						if ( ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
							$subtotal += $custom_fixed_prices[ $apply_currency['currency'] ]['price'] * $cart_item['quantity'];
						} else {
							$subtotal += YayCurrencyHelper::calculate_price_by_currency_cookie( $cart_item['data']->get_price( 'edit' ) ) * $cart_item['quantity'];
						}
					}
				} else {
					$subtotal += YayCurrencyHelper::calculate_price_by_currency_cookie( $cart_item['data']->get_price( 'edit' ) ) * $cart_item['quantity'];
				}
			}
		}
		return $subtotal;
	}

	public function custom_cart_product_price( $price, $product ) {
		if ( $this->set_fixed_price ) {
			$custom_fixed_prices = $product->get_meta( 'yay_currency_custom_fixed_prices' );

			if ( ! empty( $custom_fixed_prices ) ) {
				if ( isset( $_COOKIE[ $this->cookie_name ] ) ) {

					$currency_ID    = sanitize_key( $_COOKIE[ $this->cookie_name ] );
					$apply_currency = YayCurrencyHelper::get_currency_by_ID( $currency_ID );

					if ( ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
						$custom_fixed_price    = $custom_fixed_prices[ $apply_currency['currency'] ]['price'];
						$formatted_fixed_price = YayCurrencyHelper::format_price( $custom_fixed_price );
						if ( in_array( $product->get_type(), array( 'subscription', 'variable-subscription', 'subscription_variation' ) ) ) {
							return $formatted_fixed_price . ' / ' . $product->get_meta( '_subscription_period' );
						}
						return $formatted_fixed_price;
					}

					$converted_price = YayCurrencyHelper::calculate_price_by_currency_cookie( $product->get_price() );
					$formatted_price = YayCurrencyHelper::format_price( $converted_price );
					if ( in_array( $product->get_type(), array( 'subscription', 'variable-subscription', 'subscription_variation' ) ) ) {
						return $formatted_price . ' / ' . $product->get_meta( '_subscription_period' );
					}
					return $formatted_price;
				}
			}
		}
		$converted_price = YayCurrencyHelper::calculate_price_by_currency_cookie( $product->get_price() );
		$formatted_price = YayCurrencyHelper::format_price( $converted_price );
		return $formatted_price;
	}
}
