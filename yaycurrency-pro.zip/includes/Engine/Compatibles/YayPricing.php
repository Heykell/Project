<?php
namespace Yay_Currency\Engine\Compatibles;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\YayCurrencyHelper;


defined( 'ABSPATH' ) || exit;

class YayPricing {
	use SingletonTrait;

	private $apply_currency = array();

	public function __construct() {

		if ( ! defined( 'YAYDP_VERSION' ) ) {
			return;
		}

		$this->apply_currency = YayCurrencyHelper::detect_current_currency();

		add_filter( 'yay_currency_get_product_price_by_cart_item', array( $this, 'get_product_price_by_cart_item' ), 30, 3 );
		add_filter( 'yay_currency_get_product_price_default_by_cart_item', array( $this, 'get_product_price_default_by_cart_item' ), 10, 2 );
	}

	public function get_product_price_by_cart_item( $price, $cart_item, $apply_currency ) {

		if ( isset( $cart_item['modifiers'] ) && ! empty( $cart_item['modifiers'] ) ) {
			if ( isset( $cart_item['yaydp_custom_data']['price'] ) && ! empty( $cart_item['yaydp_custom_data']['price'] ) ) {
				$price = YayCurrencyHelper::calculate_price_by_currency( $cart_item['yaydp_custom_data']['price'], false, $this->apply_currency );
			}
		}

		return $price;
	}

	public function get_product_price_default_by_cart_item( $price, $cart_item ) {

		if ( isset( $cart_item['modifiers'] ) && ! empty( $cart_item['modifiers'] ) ) {
			if ( isset( $cart_item['yaydp_custom_data']['price'] ) && ! empty( $cart_item['yaydp_custom_data']['price'] ) ) {
				$price = $cart_item['yaydp_custom_data']['price'];
			}
		}

		return $price;
	}

}
