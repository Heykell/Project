<?php
namespace Yay_Currency\Engine\FEPages;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;

defined( 'ABSPATH' ) || exit;

class Shortcodes {

	use SingletonTrait;

	protected function __construct() {

		//Dropdown Shortcode
		add_shortcode( 'yaycurrency-switcher', array( $this, 'currency_dropdown_shortcode' ) );

		//Menu Shortcode
		add_shortcode( 'yaycurrency-menu-item-switcher', array( $this, 'menu_item_switcher_shortcode' ) );

		// Convert Price HTML By Currency
		add_shortcode( 'yaycurrency-price-html', array( $this, 'yay_convert_price_html' ) );

		// Display Current Currency Country Notice
		add_shortcode( 'yaycurrency-country-currency-notice', array( $this, 'yay_convert_country_currency_notice_html' ) );

		// Add Shortcode Current Applycurrency: Flag, Country (Location), Currency, Symbol
		add_shortcode( 'yaycurrency-flag', array( $this, 'yay_get_current_flag' ) );
		add_shortcode( 'yaycurrency-country', array( $this, 'yay_get_current_country' ) );
		add_shortcode( 'yaycurrency-currency', array( $this, 'yay_get_current_currency' ) );
		add_shortcode( 'yaycurrency-symbol', array( $this, 'yay_get_current_symbol' ) );

		// Fee custom
		add_shortcode( 'yaycurrency-fee', array( $this, 'yay_currency_calculate_fee' ) );
		add_shortcode( 'yaycurrency-fee-fallback', array( $this, 'yay_currency_calculate_fee_fallback' ) );
		add_shortcode( 'yaycurrency-fee-default', array( $this, 'yay_currency_calculate_fee_default' ) );
	}

	public function currency_dropdown_shortcode( $content = null ) {
		if ( is_checkout() && ( is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
			return '';
		}
		$is_show_flag            = get_option( 'yay_currency_show_flag_in_switcher', 1 );
		$is_show_currency_name   = get_option( 'yay_currency_show_currency_name_in_switcher', 1 );
		$is_show_currency_symbol = get_option( 'yay_currency_show_currency_symbol_in_switcher', 1 );
		$is_show_currency_code   = get_option( 'yay_currency_show_currency_code_in_switcher', 1 );
		$switcher_size           = get_option( 'yay_currency_switcher_size', 'medium' );

		ob_start();
		require YAY_CURRENCY_PLUGIN_DIR . 'includes/templates/switcher/template.php';
		$content = ob_get_clean();
		return $content;

	}

	public function menu_item_switcher_shortcode( $content = null ) {
		if ( is_checkout() && ( is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
			return '';
		}
		$is_show_flag            = get_option( 'yay_currency_show_flag_in_menu_item', 1 );
		$is_show_currency_name   = get_option( 'yay_currency_show_currency_name_in_menu_item', 1 );
		$is_show_currency_symbol = get_option( 'yay_currency_show_currency_symbol_in_menu_item', 1 );
		$is_show_currency_code   = get_option( 'yay_currency_show_currency_code_in_menu_item', 1 );
		$switcher_size           = get_option( 'yay_currency_menu_item_size', 'small' );

		ob_start();
		require YAY_CURRENCY_PLUGIN_DIR . 'includes/templates/switcher/template.php';
		$content = ob_get_clean();
		return $content;

	}


	public function yay_convert_price_html( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'price' => '',
			),
			$atts
		);

		ob_start();
		$apply_currency = YayCurrencyHelper::detect_current_currency();
		$price          = apply_filters( 'yaycurrency_get_price', $atts['price'] );
		$price_html     = YayCurrencyHelper::calculate_price_by_currency_html( $apply_currency, $price );
		$price_html     = apply_filters( 'yaycurrency_get_price_html', $price_html, $apply_currency );
		echo wp_kses_post( $price_html );
		return ob_get_clean();
	}

	public function get_currency_name_by_currency_code( $currency_code ) {
		$currencies = get_woocommerce_currencies();
		return isset( $currencies[ $currency_code ] ) ? $currencies[ $currency_code ] : false;
	}

	public function yay_convert_country_currency_notice_html( $content = null ) {
		$auto_detect_currency_by_countries = get_option( 'yay_currency_auto_select_currency_by_countries', 0 );

		ob_start();

		if ( ! $auto_detect_currency_by_countries ) {
			return ob_get_clean();
		}

		$country_info  = Helper::get_country_info_from_IP();
		$country_code  = Helper::get_value_form_args( $country_info, 'country_code', false );
		$currency_code = Helper::get_value_form_args( $country_info, 'currency_code', false );

		if ( ! $country_code || ! $currency_code ) {
			return ob_get_clean();
		}

		$apply_currency = YayCurrencyHelper::detect_current_currency();
		$country_code   = strtoupper( $country_code );
		$countries      = $apply_currency['countries'];

		if ( $currency_code === $apply_currency['currency'] || in_array( $country_code, $countries ) ) {

			$html          = get_option( 'yay_currency_setting_notice_text', 'You are from %current-country%, price will be in %current-currency% (%current-currency-symbol%).' );
			$country_name  = WC()->countries->countries[ $country_code ];
			$currency_name = $this->get_currency_name_by_currency_code( $apply_currency['currency'] );
			if ( ! $country_name || ! $currency_name || empty( $html ) ) {
				return ob_get_clean();
			}

			$html = str_replace( '%current-country%', $country_name, $html );
			$html = str_replace( '%current-currency%', $currency_name, $html );
			$html = str_replace( '%current-currency-symbol%', $apply_currency['symbol'], $html );

			echo wp_kses_post( $html );
		}

		return ob_get_clean();

	}

	public function yay_get_current_flag( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'width'  => '40px',
				'height' => '40px',
				'margin' => '0',
			),
			$atts
		);
		ob_start();
		$country_info = Helper::get_country_info_from_IP();
		$country_code = Helper::get_value_form_args( $country_info, 'country_code', false );
		$flag_url     = Helper::get_flag_by_country_code( $country_code );
		$flag_style   = '';
		if ( ! empty( $atts['width'] ) || ! empty( $atts['height'] ) ) {
			$flag_style .= '--flag-width:' . $atts['width'] . ';--flag-height:' . $atts['height'] . ';--flag-margin:' . $atts['margin'];
		}
		echo '<img style="' . esc_attr( $flag_style ) . '" src="' . esc_url( $flag_url ) . '" class="yay-currency-country-flag" />';
		return ob_get_clean();

	}

	public function yay_get_current_country( $content = null ) {

		ob_start();

		$country_info = Helper::get_country_info_from_IP();
		$country_code = Helper::get_value_form_args( $country_info, 'country_code', false );
		$country_code = strtoupper( $country_code );
		$country_name = WC()->countries->countries[ $country_code ];
		echo esc_html( $country_name );

		return ob_get_clean();

	}

	public function yay_get_current_currency( $content = null ) {

		ob_start();

		$apply_currency = YayCurrencyHelper::detect_current_currency();

		if ( isset( $apply_currency['currency'] ) ) {
			echo esc_html( $apply_currency['currency'] );
		}

		return ob_get_clean();

	}

	public function yay_get_current_symbol( $content = null ) {

		ob_start();

		$apply_currency = YayCurrencyHelper::detect_current_currency();

		if ( isset( $apply_currency['symbol'] ) ) {
			echo esc_html( $apply_currency['symbol'] );
		}

		return ob_get_clean();

	}

	public function get_cart_subtotal_by_shipping_fee( $apply_currency = false ) {
		$cart_subtotal = $apply_currency ? apply_filters( 'yay_currency_get_cart_subtotal', 0, $apply_currency ) : apply_filters( 'yay_currency_get_cart_subtotal_default', 0 );
		if ( WC()->cart->applied_coupons ) {
			$discount_total = apply_filters( 'yay_currency_get_discount_total', 0, $apply_currency );
			$cart_subtotal  = $cart_subtotal - $discount_total;
		}
		return $cart_subtotal;
	}

	public function yay_currency_calculate_fee( $atts ) {
		$atts = shortcode_atts(
			array(
				'percent' => '',
				'min_fee' => '',
				'max_fee' => '',
			),
			$atts,
			'yaycurrency-fee'
		);

		$apply_currency = YayCurrencyHelper::detect_current_currency();

		$atts['min_fee'] = YayCurrencyHelper::calculate_price_by_currency( $atts['min_fee'], true, $apply_currency );
		$atts['max_fee'] = YayCurrencyHelper::calculate_price_by_currency( $atts['max_fee'], true, $apply_currency );

		$cart_subtotal = $this->get_cart_subtotal_by_shipping_fee( $apply_currency );

		$calculated_fee = $this->get_fee_cost_by_shortcode( $cart_subtotal, $atts );

		return $calculated_fee;
	}

	public function yay_currency_calculate_fee_fallback( $atts ) {
		$atts               = shortcode_atts(
			array(
				'percent' => '',
				'min_fee' => '',
				'max_fee' => '',
			),
			$atts,
			'yaycurrency-fee-fallback'
		);
		$converted_currency = YayCurrencyHelper::converted_currency();
		$fallback_currency  = YayCurrencyHelper::get_fallback_currency( $converted_currency );

		$atts['min_fee'] = YayCurrencyHelper::calculate_price_by_currency( $atts['min_fee'], true, $fallback_currency );
		$atts['max_fee'] = YayCurrencyHelper::calculate_price_by_currency( $atts['max_fee'], true, $fallback_currency );

		$cart_subtotal = $this->get_cart_subtotal_by_shipping_fee( $fallback_currency );

		$calculated_fee = $this->get_fee_cost_by_shortcode( $cart_subtotal, $atts );

		return $calculated_fee;
	}

	public function yay_currency_calculate_fee_default( $atts ) {
		$atts           = shortcode_atts(
			array(
				'percent' => '',
				'min_fee' => '',
				'max_fee' => '',
			),
			$atts,
			'yaycurrency-fee-default'
		);
		$cart_subtotal  = $this->get_cart_subtotal_by_shipping_fee();
		$calculated_fee = $this->get_fee_cost_by_shortcode( $cart_subtotal, $atts );
		return $calculated_fee;
	}

	public function get_fee_cost_by_shortcode( $cart_subtotal, $atts ) {
		$calculated_fee = 0;

		if ( $atts['percent'] ) {
			$calculated_fee = $cart_subtotal * ( floatval( $atts['percent'] ) / 100 );
		}

		if ( $atts['min_fee'] && $calculated_fee < $atts['min_fee'] ) {
			$calculated_fee = $atts['min_fee'];
		}

		if ( $atts['max_fee'] && $calculated_fee > $atts['max_fee'] ) {
			$calculated_fee = $atts['max_fee'];
		}

		return $calculated_fee;
	}

}
