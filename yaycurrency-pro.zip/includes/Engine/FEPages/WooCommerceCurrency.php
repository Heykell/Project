<?php

namespace Yay_Currency\Engine\FEPages;

use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\SupportHelper;
use Yay_Currency\Helpers\FixedPriceHelper;
use Yay_Currency\Utils\SingletonTrait;

defined( 'ABSPATH' ) || exit;
class WooCommerceCurrency {
	use SingletonTrait;

	private $default_currency;
	private $converted_currency = array();
	private $apply_currency     = array();
	private $fallback_currency  = array();
	private $is_set_fixed_price;

	private $currencies_data = array();

	public function __construct() {
		add_action( 'init', array( $this, 'add_woocommerce_filters' ) );
	}

	public function add_woocommerce_filters() {
		$this->converted_currency = YayCurrencyHelper::converted_currency();
		$this->apply_currency     = YayCurrencyHelper::get_apply_currency( $this->converted_currency );
		$this->default_currency   = Helper::default_currency_code();
		$this->is_set_fixed_price = FixedPriceHelper::is_set_fixed_price();

		$is_dis_checkout_diff_currency = YayCurrencyHelper::is_dis_checkout_diff_currency( $this->apply_currency );
		$this->currencies_data         = YayCurrencyHelper::get_current_and_fallback_currency( $this->apply_currency, $this->converted_currency );
		$this->fallback_currency       = isset( $this->currencies_data['fallback_currency'] ) ? $this->currencies_data['fallback_currency'] : $this->apply_currency;
		if ( ! is_admin() ) {
			YayCurrencyHelper::set_cookies( $this->apply_currency );

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			if ( apply_filters( 'yay_currency_is_custom_price_html', $this->is_set_fixed_price ) ) {
				add_filter( 'woocommerce_get_price_html', array( $this, 'custom_fixed_price_string_single_product' ), 10, 2 );
				add_filter( 'woocommerce_variable_price_html', array( $this, 'custom_fixed_price_string_variable_product' ), 10, 2 );
				add_filter( 'woocommerce_grouped_price_html', array( $this, 'custom_fixed_price_string_grouped_product' ), 10, 3 );
			}

			$price_filters_priority = apply_filters( 'yay_currency_filters_priority', 10 );

			add_filter( 'woocommerce_product_get_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_product_get_regular_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_product_get_sale_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );

			add_filter( 'woocommerce_product_variation_get_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_product_variation_get_regular_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_product_variation_get_sale_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );

			add_filter( 'woocommerce_variation_prices_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_variation_prices_regular_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );
			add_filter( 'woocommerce_variation_prices_sale_price', array( $this, 'custom_raw_price' ), $price_filters_priority, 2 );

			add_filter( 'woocommerce_get_variation_prices_hash', array( $this, 'custom_variation_price_hash' ), $price_filters_priority, 1 );

			add_filter( 'woocommerce_available_payment_gateways', array( $this, 'conditional_payment_gateways' ), 10, 1 );
			add_action( 'woocommerce_before_mini_cart', array( $this, 'custom_mini_cart_price' ), 999 );

			// Filter to Coupon Min/Max
			add_filter( 'woocommerce_coupon_get_amount', array( $this, 'change_coupon_amount' ), 10, 2 );
			add_filter( 'woocommerce_coupon_get_minimum_amount', array( $this, 'change_coupon_amount' ), 10, 2 );
			add_filter( 'woocommerce_coupon_get_maximum_amount', array( $this, 'change_coupon_amount' ), 10, 2 );

			// Custom price fees
			add_action( 'woocommerce_cart_calculate_fees', array( $this, 'recalculate_cart_fees' ), 10, 1 );

			// WooCommerce Order
			add_action( 'woocommerce_checkout_create_order', array( $this, 'custom_checkout_create_order' ), 10, 2 );
			add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'custom_checkout_create_create_order_line_item' ), 10, 4 );
			add_action( 'woocommerce_checkout_create_order_shipping_item', array( $this, 'custom_checkout_create_order_shipping_item' ), 10, 4 );
			add_action( 'woocommerce_checkout_create_order_fee_item', array( $this, 'custom_checkout_create_order_fee_item' ), 10, 4 );
			add_action( 'woocommerce_checkout_create_order_tax_item', array( $this, 'custom_checkout_create_order_tax_item' ), 10, 3 );

			if ( $is_dis_checkout_diff_currency ) {
				add_action( 'woocommerce_before_checkout_form', array( $this, 'add_notice_checkout_payment_methods' ), 1000 );
				add_filter( 'woocommerce_cart_product_subtotal', array( $this, 'custom_checkout_product_subtotal' ), 10, 4 );
				add_filter( 'woocommerce_cart_subtotal', array( $this, 'custom_checkout_order_subtotal' ), 10, 3 );
				add_filter( 'woocommerce_cart_totals_coupon_html', array( $this, 'custom_discount_coupon' ), 10, 3 );
				add_filter( 'woocommerce_cart_shipping_method_full_label', array( $this, 'custom_shipping_fee' ), 10, 2 );
				add_filter( 'woocommerce_cart_totals_fee_html', array( $this, 'custom_cart_totals_fee_html' ), 10, 2 );
				add_filter( 'woocommerce_cart_tax_totals', array( $this, 'custom_total_tax' ), 10, 2 );
				add_filter( 'woocommerce_cart_totals_taxes_total_html', array( $this, 'custom_totals_taxes_total_html' ), 10, 1 );
				add_filter( 'woocommerce_cart_total', array( $this, 'custom_checkout_order_total' ) );
			}

			// Shipping Methods
			add_filter( 'transient_shipping-transient-version', array( $this, 'custom_transient_shipping_version' ), 10, 2 );
			add_filter( 'woocommerce_package_rates', array( $this, 'change_shipping_cost' ), 10, 2 );
			add_filter( 'woocommerce_shipping_local_pickup_instance_option', array( $this, 'woocommerce_shipping_local_pickup_instance_option' ), 10, 3 );
			// Free shipping with minimum amount
			add_filter( 'woocommerce_shipping_free_shipping_instance_option', array( $this, 'custom_free_shipping_min_amount' ), 20, 3 );
			add_filter( 'woocommerce_shipping_free_shipping_option', array( $this, 'custom_free_shipping_min_amount' ), 20, 3 );

			// Order Details in My Account
			add_filter( 'woocommerce_order_formatted_line_subtotal', array( $this, 'change_format_order_line_subtotal' ), 10, 3 );
			add_filter( 'woocommerce_get_order_item_totals', array( $this, 'change_format_order_item_totals' ), 10, 3 );
			add_filter( 'woocommerce_order_subtotal_to_display', array( $this, 'get_formatted_order_subtotal' ), 10, 3 );
			add_filter( 'woocommerce_order_shipping_to_display', array( $this, 'get_formatted_order_shipping' ), 10, 3 );
			add_filter( 'woocommerce_order_discount_to_display', array( $this, 'get_formatted_order_discount' ), 10, 2 );
			add_filter( 'woocommerce_get_formatted_order_total', array( $this, 'get_formatted_order_total' ), 10, 4 );
		}

	}

	public function is_original_default_currency() {
		$flag = apply_filters( 'yay_currency_is_original_default_currency', false, $this->apply_currency );
		return $flag;
	}

	public function is_fallback_currency() {
		if ( YayCurrencyHelper::checkout_in_fallback_currency( $this->apply_currency ) && ! YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) && $this->default_currency !== $this->currencies_data['fallback_currency']['currency'] ) {
			return true;
		}
		return false;
	}

	public function enqueue_scripts() {
		wp_register_script( 'yay-currency-frontend-script', YAY_CURRENCY_PLUGIN_URL . 'src/script.js', array(), YAY_CURRENCY_VERSION, true );
		wp_localize_script(
			'yay-currency-frontend-script',
			'yayCurrency',
			array(
				'admin_url'               => admin_url( 'admin.php?page=wc-settings' ),
				'ajaxurl'                 => admin_url( 'admin-ajax.php' ),
				'nonce'                   => wp_create_nonce( 'yay-currency-nonce' ),
				'isShowOnMenu'            => get_option( 'yay_currency_show_menu', 0 ),
				'shortCode'               => do_shortcode( '[yaycurrency-menu-item-switcher]' ),
				'isPolylangCompatible'    => get_option( 'yay_currency_polylang_compatible', 0 ),
				'isDisplayFlagInSwitcher' => get_option( 'yay_currency_show_flag_in_switcher', 1 ),
				'yayCurrencyPluginURL'    => YAY_CURRENCY_PLUGIN_URL,
				'converted_currency'      => $this->converted_currency,
			)
		);

		wp_enqueue_style(
			'yay-currency-frontend-style',
			YAY_CURRENCY_PLUGIN_URL . 'src/styles.css',
			array(),
			YAY_CURRENCY_VERSION
		);

		wp_enqueue_script( 'yay-currency-frontend-script' );

	}

	public function custom_fixed_price_string_single_product( $price, $product ) {

		if ( $this->default_currency === $this->apply_currency['currency'] ) {
			return $price;
		}

		$price = apply_filters( 'yay_currency_fixed_price_simple_product', $price, $product, $this->apply_currency );
		return $price;

	}

	public function custom_fixed_price_string_variable_product( $price, $product ) {

		if ( $this->default_currency === $this->apply_currency['currency'] ) {
			return $price;
		}

		$price = apply_filters( 'yay_currency_fixed_price_variable_product', $price, $product, $this->apply_currency );
		return $price;

	}

	public function custom_fixed_price_string_grouped_product( $price, $product, $child_prices ) {

		if ( $this->default_currency === $this->apply_currency['currency'] ) {
			return $price;
		}

		$price = apply_filters( 'yay_currency_fixed_price_grouped_product', $price, $product, $child_prices, $this->apply_currency );
		return $price;
	}

	public function custom_raw_price( $price, $product ) {

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {

			if ( $this->is_fallback_currency() ) {
				$price = apply_filters( 'yay_currency_get_price_fallback_in_checkout_page', $price, $product, $this->currencies_data['fallback_currency'] );
			} else {
				$price = apply_filters( 'yay_currency_get_price_default_in_checkout_page', $price, $product );
			}

			return $price;
		}

		if ( apply_filters( 'yay_currency_is_original_product_price', false, $price, $product ) ) {
			return $price;
		}

		// Fix for manual renewal subscription product and still keep old code works well
		if ( is_checkout() || is_cart() || wp_doing_ajax() ) {

			$price_with_conditions = apply_filters( 'yay_currency_get_price_with_conditions', $price, $product, $this->apply_currency );
			if ( $price_with_conditions ) {
				return $price_with_conditions;
			}

			$price_exist_class_plugins = apply_filters( 'yay_currency_get_price_except_class_plugins', $price, $product, $this->apply_currency );
			if ( $price_exist_class_plugins ) {
				return $price_exist_class_plugins;
			}

			$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );
			if ( $this->is_set_fixed_price ) {
				$fixed_price = FixedPriceHelper::get_price_fixed_by_apply_currency( $product, $price, $this->apply_currency );
				$price       = apply_filters( 'yay_currency_get_price_fixed_by_currency', $fixed_price, $product, $this->apply_currency, $price );
			}
			$price = apply_filters( 'yay_currency_get_price_by_currency', $price, $product, $this->apply_currency );
			return $price;
		}

		$price = YayCurrencyHelper::calculate_price_by_currency( $price, false, $this->apply_currency );

		// Fixed: Compare Min Max with Fixed Price Variable Product
		if ( $this->is_set_fixed_price && ! doing_filter( 'woocommerce_get_price_html' ) ) {
			$price = FixedPriceHelper::get_price_fixed_by_apply_currency( $product, $price, $this->apply_currency );
		}
		$price = apply_filters( 'yay_currency_get_price_by_currency', $price, $product, $this->apply_currency );
		return $price;

	}

	public function custom_variation_price_hash( $price_hash ) {
		$cookie_name = YayCurrencyHelper::get_cookie_name();
		if ( isset( $_COOKIE[ $cookie_name ] ) ) {
			$price_hash[] = (int) sanitize_key( $_COOKIE[ $cookie_name ] );
		}
		return $price_hash;
	}

	public function conditional_payment_gateways( $available_gateways ) {

		if ( ! $this->apply_currency ) {
			return $available_gateways;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) ) {
			$available_gateways = YayCurrencyHelper::filter_payment_methods_by_currency( $this->fallback_currency, $available_gateways );
			return $available_gateways;
		}

		$available_gateways = YayCurrencyHelper::filter_payment_methods_by_currency( $this->apply_currency, $available_gateways );
		$available_gateways = apply_filters( 'yay_currency_available_gateways', $available_gateways, $this->apply_currency );
		return $available_gateways;
	}

	public function custom_mini_cart_price() {
		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || is_cart() || is_checkout() ) {
			return false;
		}
		WC()->cart->calculate_totals();
	}

	public function change_coupon_amount( $price, $coupon ) {

		if ( $coupon->is_type( array( 'percent' ) ) ) {
			return $price;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
			// Fallback Currency
			if ( $this->is_fallback_currency() ) {
				$price = apply_filters( 'yay_currency_get_coupon_amount_fallback_currency', $price, $this->currencies_data['fallback_currency'] );
			}
			return $price;
		}

		$converted_coupon_price = YayCurrencyHelper::calculate_price_by_currency( $price, true, $this->apply_currency );
		$converted_coupon_price = apply_filters( 'yay_currency_coupon_get_amount', $converted_coupon_price, $coupon, $this->apply_currency );

		return $converted_coupon_price;

	}

	public function recalculate_cart_fees( $cart ) {

		if ( ! apply_filters( 'yay_currency_is_cart_fees_original', true, $this->apply_currency ) ) {
			return;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
			if ( $this->is_fallback_currency() ) {
				apply_filters( 'yay_currency_recalculate_cart_fees_fallback_currency', $cart, $this->currencies_data['fallback_currency'] );
			}
			return;
		}

		foreach ( $cart->get_fees() as $fee ) {
			$amount      = YayCurrencyHelper::calculate_price_by_currency( $fee->amount, true, $this->apply_currency );
			$fee->amount = $amount;
		}
	}

	public function custom_checkout_create_order( $order, $data ) {
		// Fallback Currency
		if ( $this->is_fallback_currency() ) {
			do_action( 'yay_currency_create_order_fallback_currency', $order, $data, $this->fallback_currency );
		} else {
			$current_currency = $this->currencies_data['current_currency'];
			if ( 0 == $current_currency['status'] && YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return;
			}
			do_action( 'yay_currency_set_order_original_total', $order, $data, $this->default_currency, $this->fallback_currency, $current_currency );
		}
	}

	public function custom_checkout_create_create_order_line_item( $item, $cart_item_key, $values, $order ) {
		if ( $this->is_fallback_currency() ) {
			do_action( 'yay_currency_create_create_order_line_item_fallback_currency', $item, $cart_item_key, $values, $order, $this->fallback_currency );
		}
	}

	public function custom_checkout_create_order_shipping_item( $item, $package_key, $package, $order ) {
		if ( $this->is_fallback_currency() ) {
			do_action( 'yay_currency_create_order_shipping_item_fallback_currency', $item, $package_key, $package, $order, $this->fallback_currency );
		}

	}

	public function custom_checkout_create_order_fee_item( $item, $fee_key, $fee, $order ) {
		if ( $this->is_fallback_currency() ) {
			do_action( 'yay_currency_create_order_fee_item_fallback_currency', $item, $fee_key, $fee, $order, $this->fallback_currency );
		}

	}

	public function custom_checkout_create_order_tax_item( $item, $tax_rate_id, $order ) {
		if ( $this->is_fallback_currency() ) {
			if ( $tax_rate_id && apply_filters( 'woocommerce_cart_remove_taxes_zero_rate_id', 'zero-rated' ) !== $tax_rate_id ) {
				do_action( 'yay_currency_create_order_tax_item_fallback_currency', $item, $tax_rate_id, $order, $this->fallback_currency );
			}
		}

	}

	public function add_notice_checkout_payment_methods() {

		$notice_payment_methods = apply_filters( 'yay_currency_checkout_notice_payment_methods', true, $this->apply_currency );

		if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) || ! $notice_payment_methods ) {
			return;
		}

		do_action( 'yay_currency_before_notice_checkout_payment_methods', $this->currencies_data );

		do_action( 'yay_currency_notice_checkout_payment_methods', $this->currencies_data, Helper::get_current_theme() );

		do_action( 'yay_currency_after_notice_checkout_payment_methods', $this->currencies_data );

	}

	public function custom_checkout_product_subtotal( $product_subtotal, $product, $quantity, $cart ) {
		if ( is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $product_subtotal;
			}
			$fallback_product_price    = $product->get_price();
			$product_price             = apply_filters( 'yay_currency_get_product_price_default_currency', $fallback_product_price, $product, 1 );
			$original_product_subtotal = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $product_price, $quantity );
			$original_product_subtotal = apply_filters( 'yay_currency_get_original_product_subtotal', $original_product_subtotal, $product_price, $product, $quantity, $this->fallback_currency );
			$converted_approximately   = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			if ( ! $converted_approximately ) {
				return $original_product_subtotal;
			}
			$product_price                   = YayCurrencyHelper::calculate_price_by_currency( $fallback_product_price, false, $this->apply_currency );
			$product_price                   = apply_filters( 'yay_currency_get_product_price_apply_currency', $product_price, $product, 1 );
			$converted_product_subtotal      = YayCurrencyHelper::get_formatted_total_by_convert_currency( $product_price * $quantity, $this->apply_currency, $this->apply_currency['currency'] );
			$converted_product_subtotal      = apply_filters( 'yay_currency_checkout_converted_product_subtotal_fixed', $converted_product_subtotal, $product, $this->apply_currency, $quantity );
			$converted_product_subtotal_html = YayCurrencyHelper::converted_approximately_html( $converted_product_subtotal );
			$product_subtotal                = $original_product_subtotal . $converted_product_subtotal_html;
		}
		return $product_subtotal;
	}

	public function custom_checkout_order_subtotal( $price ) {
		if ( is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $price;
			}

			$subtotal_price          = apply_filters( 'yay_currency_checkout_get_subtotal_price', (float) WC()->cart->get_displayed_subtotal(), $this->apply_currency );
			$original_subtotal       = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $subtotal_price );
			$original_subtotal       = apply_filters( 'yay_currency_get_original_cart_subtotal', $original_subtotal, $this->fallback_currency );
			$converted_approximately = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			if ( ! $converted_approximately ) {
				return $original_subtotal;
			}
			$converted_subtotal              = YayCurrencyHelper::calculate_price_by_currency_html( $this->currencies_data['current_currency'], $subtotal_price );
			$converted_subtotal              = apply_filters( 'yay_currency_checkout_converted_subtotal_fixed', $converted_subtotal, $this->apply_currency );
			$converted_product_subtotal_html = YayCurrencyHelper::converted_approximately_html( $converted_subtotal );
			$price                           = $original_subtotal . $converted_product_subtotal_html;
		}
		return $price;
	}

	public function custom_discount_coupon( $coupon_html, $coupon, $discount_amount_html ) {
		if ( is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $coupon_html;
			}

			$discount_type   = $coupon->get_discount_type();
			$discount_amount = (float) $coupon->get_amount();

			if ( 'percent' !== $discount_type ) {
				$custom_coupon_html = apply_filters( 'yay_currency_checkout_formatted_fixed_cart_or_product_discount_price', $this->currencies_data, $coupon, $coupon_html, $discount_type, $discount_amount );
			} else {
				$custom_coupon_html = apply_filters( 'yay_currency_checkout_formatted_percent_discount_price', $this->currencies_data, $coupon, $coupon_html, $discount_amount );
			}
			return $custom_coupon_html;
		}
		return $coupon_html;
	}

	public function custom_shipping_fee( $label, $method ) {
		if ( is_checkout() ) {

			if ( 'free_shipping' === $method->method_id || YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $label;
			}

			$shipping_fee           = (float) $method->cost;
			$shipping_fee           = apply_filters( 'yay_currency_recalculate_shipping_fee_incl_tax', $shipping_fee, $method, $this->fallback_currency );
			$converted_shipping_fee = YayCurrencyHelper::calculate_price_by_currency( $shipping_fee, true, $this->apply_currency );
			$formatted_shipping_fee = YayCurrencyHelper::format_price( $converted_shipping_fee );
			$shipping_method_label  = $method->label;

			$formatted_fallback_currency_shipping_fee = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $shipping_fee );
			$formatted_fallback_currency_shipping_fee = apply_filters( 'yay_currency_get_fallback_currency_shipping_fee', $formatted_fallback_currency_shipping_fee, $shipping_fee, $method, $this->fallback_currency );
			$converted_approximately                  = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			if ( ! $converted_approximately ) {
				return '' . $shipping_method_label . ': ' . $formatted_fallback_currency_shipping_fee;
			}

			$formatted_shipping_fee      = apply_filters( 'yay_currency_formatted_shipping_flat_rate_fee', $formatted_shipping_fee, $method, $this->apply_currency );
			$formatted_shipping_fee_html = YayCurrencyHelper::converted_approximately_html( $formatted_shipping_fee );
			$label                       = '' . $shipping_method_label . ': ' . $formatted_fallback_currency_shipping_fee . $formatted_shipping_fee_html;
		}
		return $label;
	}

	public function custom_cart_totals_fee_html( $cart_totals_fee_html, $fee ) {
		if ( is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $cart_totals_fee_html;
			}

			$converted_approximately = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			$fee_amount              = $fee->amount;
			$fee_amount              = apply_filters( 'yay_currency_recalculate_fee_incl_tax', $fee_amount, $fee );
			$fee_amount_html         = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $fee_amount );
			$fee_amount_html         = apply_filters( 'yay_currency_get_fee_amount_html', $fee_amount_html, $fee_amount, $this->fallback_currency );
			if ( ! $converted_approximately ) {
				return $fee_amount_html;
			}

			$convert_fee_amount      = YayCurrencyHelper::calculate_price_by_currency( $fee_amount, true, $this->apply_currency );
			$convert_fee_amount_html = YayCurrencyHelper::format_price( $convert_fee_amount );

			$cart_totals_fee_html = $fee_amount_html . YayCurrencyHelper::converted_approximately_html( $convert_fee_amount_html );
		}
		return $cart_totals_fee_html;
	}

	public function custom_total_tax( $tax_display ) {
		if ( count( $tax_display ) > 0 && is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $tax_display;
			}
			$converted_approximately = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			foreach ( $tax_display as $tax_info ) {
				$tax_amount                 = $tax_info->amount;
				$fallback_tax_amount        = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $tax_amount );
				$fallback_tax_amount        = apply_filters( 'yay_currency_get_fallback_tax_amount', $fallback_tax_amount, $tax_amount, $tax_info->tax_rate_id, $this->fallback_currency );
				$tax_info->formatted_amount = $fallback_tax_amount;
				if ( $converted_approximately ) {
					$converted_tax_amount                = YayCurrencyHelper::calculate_price_by_currency( $tax_amount, true, $this->apply_currency );
					$formatted_converted_tax_amount      = YayCurrencyHelper::format_price( $converted_tax_amount );
					$formatted_converted_tax_amount      = apply_filters( 'yay_currency_checkout_converted_total_tax_fixed', $formatted_converted_tax_amount, $tax_info->tax_rate_id, $this->apply_currency );
					$formatted_converted_tax_amount_html = YayCurrencyHelper::converted_approximately_html( $formatted_converted_tax_amount, true );
					$tax_info->formatted_amount         .= $formatted_converted_tax_amount_html;
				}
			}
		}
		return $tax_display;
	}

	public function custom_totals_taxes_total_html( $taxes_total_html ) {
		if ( is_checkout() ) {
			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $taxes_total_html;
			}
			$converted_approximately = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			$taxes_total             = WC()->cart->get_taxes_total();
			$taxes_total_html        = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $taxes_total );
			$taxes_total_html        = apply_filters( 'yay_currency_get_taxes_total_html', $taxes_total_html, $taxes_total, $this->fallback_currency );
			if ( ! $converted_approximately ) {
				return $taxes_total_html;
			}
			$converted_taxes_total_html = YayCurrencyHelper::calculate_price_by_currency_html( $this->apply_currency, $taxes_total );
			$converted_taxes_total_html = apply_filters( 'yay_currency_checkout_converted_taxes_total_fixed', $converted_taxes_total_html, $this->apply_currency );
			$converted_taxes_total_html = YayCurrencyHelper::converted_approximately_html( $converted_taxes_total_html, true );
			$taxes_total_html           = $taxes_total_html . $converted_taxes_total_html;
		}
		return $taxes_total_html;
	}

	public function custom_checkout_order_total( $price ) {
		if ( is_checkout() ) {

			if ( YayCurrencyHelper::is_current_fallback_currency( $this->currencies_data ) ) {
				return $price;
			}

			$total_price    = apply_filters( 'yay_currency_checkout_get_total_price', (float) WC()->cart->total );
			$original_total = YayCurrencyHelper::calculate_price_by_currency_html( $this->fallback_currency, $total_price );
			$original_total = apply_filters( 'yay_currency_get_original_cart_total', $original_total, $total_price, $this->fallback_currency );

			$converted_approximately = apply_filters( 'yay_currency_checkout_converted_approximately', true, $this->apply_currency );
			if ( ! $converted_approximately ) {
				return $original_total;
			}
			$converted_total          = YayCurrencyHelper::calculate_price_by_currency_html( $this->currencies_data['current_currency'], $total_price );
			$enable_fallback_currency = $this->default_currency !== $this->currencies_data['fallback_currency']['currency'];
			$converted_total          = apply_filters( 'yay_currency_checkout_converted_total_fixed', $converted_total, $this->apply_currency, $enable_fallback_currency );
			$converted_total_html     = YayCurrencyHelper::converted_approximately_html( $converted_total, true );
			$price                    = $original_total . $converted_total_html;
		}
		return $price;
	}

	public function custom_transient_shipping_version( $value, $transient ) {
		$value = false;
		return $value;
	}

	public function woocommerce_shipping_local_pickup_instance_option( $value, $key, $shipping ) {

		if ( 'cost' !== $key ) {
			return $value;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
			if ( $this->is_original_default_currency() && $this->is_fallback_currency() ) {
				$value = YayCurrencyHelper::calculate_price_by_currency( $value, true, $this->fallback_currency );
			}
		}

		return $value;
	}

	// Shipping
	public function change_shipping_cost( $methods, $package ) {

		if ( apply_filters( 'yay_currency_is_original_shipping_cost', false, $this->apply_currency ) ) {
			return $methods;
		}

		if ( count( array_filter( $methods ) ) ) {
			$shipping_methods_args = array( 'betrs_shipping', 'printful_shipping', 'easyship', 'printful_shipping_STANDARD', 'shipmondo' );

			foreach ( $methods as $key => $method ) {
				$shipping_method_id = $method->method_id;
				if ( in_array( $shipping_method_id, $shipping_methods_args, true ) ) {
					continue;
				}
				if ( 'flat_rate' == $shipping_method_id ) {
					$shipping = new \WC_Shipping_Flat_Rate( $method->instance_id );
					// Calculate the costs.
					$rate          = array(
						'id'      => $method->id,
						'label'   => $method->label,
						'cost'    => 0,
						'package' => $package,
					);
					$has_fee_costs = false; // True when a cost is set. False if all costs are blank strings.
					$cost          = $shipping->get_option( 'cost' );

					if ( ! empty( $cost ) && ! is_numeric( $cost ) ) {
						$has_fee_costs         = true;
						$package_contents_cost = $package['contents_cost'];
						$calculate_default     = false;
						$is_fallback           = false;
						if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
							if ( $this->is_original_default_currency() && $this->is_fallback_currency() ) {
								$package_contents_cost = apply_filters( 'yay_currency_get_cart_subtotal', 0, $this->currencies_data['fallback_currency'] );
								$is_fallback           = true;
							} else {
								$package_contents_cost = apply_filters( 'yay_currency_get_cart_subtotal_default', 0 );
								$calculate_default     = true;
							}
						}

						$rate['cost'] = SupportHelper::evaluate_cost(
							$cost,
							array(
								'qty'  => $shipping->get_package_item_qty( $package ),
								'cost' => $package_contents_cost,
							),
							$calculate_default,
							$is_fallback
						);
					}

					$shipping_classes = WC()->shipping->get_shipping_classes();

					if ( ! empty( $shipping_classes ) ) {
						$product_shipping_classes = $shipping->find_shipping_classes( $package );
						$shipping_classes_cost    = 0;

						foreach ( $product_shipping_classes as $shipping_class => $products ) {
							$shipping_class_term = get_term_by( 'slug', $shipping_class, 'product_shipping_class' );
							$class_cost_string   = $shipping_class_term && $shipping_class_term->term_id ? $shipping->get_option( 'class_cost_' . $shipping_class_term->term_id, $shipping->get_option( 'class_cost_' . $shipping_class, '' ) ) : $shipping->get_option( 'no_class_cost', '' );

							if ( '' === $class_cost_string ) {
								continue;
							}
							if ( ! empty( $class_cost_string ) && ! is_numeric( $class_cost_string ) ) {
								$has_fee_costs = true;
								$class_cost    = SupportHelper::evaluate_cost(
									$class_cost_string,
									array(
										'qty'  => array_sum( wp_list_pluck( $products, 'quantity' ) ),
										'cost' => array_sum( wp_list_pluck( $products, 'line_total' ) ),
									)
								);
							} else {
								$class_cost = $class_cost_string;
							}

							if ( 'class' === $shipping->type ) {
								$rate['cost'] += $class_cost;
							} else {
								$shipping_classes_cost = $class_cost > $shipping_classes_cost ? $class_cost : $shipping_classes_cost;
							}
						}

						if ( 'order' === $shipping->type && $shipping_classes_cost ) {
							$rate['cost'] += $shipping_classes_cost;
						}
					}

					if ( $has_fee_costs ) {
						$method->set_cost( $rate['cost'] );
					} else {
						if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
							if ( $this->is_original_default_currency() && $this->is_fallback_currency() ) {
								$rate_cost = YayCurrencyHelper::calculate_price_by_currency( $cost, true, $this->fallback_currency );
								// $rate_cost = apply_filters( 'yay_currency_recalculate_shipping_fee_incl_tax', $rate_cost, $method, $this->fallback_currency );
							} else {
								$rate_cost = $cost;
								// if ( $this->is_original_default_currency() && ! $this->is_fallback_currency() ) {
								// 	$rate_cost = apply_filters( 'yay_currency_recalculate_shipping_fee_incl_tax', $rate_cost, $method, false );
								// }
							}
							$rate['cost'] = apply_filters( 'yay_currency_get_original_shipping_cost', $rate_cost, $this->apply_currency );
							$method->set_cost( $rate['cost'] );
						} else {
							$rate['cost'] = YayCurrencyHelper::calculate_price_by_currency( $cost, true, $this->apply_currency );
							$method->set_cost( $rate['cost'] );
						}
					}
				} else {
					$special_shipping_methods = array( 'per_product', 'tree_table_rate' );
					if ( in_array( $method->method_id, $special_shipping_methods ) ) {
						if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
							return $methods;
						}
						$method->cost = YayCurrencyHelper::calculate_price_by_currency( $method->cost, true, $this->apply_currency );
						return $methods;
					}
					if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
						return $methods;
					}
					$data = get_option( 'woocommerce_' . $method->method_id . '_' . $method->instance_id . '_settings' );
					$method->set_cost( isset( $data['cost'] ) ? YayCurrencyHelper::calculate_price_by_currency( $data['cost'], true, $this->apply_currency ) : YayCurrencyHelper::calculate_price_by_currency( $method->get_cost(), true, $this->apply_currency ) );
				}

				// Set tax for shipping method
				if ( count( $method->get_taxes() ) > 0 ) {
					$apply_currency = $this->apply_currency;
					if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
						if ( ! $this->is_fallback_currency() ) {
							return $methods;
						} else {
							$apply_currency = $this->fallback_currency;
						}
					}
					$tax_new = array();
					foreach ( $method->get_taxes() as $key => $tax ) {
						$tax_currency = YayCurrencyHelper::calculate_price_by_currency( $tax, true, $apply_currency );
						if ( 'flat_rate' == $method->method_id && isset( $cost ) && ! is_numeric( $cost ) ) {
							$tax_calculate   = \WC_Tax::calc_shipping_tax( $rate['cost'], \WC_Tax::get_shipping_tax_rates() );
							$tax_new[ $key ] = is_array( $tax_calculate ) ? array_sum( $tax_calculate ) : $tax_currency;
						} else {
							$tax_new[ $key ] = $tax_currency;
						}
					}
					$method->set_taxes( $tax_new );
				}
			}
		}

		return $methods;
	}

	public function custom_free_shipping_min_amount( $option, $key, $method ) {

		if ( 'min_amount' !== $key || ! is_numeric( $option ) ) {
			return $option;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $this->apply_currency ) || $this->is_original_default_currency() ) {
			if ( $this->is_original_default_currency() && $this->is_fallback_currency() ) {
				$option = YayCurrencyHelper::calculate_price_by_currency( $option, true, $this->fallback_currency );
			}
			return $option;
		}

		$option = YayCurrencyHelper::calculate_price_by_currency( $option, true, $this->apply_currency );
		return $option;
	}

	// Change currency when send mail start

	public function change_format_order_item_totals( $total_rows, $order, $tax_display ) {

		if ( apply_filters( 'yay_currency_is_original_format_order_item_totals', false, $total_rows, $order, $tax_display ) ) {
			return $total_rows;
		}

		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );
		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			// Fee
			$fees = $order->get_fees();
			if ( $fees ) {
				foreach ( $fees as $id => $fee ) {
					if ( apply_filters( 'woocommerce_get_order_item_totals_excl_free_fees', empty( $fee['line_total'] ) && empty( $fee['line_tax'] ), $id ) ) {
						continue;
					}
					$price_format                          = 'excl' === $tax_display ? $fee->get_total() : $fee->get_total() + $fee->get_total_tax();
					$total_rows[ 'fee_' . $fee->get_id() ] = array(
						'label' => $fee->get_name() . ':',
						'value' => YayCurrencyHelper::get_formatted_total_by_convert_currency( $price_format, $convert_currency, $yay_currency_checkout_currency ),
					);

				}
			}
			// Tax for tax exclusive prices.
			if ( 'excl' === $tax_display && wc_tax_enabled() ) {
				if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
					foreach ( $order->get_tax_totals() as $code => $tax ) {
						$formatted_tax_amount                  = YayCurrencyHelper::get_formatted_total_by_convert_currency( $tax->amount, $convert_currency, $yay_currency_checkout_currency );
						$total_rows[ sanitize_title( $code ) ] = array(
							'label' => $tax->label . ':',
							'value' => $formatted_tax_amount, // $tax->formatted_amount
						);
					}
				} else {
					$total_rows['tax'] = array(
						'label' => WC()->countries->tax_or_vat() . ':',
						'value' => YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_total_tax(), $convert_currency, $yay_currency_checkout_currency ),
					);
				}
			}
			// Refund
			if ( method_exists( $order, 'get_refunds' ) ) {
				$refunds = $order->get_refunds();
				if ( $refunds ) {
					foreach ( $refunds as $id => $refund ) {
						$total_rows[ 'refund_' . $id ] = array(
							'label' => $refund->get_reason() ? $refund->get_reason() : __( 'Refund', 'woocommerce' ) . ':',
							'value' => YayCurrencyHelper::get_formatted_total_by_convert_currency( '-' . $refund->get_amount(), $convert_currency, $yay_currency_checkout_currency ),
						);
					}
				}
			}
		}
		return $total_rows;
	}

	public function change_format_order_line_subtotal( $subtotal, $item, $order ) {

		if ( ! apply_filters( 'yay_currency_is_change_format_order_line_subtotal', true, $subtotal, $item, $order ) ) {
			return $subtotal;
		}

		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );
		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			$tax_display      = get_option( 'woocommerce_tax_display_cart' );
			if ( 'excl' === $tax_display ) {
				$ex_tax_label = $order->get_prices_include_tax() ? 1 : 0;
				$subtotal     = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_line_subtotal( $item ), $convert_currency, $yay_currency_checkout_currency, $ex_tax_label );
			} else {
				$subtotal = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_line_subtotal( $item, true ), $convert_currency, $yay_currency_checkout_currency );
			}
		}
		return $subtotal;
	}

	public function get_formatted_order_subtotal( $subtotal, $compound, $order ) {
		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );
		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			$tax_display      = get_option( 'woocommerce_tax_display_cart' );
			$subtotal         = YayCurrencyHelper::get_cart_subtotal_for_order( $order );

			if ( ! $compound ) {
				if ( 'incl' === $tax_display ) {
					$subtotal_taxes = 0;
					foreach ( $order->get_items() as $item ) {
						$subtotal_taxes += YayCurrencyHelper::round_line_tax( $item->get_subtotal_tax(), false );
					}
					$subtotal += wc_round_tax_total( $subtotal_taxes );
				}
				$subtotal = YayCurrencyHelper::get_formatted_total_by_convert_currency( $subtotal, $convert_currency, $yay_currency_checkout_currency );
				if ( 'excl' === $tax_display && $order->get_prices_include_tax() && wc_tax_enabled() ) {
					$subtotal .= ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
				}
			} else {
				if ( 'incl' === $tax_display ) {
					return '';
				}
				// Add Shipping Costs.
				$subtotal += $order->get_shipping_total();
				// Remove non-compound taxes.
				foreach ( $order->get_taxes() as $tax ) {
					if ( $tax->is_compound() ) {
						continue;
					}
					$subtotal = $subtotal + $tax->get_tax_total() + $tax->get_shipping_tax_total();
				}
				// Remove discounts.
				$subtotal = $subtotal - $order->get_total_discount();
				$subtotal = YayCurrencyHelper::get_formatted_total_by_convert_currency( $subtotal, $convert_currency, $yay_currency_checkout_currency );
			}
		}
		return $subtotal;
	}

	public function get_formatted_order_shipping( $shipping, $order, $tax_display ) {
		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );
		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			$tax_display      = $tax_display ? $tax_display : get_option( 'woocommerce_tax_display_cart' );

			if ( 0 < abs( (float) $order->get_shipping_total() ) ) {
				if ( 'excl' === $tax_display ) {
					// Show shipping excluding tax.
					$shipping = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_shipping_total(), $convert_currency, $yay_currency_checkout_currency );
					if ( (float) $order->get_shipping_tax() > 0 && $order->get_prices_include_tax() ) {
						$shipping .= apply_filters( 'woocommerce_order_shipping_to_display_tax_label', '&nbsp;<small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>', $order, $tax_display );
					}
				} else {
					// Show shipping including tax.
					$shipping = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_shipping_total() + $order->get_shipping_tax(), $convert_currency, $yay_currency_checkout_currency );
					if ( (float) $order->get_shipping_tax() > 0 && ! $order->get_prices_include_tax() ) {
						$shipping .= apply_filters( 'woocommerce_order_shipping_to_display_tax_label', '&nbsp;<small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>', $order, $tax_display );
					}
				}
				/* translators: %s: method */
				$shipping .= apply_filters( 'woocommerce_order_shipping_to_display_shipped_via', '&nbsp;<small class="shipped_via">' . sprintf( __( 'via %s', 'woocommerce' ), $order->get_shipping_method() ) . '</small>', $order );
			} elseif ( $order->get_shipping_method() ) {
				$shipping = $order->get_shipping_method();
			} else {
				$shipping = __( 'Free!', 'woocommerce' );
			}
		}
		return $shipping;
	}

	public function get_formatted_order_discount( $tax_display, $order ) {
		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );
		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			$price_format     = $order->get_total_discount();
			$discount         = YayCurrencyHelper::get_formatted_total_by_convert_currency( $price_format, $convert_currency, $yay_currency_checkout_currency );
		}
		return $discount;
	}

	public function get_formatted_order_total( $formatted_total, $order, $tax_display, $display_refunded ) {

		$total_refunded = $order->get_total_refunded();

		if ( $total_refunded && $display_refunded ) {
			return $formatted_total;
		}

		$yay_currency_checkout_currency = YayCurrencyHelper::get_currency_code_by_order( $order );

		if ( ! empty( $yay_currency_checkout_currency ) ) {
			$convert_currency = YayCurrencyHelper::get_convert_currency_by_checkout_currency( $this->converted_currency, $this->apply_currency, $yay_currency_checkout_currency );
			if ( ! $convert_currency ) {
				return $formatted_total;
			}

			$total = YayCurrencyHelper::get_total_by_order( $order );

			$formatted_total = YayCurrencyHelper::get_formatted_total_by_convert_currency( $total, $convert_currency, $yay_currency_checkout_currency );

			if ( wc_tax_enabled() && 'incl' === $tax_display ) {
				$formatted_tax   = YayCurrencyHelper::get_formatted_total_by_convert_currency( $order->get_total_tax(), $convert_currency, $yay_currency_checkout_currency );
				$formatted_total = $formatted_total . ' (includes ' . $formatted_tax . ' Tax)';
			}
		}

		return $formatted_total;

	}

}
