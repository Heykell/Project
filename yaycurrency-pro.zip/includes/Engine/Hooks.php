<?php
namespace Yay_Currency\Engine;

use Yay_Currency\Utils\SingletonTrait;
use Yay_Currency\Helpers\Helper;
use Yay_Currency\Helpers\YayCurrencyHelper;
use Yay_Currency\Helpers\SupportHelper;

defined( 'ABSPATH' ) || exit;

class Hooks {
	use SingletonTrait;

	public function __construct() {
		// ADD FILTER PRIORITY
		add_filter( 'yay_currency_filters_priority', array( $this, 'get_filters_priority' ), 9, 1 );

		// GET CURRENCY RATE
		add_filter( 'yay_currency_rate', array( $this, 'get_yay_currency_rate' ), 10, 1 );

		// ADD FILTER GET PRICE WITH CONDITIONS
		add_filter( 'yay_currency_get_price_with_conditions', array( $this, 'get_price_with_conditions' ), 10, 3 );
		add_filter( 'yay_currency_get_price_except_class_plugins', array( $this, 'get_price_except_class_plugins' ), 10, 3 );

		// CUSTOM FIXED PRODUCT PRICE HTML
		add_filter( 'yay_currency_fixed_price_simple_product', array( $this, 'custom_fixed_price_simple_product' ), 10, 3 );
		add_filter( 'yay_currency_fixed_price_variable_product', array( $this, 'custom_fixed_price_variable_product' ), 10, 3 );
		add_filter( 'yay_currency_fixed_price_grouped_product', array( $this, 'custom_fixed_price_grouped_product' ), 10, 4 );

		add_filter( 'woocommerce_stripe_request_body', array( $this, 'custom_stripe_request_total_amount' ), 10, 2 );

		// KEEP ORIGINAL PRODUCT PRICE, CART FEE, ORDER TOTALS
		add_filter( 'yay_currency_is_original_product_price', array( $this, 'is_original_product_price' ), 10, 3 );
		add_filter( 'yay_currency_is_cart_fees_original', array( $this, 'is_cart_fees_original' ), 10, 2 );
		add_filter( 'yay_currency_is_original_format_order_item_totals', array( $this, 'is_original_format_order_item_totals' ), 10, 4 );

		// CALCULATE TOTAL: CART SUBTOTAL, CART TOTAL --- DEFAULT CURRENCY
		add_filter( 'yay_currency_get_cart_subtotal_default', array( $this, 'calculate_cart_subtotal_default' ), 10, 1 );
		add_filter( 'yay_currency_get_cart_total_default', array( $this, 'calculate_cart_total_default' ), 10, 1 );

		// CALCULATE TOTAL BY CURRENCY : PRICE, SUBTOTAL, DISCOUNT, SHIPPING, FEE, TAX, CART TOTAL,
		add_filter( 'yay_currency_get_cart_item_price', array( $this, 'get_cart_item_price' ), 10, 3 );
		add_filter( 'yay_currency_get_cart_subtotal', array( $this, 'get_cart_subtotal' ), 10, 2 );
		add_filter( 'yay_currency_get_discount_total', array( $this, 'calculate_discount_total' ), 10, 2 );
		add_filter( 'yay_currency_get_shipping_total', array( $this, 'calculate_shipping_total' ), 10, 3 );
		add_filter( 'yay_currency_get_fee_total', array( $this, 'calculate_fee_total' ), 10, 2 );
		add_filter( 'yay_currency_get_total_tax', array( $this, 'calculate_total_tax' ), 10, 2 );
		add_filter( 'yay_currency_get_cart_total', array( $this, 'calculate_cart_total' ), 10, 3 );

		// TAX
		add_filter( 'yay_currency_is_recalculate_tax', array( $this, 'is_recalculate_tax' ), 10, 1 );
		add_filter( 'yay_currency_is_custom_price_html', array( $this, 'is_custom_price_html' ), 10, 1 );

		// RELATED WITH ORDER
		add_action( 'yay_currency_set_order_original_total', array( $this, 'custom_set_order_original_total' ), 10, 5 );
		add_action( 'yay_currency_create_order_fallback_currency', array( $this, 'custom_checkout_create_order_fallback_currency' ), 10, 3 );
		add_action( 'yay_currency_create_create_order_line_item_fallback_currency', array( $this, 'create_create_order_line_item_fallback_currency' ), 10, 5 );
		add_action( 'yay_currency_create_order_shipping_item_fallback_currency', array( $this, 'create_order_shipping_item_fallback_currency' ), 10, 5 );
		add_action( 'yay_currency_create_order_fee_item_fallback_currency', array( $this, 'create_order_fee_item_fallback_currency' ), 10, 5 );
		add_action( 'yay_currency_create_order_tax_item_fallback_currency', array( $this, 'custom_order_tax_item_fallback_currency' ), 10, 4 );

		// ACTION - HOOKS
		add_action( 'yay_currency_redirect_to_url', array( $this, 'yay_currency_redirect_to_url' ), 10, 2 );
		add_action( 'yay_currency_notice_checkout_payment_methods', array( $this, 'add_notice_checkout_payment_methods' ), 10, 2 );
	}

	public function get_filters_priority( $priority ) {

		// Compatible with B2B Wholesale Suite, Price by Country, B2BKing
		if ( class_exists( 'B2bwhs' ) || class_exists( 'CBP_Country_Based_Price' ) || class_exists( 'B2bkingcore' ) ) {
			$priority = 100000;
		}

		return $priority;

	}

	public function get_yay_currency_rate( $rate = 1 ) {
		$apply_currency = YayCurrencyHelper::detect_current_currency();
		$rate           = YayCurrencyHelper::get_rate_fee( $apply_currency );
		return $rate;
	}

	public function get_price_with_conditions( $price, $product, $apply_currency ) {
		// YayExtra , YayPricing

		$is_ydp_adjust_price = false;
		$calculate_price     = YayCurrencyHelper::calculate_price_by_currency( $price, false, $apply_currency );

		if ( class_exists( '\YayPricing\FrontEnd\ProductPricing' ) ) {
			$is_ydp_adjust_price = apply_filters( 'ydp_check_adjust_price', false );
		}

		if ( class_exists( '\YayPricing\FrontEnd\ProductPricing' ) && $is_ydp_adjust_price ) {
			return $calculate_price;
		}

		$price_3rd_plugin = apply_filters( 'yay_currency_product_price_3rd_with_condition', false, $product );
		return $price_3rd_plugin;

	}

	public function get_price_except_class_plugins( $price, $product, $apply_currency ) {
		if ( class_exists( '\BM_Conditionals' ) ) {
			$group_id = \BM_Conditionals::get_validated_customer_group();
			if ( false !== $group_id ) {
				return $price;
			}
		}
		$calculate_price      = YayCurrencyHelper::calculate_price_by_currency( $price, false, $apply_currency );
		$except_class_plugins = array(
			'WC_Measurement_Price_Calculator',
			'WCPA', // Woocommerce Custom Product Addons
			'\Acowebs\WCPA\Main', // Woocommerce Custom Product Addons
			'WoonpCore', // Name Your Price for WooCommerce
			'Webtomizer\\WCDP\\WC_Deposits', // WooCommerce Deposits
			'\WC_Product_Price_Based_Country', // Price Per Country
			'\JET_APB\Plugin', // Jet Appointments Booking
		);
		$except_class_plugins = apply_filters( 'yay_currency_except_class_plugin', $except_class_plugins );
		foreach ( $except_class_plugins as $class ) {
			if ( class_exists( $class ) ) {
				return $calculate_price;
			}
		}
		return false;
	}

	public function custom_fixed_price_simple_product( $price, $product, $apply_currency ) {
		// WooCommerce Product Bundles plugin
		if ( 'bundle' === $product->get_type() && isset( $product->bundled_item_price ) ) {
			$price = apply_filters( 'yay_currency_get_fixed_price_product_bundle_html', $price, $product );
			return $price;
		}

		$custom_fixed_prices = ! empty( get_post_meta( $product->get_ID(), 'yay_currency_custom_fixed_prices', true ) ) ? get_post_meta( $product->get_ID(), 'yay_currency_custom_fixed_prices', true ) : null;

		if ( $custom_fixed_prices && ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
			$regular_price = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] : $product->get_regular_price();
			if ( floatval( $product->get_sale_price() ) > 0 ) {
				if ( ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] ) ) {
					$sale_price = $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'];
				} else {
					$sale_price = $product->get_sale_price();
				}
				$price = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
			} else {
				$price = YayCurrencyHelper::format_price( $regular_price );
			}
		}

		$price = apply_filters( 'yay_currency_fixed_price_simple_product_convented', $price, $product, $apply_currency );
		return $price;
	}

	public function custom_fixed_price_variable_product( $price, $product, $apply_currency ) {
		$min_price     = $product->get_variation_price( 'min', true );
		$max_price     = $product->get_variation_price( 'max', true );
		$variation_ids = $product->get_children();
		$flag          = false;
		$sale_price    = false;
		$regular_price = false;
		foreach ( $variation_ids as $id ) {

			$custom_fixed_prices = get_post_meta( $id, 'yay_currency_custom_fixed_prices', true );
			$price_by_currency   = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['price'] : false;

			if ( $custom_fixed_prices && $price_by_currency ) {

				$flag      = true;
				$min_price = min( $min_price, $price_by_currency );
				$max_price = max( $max_price, $price_by_currency );

				$sale_price    = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] : false;
				$regular_price = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] ) ? $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] : false;

			}
		}

		if ( ! $flag ) {
			return $price;
		}

		$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
		$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

		if ( $min_price == $max_price ) {
			if ( $sale_price && $regular_price ) {
				$price = YayCurrencyHelper::format_sale_price( $regular_price, $sale_price );
			} else {
				$price = $formatted_min_price;
			}
		} else {
			$price = $formatted_min_price . ' - ' . $formatted_max_price;
		}

		$price = apply_filters( 'yay_currency_fixed_price_variable_product_convented', $price, $product, $apply_currency );
		return $price;

	}

	public function custom_fixed_price_grouped_product( $price, $product, $child_prices, $apply_currency ) {
		$min_price          = min( $child_prices );
		$max_price          = max( $child_prices );
		$linked_product_ids = $product->get_children();
		$fixed_prices_array = array();

		foreach ( $linked_product_ids as $id ) {
			$custom_fixed_prices = get_post_meta( $id, 'yay_currency_custom_fixed_prices', true );
			if ( $custom_fixed_prices && ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
				array_push( $fixed_prices_array, $custom_fixed_prices[ $apply_currency['currency'] ]['price'] );
			}
		}

		if ( ! empty( $fixed_prices_array ) ) {
			$min_price = min( $fixed_prices_array );
			$max_price = max( $fixed_prices_array );
		}

		$formatted_min_price = YayCurrencyHelper::format_price( $min_price );
		$formatted_max_price = YayCurrencyHelper::format_price( $max_price );

		$price = $min_price == $max_price ? $formatted_min_price : $formatted_min_price . ' - ' . $formatted_max_price;
		$price = apply_filters( 'yay_currency_fixed_price_grouped_product_convented', $price, $product, $child_prices, $apply_currency );

		return $price;

	}

	public function custom_stripe_request_total_amount( $request, $api ) {
		if ( isset( $request['currency'] ) && isset( $request['metadata'] ) && isset( $request['metadata']['order_id'] ) ) {
			$array_zero_decimal_currencies = array(
				'BIF',
				'CLP',
				'DJF',
				'GNF',
				'JPY',
				'KMF',
				'KRW',
				'MGA',
				'PYG',
				'RWF',
				'UGX',
				'VND',
				'VUV',
				'XAF',
				'XOF',
				'XPF',
			);
			if ( in_array( strtoupper( $request['currency'] ), $array_zero_decimal_currencies ) ) {
				$order_id = $request['metadata']['order_id'];
				if ( ! empty( $order_id ) ) {
					$order = wc_get_order( $order_id );
					if ( ! $order ) {
						return $request;
					}
					$order_total       = YayCurrencyHelper::get_total_by_order( $order );
					$request['amount'] = floatval( $order_total );
				}
			}
		}
		return $request;
	}

	public function is_original_product_price( $flag, $price, $product ) {

		if ( empty( $price ) || ! is_numeric( $price ) || YayCurrencyHelper::is_wc_json_products() || class_exists( 'BM' ) ) {
			$flag = true;
		}

		if ( class_exists( 'WC_Bookings' ) && 'booking' === $product->get_type() ) {
			$flag = true;
		}

		// Role Based Pricing for WooCommerce plugin
		if ( class_exists( 'AF_C_S_P_Price' ) && doing_filter( 'woocommerce_before_calculate_totals' ) ) {
			$flag = true;
		}

		return $flag;
	}

	public function is_cart_fees_original( $flag, $apply_currency ) {

		if ( class_exists( 'Woocommerce_Conditional_Product_Fees_For_Checkout_Pro' ) || class_exists( 'TaxamoClass' ) ) {
			$flag = false;
		}

		return $flag;
	}

	public function is_original_format_order_item_totals( $flag, $total_rows, $order, $tax_display ) {
		if ( isset( $_GET['action'] ) && 'generate_wpo_wcpdf' === $_GET['action'] ) {
			$flag = true;
		}
		return $flag;
	}

	// Calculate Total to Default

	public function calculate_cart_subtotal_default( $subtotal ) {
		$subtotal = SupportHelper::get_cart_subtotal_default();
		return $subtotal;
	}

	public function get_cart_item_price( $product_price, $cart_item, $apply_currency ) {
		$product_price = SupportHelper::get_product_price_by_cart_item( $cart_item, $apply_currency );
		return $product_price;
	}

	public function get_cart_subtotal( $cart_subtotal, $apply_currency ) {
		$cart_subtotal = SupportHelper::get_cart_subtotal( $apply_currency );
		return $cart_subtotal;
	}

	public function calculate_discount_total( $discount_total, $apply_currency = false ) {
		if ( ! $apply_currency ) {
			$cart_subtotal = apply_filters( 'yay_currency_get_cart_subtotal_default', 0 );
		} else {
			$cart_subtotal = apply_filters( 'yay_currency_get_cart_subtotal', 0, $apply_currency );
		}
		$discount_total = SupportHelper::get_total_coupons( $cart_subtotal, $apply_currency );
		return $discount_total;
	}

	public function calculate_shipping_total( $shipping_total, $apply_currency, $is_fallback = false ) {
		$calculate_default = $apply_currency ? false : true;
		$shipping_total    = SupportHelper::get_shipping_total_selected( $apply_currency, $calculate_default, false, $is_fallback );
		return $shipping_total;
	}

	public function calculate_fee_total( $fee_total, $apply_currency ) {
		$calculate_default = $apply_currency ? false : true;
		$fee_total         = SupportHelper::get_total_fees( $apply_currency, false, $calculate_default );
		return $fee_total;
	}

	public function calculate_total_tax( $total_tax, $apply_currency ) {
		$total_tax = SupportHelper::get_total_tax( $apply_currency );
		return $total_tax;
	}

	public function calculate_cart_total( $total, $apply_currency, $is_fallback ) {
		$total = SupportHelper::get_cart_total( $apply_currency, $is_fallback );
		return $total;
	}

	public function calculate_cart_total_default( $total ) {
		$total = SupportHelper::get_cart_total( false );
		return $total;
	}

	// TAX
	public function is_recalculate_tax( $flag ) {

		if ( wc_tax_enabled() && 'incl' !== get_option( 'woocommerce_tax_display_cart' ) ) {
			$flag = true;
		}

		return $flag;

	}

	public function is_custom_price_html( $is_set_fixed_price ) {

		if ( ! $is_set_fixed_price ) {
			return false;
		}

		$tax_display_shop = get_option( 'woocommerce_tax_display_shop' );

		return ! wc_tax_enabled() || ( ! wc_prices_include_tax() && 'excl' === $tax_display_shop ) || ( wc_prices_include_tax() && 'incl' === $tax_display_shop );

	}

	public function custom_set_order_original_total( $order, $data, $default_currency_code, $fallback_currency, $current_currency ) {
		$flag_apply_currency    = YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $current_currency ) && $default_currency_code !== $current_currency['currency'];
		$flag_fallback_currency = YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $fallback_currency );
		$order_total            = $order->get_total();
		$original_total         = false;

		if ( $flag_apply_currency || $flag_fallback_currency ) {
			$original_total = apply_filters( 'yay_currency_get_cart_total_default', 0 );
		}

		if ( 0 == $current_currency['status'] && $fallback_currency['currency'] != $default_currency_code ) {
			if ( ! $original_total ) {
				$original_total = $order_total / YayCurrencyHelper::get_rate_fee( $fallback_currency );
			}
		} else {
			if ( ! $original_total ) {
				$original_total = $order_total / YayCurrencyHelper::get_rate_fee( $current_currency );
			}
		}

		$original_total = $original_total ? $original_total : $order_total;
		if ( Helper::check_custom_orders_table_usage_enabled() ) {
			$order->add_meta_data( 'yay_currency_checkout_original_total', $original_total );
		} else {
			update_post_meta( $order->get_id(), 'yay_currency_checkout_original_total', $original_total );
		}
	}

	public function custom_checkout_create_order_fallback_currency( $order, $data, $fallback_currency ) {
		$order_subtotal       = YayCurrencyHelper::calculate_price_by_currency( $order->get_subtotal(), true, $fallback_currency );
		$order_total          = YayCurrencyHelper::calculate_price_by_currency( $order->get_total(), true, $fallback_currency );
		$order_discount_total = YayCurrencyHelper::calculate_price_by_currency( $order->get_discount_total(), true, $fallback_currency );
		$order_shipping_total = YayCurrencyHelper::calculate_price_by_currency( $order->get_shipping_total(), true, $fallback_currency );
		$order_cart_tax       = YayCurrencyHelper::calculate_price_by_currency( $order->get_cart_tax(), true, $fallback_currency );
		$order_shipping_tax   = YayCurrencyHelper::calculate_price_by_currency( $order->get_shipping_tax(), true, $fallback_currency );
		if ( YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $fallback_currency ) ) {
			$order_subtotal       = apply_filters( 'yay_currency_get_cart_subtotal', 0, $fallback_currency );
			$order_discount_total = apply_filters( 'yay_currency_get_discount_total', 0, $fallback_currency );
			$order_shipping_total = apply_filters( 'yay_currency_get_shipping_total', 0, $fallback_currency, true );
			$order_total          = apply_filters( 'yay_currency_get_cart_total', 0, $fallback_currency, true );
			$original_total       = apply_filters( 'yay_currency_get_cart_total_default', 0 );
			$order->add_meta_data( 'yay_currency_checkout_original_total', $original_total );
		}
		$order->subtotal = $order_subtotal;
		$order->set_currency( $fallback_currency['currency'] );
		$order->set_total( $order_total );
		$order->set_discount_total( $order_discount_total );
		$order->set_shipping_total( $order_shipping_total );
		$order->set_cart_tax( $order_cart_tax );
		$order->set_shipping_tax( $order_shipping_tax );
	}

	public function create_create_order_line_item_fallback_currency( $item, $cart_item_key, $values, $order, $fallback_currency ) {
		$item_subtotal     = YayCurrencyHelper::calculate_price_by_currency( $values['line_subtotal'], true, $fallback_currency );
		$item_subtotal_tax = YayCurrencyHelper::calculate_price_by_currency( $values['line_subtotal_tax'], true, $fallback_currency );
		$item_total        = YayCurrencyHelper::calculate_price_by_currency( $values['line_total'], true, $fallback_currency );
		$item_total_tax    = YayCurrencyHelper::calculate_price_by_currency( $values['line_tax'], true, $fallback_currency );
		$product           = $item->get_product();

		if ( YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $fallback_currency, 'product', $product ) ) {
			$product_info      = SupportHelper::get_product_subtotal_info( $product, $item->get_quantity(), $fallback_currency );
			$item_subtotal     = $product_info['subtotal'];
			$item_subtotal_tax = $product_info['subtotal_tax'];
			$item_total        = $item_subtotal;
			$item_total_tax    = $item_subtotal_tax;
		}

		$item->set_subtotal( $item_subtotal );
		$item->set_subtotal_tax( $item_subtotal_tax );
		$item->set_total( $item_total );
		$item->set_total_tax( $item_total_tax );

		$line_tax_data = $values['line_tax_data'];
		if ( $line_tax_data ) {
			if ( isset( $line_tax_data['subtotal'] ) ) {
				$rateId                               = key( $line_tax_data['subtotal'] );
				$line_tax_data['subtotal'][ $rateId ] = $item_subtotal_tax;
			}

			if ( isset( $line_tax_data['total'] ) ) {
				$rateId                            = key( $line_tax_data['total'] );
				$line_tax_data['total'][ $rateId ] = $item_total_tax;
			}
			$item->set_taxes( $line_tax_data );
		}

		$item->save();
	}

	public function create_order_shipping_item_fallback_currency( $item, $package_key, $package, $order, $fallback_currency ) {
		$item_total = YayCurrencyHelper::calculate_price_by_currency( $item->get_total(), true, $fallback_currency );
		$taxes      = $item->get_taxes();
		if ( YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $fallback_currency ) ) {
			$item_total              = apply_filters( 'yay_currency_get_shipping_total', 0, $fallback_currency, true );
			$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
			$shipping_rate           = $package['rates'][ $chosen_shipping_methods[ $package_key ] ];
			if ( $shipping_rate && isset( $shipping_rate->taxes ) && $shipping_rate->taxes ) {
				$rateId = key( $shipping_rate->taxes );
				if ( $rateId ) {
					$rate_percent   = \WC_Tax::get_rate_percent_value( $rateId );
					$taxes['total'] = array(
						$rateId => $item_total * $rate_percent / 100,
					);
				}
			}
		}

		$item->set_total( $item_total );
		if ( $taxes && isset( $taxes['total'] ) ) {
			$item->set_taxes( $taxes );
		}

		$item->save();
	}

	public function create_order_fee_item_fallback_currency( $item, $fee_key, $fee, $order, $fallback_currency ) {
		$item_total     = YayCurrencyHelper::calculate_price_by_currency( $fee->total, true, $fallback_currency );
		$item_total_tax = YayCurrencyHelper::calculate_price_by_currency( $fee->tax, true, $fallback_currency );
		$taxes          = $item->get_taxes();
		$item->set_total( $item_total );
		$item->set_total_tax( $item_total_tax );

		if ( $fee->tax_data ) {
			foreach ( $fee->tax_data as $rateId => $tax ) {
				$fee->tax_data[ $rateId ] = YayCurrencyHelper::calculate_price_by_currency( $tax, true, $fallback_currency );
			}
			$taxes['total'] = $fee->tax_data;
			$item->set_taxes( $taxes );
		}

		$item->save();
	}

	public function custom_order_tax_item_fallback_currency( $item, $tax_rate_id, $order, $fallback_currency ) {
		$cart               = WC()->cart;
		$tax_total          = $cart->get_tax_amount( $tax_rate_id );
		$tax_total          = YayCurrencyHelper::calculate_price_by_currency( $tax_total, true, $fallback_currency );
		$shipping_total_tax = $cart->get_shipping_tax_amount( $tax_rate_id );
		$shipping_total_tax = YayCurrencyHelper::calculate_price_by_currency( $shipping_total_tax, true, $fallback_currency );

		if ( YayCurrencyHelper::enable_rounding_or_fixed_price_currency( $fallback_currency ) ) {
			$rate_percent       = \WC_Tax::get_rate_percent_value( $tax_rate_id );
			$sum_tax_total      = SupportHelper::get_total_tax_is_fallback( $fallback_currency );
			$sum_shipping_total = apply_filters( 'yay_currency_get_shipping_total', 0, $fallback_currency, true );
			$shipping_total_tax = $sum_shipping_total * $rate_percent / 100;
			$tax_total          = $sum_tax_total - $shipping_total_tax;
		}
		$item->set_tax_total( $tax_total );
		$item->set_shipping_tax_total( $shipping_total_tax );
		$item->save();
	}

	// ACTION - HOOKS

	public function yay_currency_redirect_to_url( $current_url, $currency_ID ) {
		$current_currency = YayCurrencyHelper::get_currency_by_ID( $currency_ID );
		$current_url      = add_query_arg( array( 'yay-currency' => $current_currency['currency'] ), $current_url );
		if ( wp_safe_redirect( $current_url ) ) {
			exit;
		}
	}

	public function add_notice_checkout_payment_methods( $currencies_data, $current_theme ) {
		if ( current_user_can( 'manage_options' ) ) {
			// only for admin
			echo "<div class='yay-currency-checkout-notice yay-currency-with-" . esc_attr( $current_theme ) . "'><span>" . esc_html__( 'The current payment method for ', 'yay-currency' ) . '<strong>' . wp_kses_post( html_entity_decode( esc_html__( $currencies_data['current_currency']['currency'], 'yay-currency' ) ) ) . '</strong></span><span>' . esc_html__( ' is not supported in your location. ', 'yay-currency' ) . '</span><span>' . esc_html__( 'So your payment will be recorded in ', 'yay-currency' ) . '</span><strong>' . wp_kses_post( html_entity_decode( esc_html__( $currencies_data['fallback_currency']['currency'], 'yay-currency' ) ) ) . '.</strong></span></div>';
			echo "<div class='yay-currency-checkout-notice-admin yay-currency-with-" . esc_attr( $current_theme ) . "'><span>" . esc_html__( 'Are you the admin? You can change the checkout options for payment methods ', 'yay-currency' ) . '<a href=' . esc_url( admin_url( '/admin.php?page=yay_currency&tabID=1' ) ) . '>' . esc_html__( 'here', 'yay-currency' ) . '</a>.</span><br><span><i>' . esc_html__( '(Only logged in admin can see this.)', 'yay-currency' ) . '</i></span></div>';
		} else {
			echo "<div class='yay-currency-checkout-notice user yay-currency-with-" . esc_attr( $current_theme ) . "'><span>" . esc_html__( 'The current payment method for ', 'yay-currency' ) . '<strong>' . wp_kses_post( html_entity_decode( esc_html__( $currencies_data['current_currency']['currency'], 'yay-currency' ) ) ) . '</strong></span><span>' . esc_html__( ' is not supported in your location. ', 'yay-currency' ) . '</span><span>' . esc_html__( 'So your payment will be recorded in ', 'yay-currency' ) . '</span><strong>' . wp_kses_post( html_entity_decode( esc_html__( $currencies_data['fallback_currency']['currency'], 'yay-currency' ) ) ) . '.</strong></span></div>';
		}
	}

}
