<?php
namespace Yay_Currency\Helpers;

use Yay_Currency\Utils\SingletonTrait;
class FixedPriceHelper {

	use SingletonTrait;

	protected function __construct() {}

	public static function is_set_fixed_price() {
		$flag = get_option( 'yay_currency_set_fixed_price', 0 );
		return $flag;
	}

	public static function get_price_fixed_by_apply_currency( $product, $price, $apply_currency ) {
		if ( ! self::is_set_fixed_price() ) {
			return $price;
		}
		$product_id          = $product->get_id();
		$custom_fixed_prices = get_post_meta( $product_id, 'yay_currency_custom_fixed_prices', true );
		if ( ! empty( $custom_fixed_prices ) && isset( $custom_fixed_prices[ $apply_currency['currency'] ] ) ) {
			if ( ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
				if ( ! empty( $product->get_data()['sale_price'] ) ) {
					$price = $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] ? $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] : $price;
				} else {
					$price = $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] ? $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] : $price;
				}
			}
		}
		return (float) $price;
	}

	public static function product_is_set_fixed_price_by_currency( $product, $apply_currency ) {
		$fixed_price = false;
		if ( self::is_set_fixed_price() ) {
			$fixed_price = self::get_price_fixed_by_apply_currency( $product, $fixed_price, $apply_currency );
		}

		return $fixed_price;
	}

	public static function check_product_in_cart_fixed_price( $apply_currency ) {
		$flag          = false;
		$cart_contents = WC()->cart->get_cart_contents();
		foreach ( $cart_contents  as $key => $cart_item ) {
			$product_id  = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
			$_product    = wc_get_product( $product_id );
			$price_fixed = self::product_is_set_fixed_price_by_currency( $_product, $apply_currency );
			if ( $price_fixed ) {
				$flag = true;
				break;
			}
		}
		return $flag;
	}

	// CALCULATE COUPON APPLIES
	public static function get_cart_subtotal_fixed_apply_discount( $apply_currency, $coupon_amount ) {
		$cart_subtotal_fixed = 0;
		$cart_contents       = WC()->cart->get_cart_contents();
		foreach ( $cart_contents  as $key => $cart_item ) {
			$product_id             = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
			$_product               = wc_get_product( $product_id );
			$fixed_price            = self::product_is_set_fixed_price_by_currency( $_product, $apply_currency );
			$fixed_product_subtotal = $fixed_price ? ( $fixed_price * $cart_item['quantity'] ) : ( YayCurrencyHelper::calculate_price_by_currency( $coupon_amount, true, $apply_currency ) * $cart_item['quantity'] );
			$cart_subtotal_fixed    = $cart_subtotal_fixed + $fixed_product_subtotal;
		}
		return $cart_subtotal_fixed;
	}

	public static function calculate_fixed_coupon_currency( $subtotal_price_fixed, $apply_currency ) {
		$total_coupon_applies = 0;
		if ( WC()->cart->applied_coupons ) {
			$applied_coupons = WC()->cart->applied_coupons;
			foreach ( $applied_coupons  as $coupon_code ) {
				$coupon          = new \WC_Coupon( $coupon_code );
				$discount_type   = $coupon->get_discount_type();
				$coupon_data     = $coupon->get_data();
				$products_ids    = Helper::get_value_variable( $coupon_data['product_ids'] );
				$discount_amount = (float) $coupon_data['amount'];
				if ( SupportHelper::woo_discount_rules_active() && $products_ids ) {
					if ( 'percent' === $discount_type ) {
						$cart_subtotal_apply_discount     = YayCurrencyHelper::calculate_price_by_currency( $discount_amount, true, $apply_currency );
						$cart_subtotal_apply_rule_as_cart = apply_filters( 'yay_currency_discount_rules_get_cart_subtotal_apply_coupon_as_cart_rule', $cart_subtotal_apply_discount, $discount_amount, $products_ids, $apply_currency );
						$total_coupon_applies            += $cart_subtotal_apply_rule_as_cart;
					}
				} else {

					if ( 'percent' !== $discount_type ) {

						if ( 'fixed_product' === $discount_type ) {
							$discount_amount *= SupportHelper::get_product_quantity_item_qty( true );
						}

						$cart_subtotal_apply_discount = YayCurrencyHelper::calculate_price_by_currency( $discount_amount, true, $apply_currency );
						if ( self::check_product_in_cart_fixed_price( $apply_currency ) ) {
							$cart_subtotal_fixed_apply_discount = self::get_cart_subtotal_fixed_apply_discount( $apply_currency, (float) $coupon->get_amount() );
							$cart_subtotal_fixed_apply_discount = $cart_subtotal_fixed_apply_discount > $cart_subtotal_apply_discount ? $cart_subtotal_apply_discount : $cart_subtotal_fixed_apply_discount;
							$total_coupon_applies              += $cart_subtotal_fixed_apply_discount;
						} else {
							$total_coupon_applies += $cart_subtotal_apply_discount;
						}
					} else {
						$total_coupon_applies += ( $subtotal_price_fixed * $discount_amount ) / 100;
					}
				}
			}
		}
		return $total_coupon_applies;
	}

}
