<?php
namespace Yay_Currency\Helpers;

use Yay_Currency\Utils\SingletonTrait;

class Helper {

	use SingletonTrait;

	protected function __construct() {}
	private static $YAY_CURRENCY_POST_TYPE = 'yay-currency-manage';

	public static function sanitize_array( $var = array() ) {
		if ( is_array( $var ) ) {
			return array_map( 'self::sanitize_array', $var );
		} else {
			return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
		}
	}

	public static function get_value_variable( $variable, $default = false ) {
		return isset( $variable ) && ! empty( $variable ) ? $variable : $default;
	}

	public static function get_value_form_args( $args = array(), $key = false, $default = false ) {
		if ( ! $key ) {
			return $args;
		}
		return isset( $args[ $key ] ) && ! empty( $args[ $key ] ) ? $args[ $key ] : $default;
	}

	public static function sanitize( $var = array() ) {
		return wp_kses_post_deep( $var['data'] );
	}

	public static function get_post_type() {
		return self::$YAY_CURRENCY_POST_TYPE;
	}

	public static function get_yay_currency_by_currency_code( $currency_code = '' ) {
		$currencies = get_posts(
			array(
				'post_type' => self::get_post_type(),
				'title'     => $currency_code,
			)
		);
		return $currencies ? $currencies[0] : false;
	}

	public static function use_yay_currency_params() {
		$yay_currency_use_params = apply_filters( 'yay_currency_use_params', false );
		return $yay_currency_use_params;
	}

	public static function polylang_active() {
		if ( function_exists( 'pll_get_post_translations' ) ) {
			return true;
		}

		return false;
	}

	public static function wpml_language_active() {
		global $sitepress;
		if ( null === $sitepress || get_class( $sitepress ) !== 'SitePress' ) {
			return false;
		}
		return true;
	}

	public static function get_instance_classes( $engine_classes = array(), $yay_classes = array() ) {
		$last_length = count( $engine_classes );
		foreach ( $yay_classes as $yay_class ) {
			$engine_classes[ $last_length ] = $yay_class;
			$class                          = implode( '\\', $engine_classes );
			$class::get_instance();
		}
	}

	public static function engine_classes() {
		$classes = array(
			'Hooks',
			'Ajax',
			'ScheduleJobs',
		);

		return $classes;
	}

	public static function appearance_classes() {
		$classes = array(
			'MenuDropdown',
			'Widget',
		);

		return $classes;
	}

	public static function backend_classes() {
		$classes = array(
			'WooCommerceFilterAnalytics',
			'WooCommerceFilterReport',
			'Settings',
			'FixedPricesPerProduct',
			'WooCommerceSettingGeneral',
			'WooCommerceOrderAdmin',
		);

		return $classes;
	}

	public static function frontend_classes() {
		$classes = array(
			'WooCommerceCurrency',
			'WooCommerceCheckoutPage',
			'WooCommercePriceFormat',
			'WooCommerceTaxCalculate',
			'SingleProductDropdown',
			'Shortcodes',
		);

		return $classes;
	}

	public static function compatible_classes() {
		$classes = array(
			// PLUGINS
			'WpmlCompatible',
			'PolylangCompatible',
			'AdvancedProductFieldsProWooCommerce',
			'B2BMarket',
			'B2BKingPro',
			'Cartflows',
			'Dokan',
			'RoleBasedPricingFoWooCommerce',
			'FlexibleShipping',
			'HivePress',
			'RapydPaymentGateway',
			'TieredPricingTableForWooCommerce',
			'JetSmartFilters',
			'WooCommerceSubscriptions',
			'BuyOnceOrSubscribeWooCommerceSubscriptions',
			'WooCommerceProductFeed',
			'WooCommercePayForPayment',
			'WooCommercePayments',
			'WooCommercePayPalPayments',
			'AGWooCommerceTylByNatWestPaymentGateway',
			'WooCommerceQuickView',
			'WooCommerceTableRateShipping',
			'WooCommerceProductTable',
			'AdvancedFlatRateShippingForWooCommercePro',
			'WooDiscountRules',
			'WooCommerceTMExtraProductOptions',
			'WooCommerceProductAddons',
			'WooCommerceProductAddOnsUltimate',
			'Barn2WooCommerceWholesalePro',
			'WooCommerceSimpleAuction',
			'YayExtra',
			'YayPricing',
			'WPFunnels',
			'WooCommerceTeraWallet',
			'WooCommerceProductBundles',
			'LearnPress',
			'WooCommerceNameYourPrice',
			'WooCommerceRequestAQuote',
			'PPOM',
			'YITHEasyOrderPageForWooCommerce',
			'YITHPointsAndRewards',
			'YITHWoocommerceGiftCards',
			'YITHWooCommerceAddOnsExtraPremiumOptions',
			'YITHWooCommerceSubscription',
			'WoocommerceGiftCards',
			'WooCommerceDeposits',
			'WooCommerceEmailSymbol',
			'WooCommerceBookings',
			'ElementorPro',
			'TranslatePressMultilingual',
			'Bookly',
			'Measurement_Price_Calculator',
			'TabbyCheckout',
			'PaymentGatewayForPayPalWooCommerce',
			'PaymentPluginsForPayPalWooCommerce',
			'ShipmondoWooCommerce',
			//THEMES
			'BeTheme',
			'JulyTheme',
			'KapeeTheme',
			'BreakdanceTheme',
			'EnfoldTheme',
			'WoodmartTheme',
			'FlatsomeTheme',
			//CACHES
			'WPGridBuilderCaching',
			'WPRocket',
			'LiteSpeedCache',
		);

		return $classes;

	}

	public static function default_currency_code() {
		$default_currency = get_option( 'woocommerce_currency' );
		return $default_currency;
	}

	public static function default_price_num_decimals() {
		$default_price_num_decimals = get_option( 'woocommerce_price_num_decimals' );
		return wp_kses_post( html_entity_decode( $default_price_num_decimals ) );
	}

	public static function get_currencies_post_type() {

		$post_type_args = array(
			'posts_per_page' => -1,
			'post_type'      => 'yay-currency-manage',
			'post_status'    => 'publish',
			'order'          => 'ASC',
			'orderby'        => 'menu_order',
		);

		$currencies   = get_posts( $post_type_args );
		$dup_currency = array();

		foreach ( $currencies as $key => $currency ) {
			if ( in_array( $currency->post_title, $dup_currency ) ) {
				wp_delete_post( $currency->ID );
				unset( $currencies[ $key ] );
			} else {
				array_push( $dup_currency, $currency->post_title );
			}
		};

		return $currencies;
	}

	public static function count_display_elements_in_switcher( $is_show_flag = true, $is_show_currency_name = true, $is_show_currency_symbol = true, $is_show_currency_code = true ) {
		$display_elements_array = array();
		$is_show_flag ? array_push( $display_elements_array, $is_show_flag ) : null;
		$is_show_currency_name ? array_push( $display_elements_array, $is_show_currency_name ) : null;
		$is_show_currency_symbol ? array_push( $display_elements_array, $is_show_currency_symbol ) : null;
		$is_show_currency_code ? array_push( $display_elements_array, $is_show_currency_code ) : null;
		return count( $display_elements_array );
	}

	public static function get_flag_by_country_code( $country_code = 'us' ) {

		$flag_url = YAY_CURRENCY_PLUGIN_DIR . 'assets/dist/flags/' . $country_code . '.svg';
		if ( file_exists( $flag_url ) ) {
			return YAY_CURRENCY_PLUGIN_URL . 'assets/dist/flags/' . $country_code . '.svg';
		} else {
			return YAY_CURRENCY_PLUGIN_URL . 'assets/dist/flags/us.svg';
		}

	}

	public static function change_existing_currency_symbol( $apply_currency = array(), $currency_symbol = '' ) {
		if ( ! $apply_currency ) {
			return $currency_symbol;
		}
		$currency_symbol = isset( $apply_currency['symbol'] ) ? $apply_currency['symbol'] : $currency_symbol;
		return wp_kses_post( html_entity_decode( $currency_symbol ) );
	}

	public static function change_currency_position( $apply_currency = array() ) {
		if ( ! $apply_currency ) {
			return false;
		}
		return $apply_currency['currencyPosition'];
	}

	public static function set_default_currency_options( $apply_currency = array() ) {
		return array(
			'thousandSeparator' => isset( $apply_currency['thousandSeparator'] ) && ! empty( $apply_currency['thousandSeparator'] ) ? $apply_currency['thousandSeparator'] : '',
			'decimalSeparator'  => isset( $apply_currency['decimalSeparator'] ) && ! empty( $apply_currency['decimalSeparator'] ) ? $apply_currency['decimalSeparator'] : '.',
			'numberDecimal'     => isset( $apply_currency['numberDecimal'] ) && ! empty( $apply_currency['numberDecimal'] ) ? $apply_currency['numberDecimal'] : '0',
		);
	}

	public static function get_apply_currency_by_fallback_currency() {
		$converted_currency = YayCurrencyHelper::converted_currency();
		$apply_currency     = YayCurrencyHelper::get_fallback_currency( $converted_currency );
		return $apply_currency;
	}

	public static function change_thousand_separator( $apply_currency = array() ) {

		if ( ! $apply_currency || YayCurrencyHelper::disable_fallback_option_in_checkout_page( $apply_currency ) ) {
			$apply_currency = self::get_apply_currency_by_fallback_currency();
		}

		$default_currency_options = self::set_default_currency_options( $apply_currency );
		$thousand_separator       = $default_currency_options['thousandSeparator'];

		return apply_filters( 'yay_currency_custom_thousand_separator', $thousand_separator, $apply_currency );

	}

	public static function change_decimal_separator( $apply_currency = array() ) {

		if ( ! $apply_currency || YayCurrencyHelper::disable_fallback_option_in_checkout_page( $apply_currency ) ) {
			$apply_currency = self::get_apply_currency_by_fallback_currency();
		}

		$default_currency_options = self::set_default_currency_options( $apply_currency );
		$decimal_separator        = $default_currency_options['decimalSeparator'];

		return apply_filters( 'yay_currency_custom_decimal_separator', $decimal_separator, $apply_currency );

	}

	public static function change_number_decimals( $apply_currency = array() ) {

		if ( ! $apply_currency || YayCurrencyHelper::disable_fallback_option_in_checkout_page( $apply_currency ) ) {
			$apply_currency = self::get_apply_currency_by_fallback_currency();
		}

		$default_currency_options = self::set_default_currency_options( $apply_currency );
		$number_decimal           = $default_currency_options['numberDecimal'];

		return apply_filters( 'yay_currency_custom_number_decimal', $number_decimal, $apply_currency );

	}

	public static function change_price_format( $apply_currency = array(), $format = '' ) {

		if ( ! $apply_currency ) {
			return $format;
		}

		if ( YayCurrencyHelper::disable_fallback_option_in_checkout_page( $apply_currency ) ) {
			$apply_currency = self::get_apply_currency_by_fallback_currency();
		}

		$format = YayCurrencyHelper::format_currency_symbol( $apply_currency );

		return apply_filters( 'yay_currency_custom_price_format', $format, $apply_currency );
	}

	public static function geolocate_via_api( $ip_address ) {

		$geoip_apis = array(
			'ipinfo.io'  => 'https://ipinfo.io/%s/json',
			'ip-api.com' => 'http://ip-api.com/json/%s',
		);

		$geoip_services = apply_filters( 'woocommerce_geolocation_geoip_apis', $geoip_apis );

		if ( empty( $geoip_services ) ) {
			return '';
		}

		$country_code = false;

		$geoip_services_keys = array_keys( $geoip_services );
		shuffle( $geoip_services_keys );

		foreach ( $geoip_services_keys as $service_name ) {
			$service_endpoint = $geoip_services[ $service_name ];
			$response         = wp_safe_remote_get(
				sprintf( $service_endpoint, $ip_address ),
				array(
					'timeout'    => 2,
					'user-agent' => 'WooCommerce/' . wc()->version,
				)
			);

			if ( ! is_wp_error( $response ) && $response['body'] ) {
				switch ( $service_name ) {
					case 'ipinfo.io':
						$data         = json_decode( $response['body'] );
						$country_code = isset( $data->country ) ? $data->country : '';
						break;
					case 'ip-api.com':
						$data         = json_decode( $response['body'] );
						$country_code = isset( $data->countryCode ) ? $data->countryCode : ''; // @codingStandardsIgnoreLine
						break;
					default:
						$country_code = apply_filters( 'woocommerce_geolocation_geoip_response_' . $service_name, '', $response['body'] );
						break;
				}

				$country_code = sanitize_text_field( strtoupper( $country_code ) );

				if ( $country_code ) {
					break;
				}
			}
		}

		return $country_code;

	}

	public static function get_ip_address() {
		// use this to test
		if ( isset( $_REQUEST['yay-currency-country-ip'] ) ) {
			return sanitize_text_field( wp_unslash( $_REQUEST['yay-currency-country-ip'] ) );
		}

		if ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			// Proxy servers can send through this header like this: X-Forwarded-For: client1, proxy1, proxy2
			// Make sure we always only send through the first IP in the list which should always be the client IP.
			return (string) rest_is_ip_address( trim( current( preg_split( '/,/', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) ) ) );
		} elseif ( isset( $_SERVER['HTTP_X_REAL_IP'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_REAL_IP'] ) );
		} elseif ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}

		return '';
	}

	public static function get_country_info_from_IP() {
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
		$wp_filesystem = new \WP_Filesystem_Direct( null );
		$user_ip       = self::get_ip_address();
		$country       = self::geolocate_via_api( $user_ip );
		$country       = strtolower( $country );
		if ( empty( $country ) ) {
			return array(
				'country_code'  => $country,
				'currency_code' => get_option( 'woocommerce_currency' ),
			);
		}

		$country_data         = $wp_filesystem->get_contents( YAY_CURRENCY_PLUGIN_DIR . 'lib/country-data.json' );
		$decoded_country_data = json_decode( $country_data );

		return array(
			'country_code'  => $country,
			'currency_code' => $decoded_country_data->$country,
		);
	}

	public static function converted_currencies( $currencies = array() ) {
		$converted_currencies = array();
		foreach ( $currencies as $currency ) {
			$currency_meta      = get_post_meta( $currency->ID, '', false );
			$currency_code      = $currency->post_title;
			$symbol_currency    = get_woocommerce_currency_symbol( $currency_code );
			$converted_currency = array(
				'ID'                   => $currency->ID,
				'currency'             => $currency_code,
				'currencySymbol'       => html_entity_decode( $symbol_currency ),
				'currencyPosition'     => $currency_meta['currency_position'][0],
				'currencyCodePosition' => isset( $currency_meta['currency_code_position'] ) && ! empty( $currency_meta['currency_code_position'][0] ) ? $currency_meta['currency_code_position'][0] : 'not_display',
				'thousandSeparator'    => $currency_meta['thousand_separator'][0],
				'decimalSeparator'     => ! empty( $currency_meta['decimal_separator'][0] ) ? $currency_meta['decimal_separator'][0] : '.',
				'numberDecimal'        => ! empty( $currency_meta['number_decimal'][0] ) ? $currency_meta['number_decimal'][0] : '0',
				'rate'                 =>
					array(
						'type'  => $currency_meta['rate_type'] && ! empty( $currency_meta['rate_type'][0] ) ? $currency_meta['rate_type'][0] : 'auto',
						'value' => $currency_meta['rate'][0],
					),
				'fee'                  => maybe_unserialize( $currency_meta['fee'][0] ),
				'status'               => $currency_meta['status'][0],
				'paymentMethods'       => maybe_unserialize( $currency_meta['payment_methods'][0] ),
				'countries'            => maybe_unserialize( $currency_meta['countries'][0] ),
				'default'              => get_option( 'woocommerce_currency' ) == $currency_code ? true : false,
				'isLoading'            => false,
				'roundingType'         => $currency_meta['rounding_type'][0] ? $currency_meta['rounding_type'][0] : 'disabled',
				'roundingValue'        => $currency_meta['rounding_value'][0] ? $currency_meta['rounding_value'][0] : 1,
				'subtractAmount'       => $currency_meta['subtract_amount'][0] ? $currency_meta['subtract_amount'][0] : 0,
			);
			array_push( $converted_currencies, $converted_currency );
		}
		return $converted_currencies;
	}

	// Analytics
	public static function analytics_currencies() {
		$currencies           = self::get_currencies_post_type();
		$converted_currencies = array();
		foreach ( $currencies as $currency ) {
			$currency_meta = get_post_meta( $currency->ID, '', false );
			$currency_code = $currency->post_title;
			array_push(
				$converted_currencies,
				array(
					$currency_code => array(
						'code'              => $currency_code,
						'symbol'            => html_entity_decode( YayCurrencyHelper::get_symbol_by_currency_code( $currency_code ) ),
						'symbolPosition'    => $currency_meta['currency_position'][0],
						'thousandSeparator' => $currency_meta['thousand_separator'][0],
						'decimalSeparator'  => $currency_meta['decimal_separator'][0],
						'precision'         => $currency_meta['number_decimal'][0],
					),
				)
			);
		}
		return $converted_currencies;
	}

	public static function analytics_dropdown_currencies( $converted_currencies = array() ) {
		$dropdown_currencies = array(
			array(
				'label' => __( 'All currencies', 'yay-currency' ),
				'value' => 'all_currency',
			),
		);
		$list_currencies     = self::woo_list_currencies();

		foreach ( $converted_currencies as $key => $value ) {
			if ( ! isset( $list_currencies[ reset( $value )['code'] ] ) ) {
				continue;
			}
			$decoded_currency_name       = wp_kses_post( html_entity_decode( $list_currencies[ reset( $value )['code'] ] ) );
			$currency_symbol             = wp_kses_post( html_entity_decode( reset( $value )['symbol'] ) );
			$currency_code               = wp_kses_post( html_entity_decode( reset( $value )['code'] ) );
			$dropdown_converted_currency = array(
				'label' => __( $decoded_currency_name . '(' . $currency_symbol . ') - ' . $currency_code, 'yay-currency' ),
				'value' => $currency_code,
			);
			array_push( $dropdown_currencies, $dropdown_converted_currency );
		}

		return $dropdown_currencies;
	}

	public static function analytics_query_args() {
		$args = array(
			'products',
			'products_stats',
			'revenue',
			'orders',
			'orders_stats',
			'variations',
			'variations_stats',
			'categories',
			'categories_stats',
			'coupons',
			'coupons_stats',
			'taxes',
			'taxes_stats',
		);
		return $args;
	}

	public static function analytics_subquery_args() {
		$args = array(
			'products',
			'orders',
			'variations',
			'categories',
			'coupons',
			'taxes',
		);
		return $args;
	}

	public static function get_woo_current_settings() {
		return array(
			'currentCurrency'       => get_option( 'woocommerce_currency' ),
			'currentCurrencySymbol' => get_woocommerce_currency_symbol(),
			'currencyPosition'      => get_option( 'woocommerce_currency_pos' ),
			'thousandSeparator'     => get_option( 'woocommerce_price_thousand_sep' ),
			'decimalSeparator'      => get_option( 'woocommerce_price_decimal_sep' ),
			'numberDecimals'        => get_option( 'woocommerce_price_num_decimals' ),
		);
	}

	public static function woo_list_currencies() {
		$list_currencies        = get_woocommerce_currencies();
		$list_currencies['USD'] = 'United States dollar'; // Remove (US) from default
		return $list_currencies;
	}

	public static function currency_code_by_country_code() {
		$countries_code = array(
			'AED' => 'ae',
			'AFN' => 'af',
			'ALL' => 'al',
			'AMD' => 'am',
			'ANG' => 'an',
			'AOA' => 'ao',
			'ARS' => 'ar',
			'AUD' => 'au',
			'AWG' => 'aw',
			'AZN' => 'az',
			'BAM' => 'ba',
			'BBD' => 'bb',
			'BDT' => 'bd',
			'BGN' => 'bg',
			'BHD' => 'bh',
			'BIF' => 'bi',
			'BMD' => 'bm',
			'BND' => 'bn',
			'BOB' => 'bo',
			'BRL' => 'br',
			'BSD' => 'bs',
			'BTN' => 'bt',
			'BTC' => 'btc',
			'BWP' => 'bw',
			'BYN' => 'by',
			'BYR' => 'byr',
			'BZD' => 'bz',
			'CAD' => 'ca',
			'CDF' => 'cd',
			'CHF' => 'ch',
			'CLP' => 'cl',
			'CNY' => 'cn',
			'COP' => 'co',
			'CRC' => 'cr',
			'CUP' => 'cu',
			'CUC' => 'cuc',
			'CVE' => 'cv',
			'CZK' => 'cz',
			'DJF' => 'dj',
			'DKK' => 'dk',
			'DOP' => 'do',
			'DZD' => 'dz',
			'EGP' => 'eg',
			'ERN' => 'er',
			'ETB' => 'et',
			'EUR' => 'eu',
			'FJD' => 'fj',
			'FKP' => 'fk',
			'GBP' => 'gb',
			'GEL' => 'ge',
			'GGP' => 'gg',
			'GHS' => 'gh',
			'GIP' => 'gi',
			'GMD' => 'gm',
			'GNF' => 'gn',
			'GTQ' => 'gt',
			'GYD' => 'gy',
			'HKD' => 'hk',
			'HNL' => 'hn',
			'HRK' => 'hr',
			'HTG' => 'ht',
			'HUF' => 'hu',
			'IDR' => 'id',
			'ILS' => 'il',
			'IMP' => 'im',
			'INR' => 'in',
			'IQD' => 'iq',
			'IRR' => 'ir',
			'IRT' => 'irt',
			'ISK' => 'is',
			'JEP' => 'je',
			'JMD' => 'jm',
			'JOD' => 'jo',
			'JPY' => 'jp',
			'KES' => 'ke',
			'KGS' => 'kg',
			'KHR' => 'kh',
			'KMF' => 'km',
			'KPW' => 'kp',
			'KRW' => 'kr',
			'KWD' => 'kw',
			'KYD' => 'ky',
			'KZT' => 'kz',
			'LAK' => 'la',
			'LBP' => 'lb',
			'LKR' => 'lk',
			'LRD' => 'lr',
			'LSL' => 'ls',
			'LYD' => 'ly',
			'MAD' => 'ma',
			'MDL' => 'md',
			'PRB' => 'mda',
			'MGA' => 'mg',
			'MKD' => 'mk',
			'MMK' => 'mm',
			'MNT' => 'mn',
			'MOP' => 'mo',
			'MRU' => 'mr',
			'MUR' => 'mu',
			'MVR' => 'mv',
			'MWK' => 'mw',
			'MXN' => 'mx',
			'MYR' => 'my',
			'MZN' => 'mz',
			'NAD' => 'na',
			'NGN' => 'ng',
			'NIO' => 'ni',
			'NOK' => 'no',
			'XOF' => 'none',
			'XPF' => 'none1',
			'XCD' => 'none2',
			'XAF' => 'none3',
			'NPR' => 'np',
			'NZD' => 'nz',
			'OMR' => 'om',
			'PAB' => 'pa',
			'PEN' => 'pe',
			'PGK' => 'pg',
			'PHP' => 'ph',
			'PKR' => 'pk',
			'PLN' => 'pl',
			'PYG' => 'py',
			'QAR' => 'qa',
			'RON' => 'ro',
			'RSD' => 'rs',
			'RUB' => 'ru',
			'RWF' => 'rw',
			'SAR' => 'sa',
			'SBD' => 'sb',
			'SCR' => 'sc',
			'SDG' => 'sd',
			'SEK' => 'se',
			'SGD' => 'sg',
			'SHP' => 'sh',
			'SLL' => 'sl',
			'SOS' => 'so',
			'SRD' => 'sr',
			'SSP' => 'ss',
			'STN' => 'st',
			'SYP' => 'sy',
			'SZL' => 'sz',
			'THB' => 'th',
			'TJS' => 'tj',
			'TMT' => 'tm',
			'TND' => 'tn',
			'TOP' => 'to',
			'TRY' => 'tr',
			'TTD' => 'tt',
			'TWD' => 'tw',
			'TZS' => 'tz',
			'UAH' => 'ua',
			'UGX' => 'ug',
			'USD' => 'us',
			'UYU' => 'uy',
			'UZS' => 'uz',
			'VES' => 've',
			'VEF' => 'vef',
			'VND' => 'vn',
			'VUV' => 'vu',
			'WST' => 'ws',
			'YER' => 'ye',
			'ZAR' => 'za',
			'ZMW' => 'zm',
		);
		return $countries_code;
	}

	public static function convert_currencies_data() {
		$most_traded_currencies_code           = array( 'USD', 'EUR', 'GBP', 'INR', 'AUD', 'CAD', 'SGD', 'CHF', 'MYR', 'JPY' );
		$most_traded_converted_currencies_data = array();
		$converted_currencies_data             = array();

		$currency_code_by_country_code = self::currency_code_by_country_code();
		$woo_list_currencies           = self::woo_list_currencies();

		foreach ( $currency_code_by_country_code as $key => $value ) {
			$currency_data = array(
				'currency'      => isset( $woo_list_currencies[ $key ] ) ? html_entity_decode( $woo_list_currencies[ $key ] ) : 'USD',
				'currency_code' => $key,
				'country_code'  => $value,
			);
			if ( in_array( $key, $most_traded_currencies_code ) ) {
				array_push( $most_traded_converted_currencies_data, $currency_data );
			} else {
				array_push( $converted_currencies_data, $currency_data );
			}
		}
		usort(
			$most_traded_converted_currencies_data,
			function ( $a, $b ) use ( $most_traded_currencies_code ) {
				$pos_a = array_search( $a['currency_code'], $most_traded_currencies_code );
				$pos_b = array_search( $b['currency_code'], $most_traded_currencies_code );
				return $pos_a - $pos_b;
			}
		);
		$result = array_merge( $most_traded_converted_currencies_data, $converted_currencies_data );
		return $result;
	}

	public static function get_default_currency() {
		$woo_current_settings = self::get_woo_current_settings();
		$currentCurrency      = $woo_current_settings['currentCurrency'];
		$symbol               = get_woocommerce_currency_symbol( $currentCurrency );
		$default_currency     = array(
			'currency'             => $currentCurrency,
			'currencySymbol'       => html_entity_decode( $symbol ),
			'currencyPosition'     => $woo_current_settings['currencyPosition'],
			'currencyCodePosition' => 'not_display',
			'thousandSeparator'    => $woo_current_settings['thousandSeparator'],
			'decimalSeparator'     => $woo_current_settings['decimalSeparator'],
			'numberDecimal'        => $woo_current_settings['numberDecimals'],
			'rate'                 => array(
				'type'  => 'auto',
				'value' => '1',
			),
			'fee'                  => array(
				'value' => '0',
				'type'  => 'fixed',
			),
			'status'               => '1',
			'paymentMethods'       => array( 'all' ),
			'countries'            => array( 'default' ),
			'default'              => true,
			'isLoading'            => false,
			'roundingType'         => 'disabled',
			'roundingValue'        => 1,
			'subtractAmount'       => 0,
		);

		return $default_currency;

	}

	public static function create_new_currency( $currentCurrency = '', $is_wc_settings_page = false ) {
		if ( ! $is_wc_settings_page ) {
			$woo_current_settings = self::get_woo_current_settings();
			$currentCurrency      = $woo_current_settings['currentCurrency'];
		}
		$args            = array(
			'post_title'  => $currentCurrency,
			'post_type'   => self::$YAY_CURRENCY_POST_TYPE,
			'post_status' => 'publish',
			'menu_order'  => 0,
		);
		$new_currency_ID = wp_insert_post( $args );
		if ( ! is_wp_error( $new_currency_ID ) ) {
			if ( ! $is_wc_settings_page ) {
				self::update_currency_meta( $new_currency_ID, 'currency_position', $woo_current_settings['currencyPosition'] );
				self::update_currency_meta( $new_currency_ID, 'thousand_separator', $woo_current_settings['thousandSeparator'] );
				self::update_currency_meta( $new_currency_ID, 'decimal_separator', $woo_current_settings['decimalSeparator'] );
				self::update_currency_meta( $new_currency_ID, 'number_decimal', $woo_current_settings['numberDecimals'] );
				self::update_currency_meta( $new_currency_ID, 'currency_code_position', 'not_display' );
			}
			self::update_post_meta_currency( $new_currency_ID );
		}
	}

	public static function update_post_meta_currency( $currency_id = 0, $currency = false ) {
		if ( $currency ) {
			$default_currency_options = self::set_default_currency_options( $currency );
			self::update_currency_meta( $currency_id, 'currency_position', $currency['currencyPosition'] );
			self::update_currency_meta( $currency_id, 'currency_code_position', $currency['currencyCodePosition'] );
			self::update_currency_meta( $currency_id, 'thousand_separator', $currency['thousandSeparator'] );
			self::update_currency_meta( $currency_id, 'decimal_separator', $default_currency_options['decimalSeparator'] );
			self::update_currency_meta( $currency_id, 'number_decimal', $default_currency_options['numberDecimal'] );
		}
		self::update_currency_meta( $currency_id, 'rounding_type', $currency ? $currency['roundingType'] : 'disabled' );
		self::update_currency_meta( $currency_id, 'rounding_value', $currency ? $currency['roundingValue'] : 1 );
		self::update_currency_meta( $currency_id, 'subtract_amount', $currency ? $currency['subtractAmount'] : 0 );
		self::update_currency_meta( $currency_id, 'rate', $currency ? $currency['rate']['value'] : 1 );
		self::update_currency_meta( $currency_id, 'rate_type', $currency ? $currency['rate']['type'] : 'auto' );
		$fee_currency = $currency ? $currency['fee'] : array(
			'value' => '0',
			'type'  => 'fixed',
		);
		self::update_currency_meta( $currency_id, 'fee', $fee_currency );
		self::update_currency_meta( $currency_id, 'status', $currency ? $currency['status'] : '1' );
		self::update_currency_meta( $currency_id, 'payment_methods', $currency ? $currency['paymentMethods'] : array( 'all' ) );
		self::update_currency_meta( $currency_id, 'countries', $currency ? $currency['countries'] : array( 'default' ) );
	}

	public static function update_currency_meta( $currency_id = 0, $meta_key, $meta_value ) {
		if ( metadata_exists( 'post', $currency_id, $meta_key ) ) {
			update_post_meta( $currency_id, $meta_key, $meta_value );
		} else {
			add_post_meta( $currency_id, $meta_key, $meta_value );
		}
	}

	public static function update_exchange_rate_currency( $yay_currencies = array(), $woocommerce_currency = '' ) {
		if ( ! empty( $woocommerce_currency ) && $yay_currencies ) {
			foreach ( $yay_currencies as $currency ) {
				if ( $currency->post_title !== $woocommerce_currency ) {
					$rate_type = get_post_meta( $currency->ID, 'rate_type', true );
					if ( 'auto' === $rate_type || empty( $rate_type ) ) {

						$json_data = ExchangeRateAPIHelper::get_exchange_rates(
							array(
								'$src'  => $woocommerce_currency,
								'$dest' => $currency->post_title,
							)
						);

						if ( isset( $json_data['response']['code'] ) && 200 !== $json_data['response']['code'] ) {
							update_post_meta( $currency->ID, 'rate', 'N/A' );
							continue;
						}

						$decoded_json_data = json_decode( $json_data['body'] );
						$exchange_rate     = 1;

						if ( isset( $decoded_json_data->chart->result[0]->indicators->quote[0]->close ) ) {
							$exchange_rate = $decoded_json_data->chart->result[0]->indicators->quote[0]->close[0];
						} else {
							$exchange_rate = $decoded_json_data->chart->result[0]->meta->previousClose;
						}

						update_post_meta( $currency->ID, 'rate', $exchange_rate );

					}
				} else {
					update_post_meta( $currency->ID, 'rate', 1 );
				}
			}
		}
	}

	public static function get_current_theme() {
		return wp_get_theme()->template;
	}

	public static function get_current_url() {
		global $wp;
		if ( isset( $_SERVER['QUERY_STRING'] ) && ! empty( $_SERVER['QUERY_STRING'] ) ) {
			$query_string = sanitize_text_field( $_SERVER['QUERY_STRING'] );
			$current_url  = add_query_arg( $query_string, '', home_url( $wp->request ) );
		} else {
			$current_url = add_query_arg( array(), home_url( $wp->request ) );
		}
		return $current_url;
	}

	public static function create_nonce_field( $action = 'yay-currency-check-nonce', $name = 'yay-currency-nonce' ) {
		$name        = esc_attr( $name );
		$request_url = remove_query_arg( '_wp_http_referer' );
		$current_url = self::get_current_url();
		echo '<input type="hidden" class="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( wp_create_nonce( $action ) ) . '" />';
		echo '<input type="hidden" name="_wp_http_referer" value="' . esc_url( $request_url ) . '" />';
		echo '<input type="hidden" name="yay_currency_current_url" value="' . esc_url( $current_url ) . '" />';
	}

	public static function check_custom_orders_table_usage_enabled() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) ) {
			if ( \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
				return true;
			}
		}
		return false;
	}

	public static function get_translations() {
		return array(
			'Manager Currency'                           => __( 'Manager Currency', 'yay-currency' ),
			'Checkout in fallback currency'              => __( 'Checkout in fallback currency', 'yay-currency' ),
			'Type to search currency...'                 => __( 'Type to search currency...', 'yay-currency' ),
			'This currency is used as a fallback where the default currency can’t be displayed on checkout page.' => __( 'This currency is used as a fallback where the default currency can’t be displayed on checkout page.', 'yay-currency' ),
			'The fallback currency can not be disabled.' => __( 'The fallback currency can not be disabled.', 'yay-currency' ),
			'Checkout in different currency'             => __( 'Checkout in different currency', 'yay-currency' ),
			'This sets the ability to checkout in a variety of currencies' => __( 'This sets the ability to checkout in a variety of currencies', 'yay-currency' ),
			'Status'                                     => __( 'Status', 'yay-currency' ),
			'This sets the currency is applied in checkout' => __( 'This sets the currency is applied in checkout', 'yay-currency' ),
			'Currency'                                   => __( 'Currency', 'yay-currency' ),
			'Payment Methods'                            => __( 'Payment Methods', 'yay-currency' ),
			'Are you sure to disable the default currency at checkout?' => __( 'Are you sure to disable the default currency at checkout?', 'yay-currency' ),
			'You would need to select a fallback currency.' => __( 'You would need to select a fallback currency.', 'yay-currency' ),
			'All payment methods'                        => __( 'All payment methods', 'yay-currency' ),
			'Currency symbol position'                   => __( 'Currency symbol position', 'yay-currency' ),
			'Currency code position'                     => __( 'Currency code position', 'yay-currency' ),
			'Thousand separator'                         => __( 'Thousand separator', 'yay-currency' ),
			'Decimal separator'                          => __( 'Decimal separator', 'yay-currency' ),
			'Number of decimals'                         => __( 'Number of decimals', 'yay-currency' ),
			'Rounding'                                   => __( 'Rounding', 'yay-currency' ),
			'Custom rounding of converted prices'        => __( 'Custom rounding of converted prices', 'yay-currency' ),
			'To'                                         => __( 'To', 'yay-currency' ),
			'Round the converted price to achieve the target ending. Eg: 365.36 becomes 370 when rounding up to the nearest 10' => __( 'Round the converted price to achieve the target ending. Eg: 365.36 becomes 370 when rounding up to the nearest 10', 'yay-currency' ),
			'Minus'                                      => __( 'Minus', 'yay-currency' ),
			'Deduct this amount from the above rounded price. Eg: 370 becomes 369.99 after deducting 0.01' => __( 'Deduct this amount from the above rounded price. Eg: 370 becomes 369.99 after deducting 0.01', 'yay-currency' ),
			'Enter test amount'                          => __( 'Enter test amount', 'yay-currency' ),
			'Result'                                     => __( 'Result', 'yay-currency' ),
			'Left'                                       => __( 'Left', 'yay-currency' ),
			'Right'                                      => __( 'Right', 'yay-currency' ),
			'Left with space'                            => __( 'Left with space', 'yay-currency' ),
			'Right with space'                           => __( 'Right with space', 'yay-currency' ),
			'Not display'                                => __( 'Not display', 'yay-currency' ),
			'Disabled'                                   => __( 'Disabled', 'yay-currency' ),
			'Up'                                         => __( 'Up', 'yay-currency' ),
			'Down'                                       => __( 'Down', 'yay-currency' ),
			'Nearest'                                    => __( 'Nearest', 'yay-currency' ),
			'Your default currency is '                  => __( 'Your default currency is ', 'yay-currency' ),
			'Change'                                     => __( 'Change', 'yay-currency' ),
			'Add New Currency'                           => __( 'Add New Currency', 'yay-currency' ),
			'Live exchange rate unavailable. Please update manually for this currency.' => __( 'Live exchange rate unavailable. Please update manually for this currency.', 'yay-currency' ),
			'Troubleshoot'                               => __( 'Troubleshoot', 'yay-currency' ),
			'Config currency\'s format'                  => __( 'Config currency\'s format', 'yay-currency' ),
			'Update currency\'s rate'                    => __( 'Update currency\'s rate', 'yay-currency' ),
			'Delete currency'                            => __( 'Delete currency', 'yay-currency' ),
			'Fixed'                                      => __( 'Fixed', 'yay-currency' ),
			'Auto'                                       => __( 'Auto', 'yay-currency' ),
			'Preview'                                    => __( 'Preview', 'yay-currency' ),
			'Rate'                                       => __( 'Rate', 'yay-currency' ),
			'Fee'                                        => __( 'Fee', 'yay-currency' ),
			'Action'                                     => __( 'Action', 'yay-currency' ),
			'This controls what currency prices are listed at in the catalog and which currency gateways will take payments in.' => __( 'This controls what currency prices are listed at in the catalog and which currency gateways will take payments in.', 'yay-currency' ),
			'This show sample amount'                    => __( 'This show sample amount', 'yay-currency' ),
			'This sets the exchange rate of currency based on default currency' => __( 'This sets the exchange rate of currency based on default currency', 'yay-currency' ),
			'This sets the extra money to compensate the difference of currency' => __( 'This sets the extra money to compensate the difference of currency', 'yay-currency' ),
			'Are you sure you want to delete this currency?' => __( 'Are you sure you want to delete this currency?', 'yay-currency' ),
			'Configure'                                  => __( 'Configure', 'yay-currency' ),
			'currency'                                   => __( 'currency', 'yay-currency' ),
			'Switcher Location'                          => __( 'Switcher Location', 'yay-currency' ),
			'Choose where to display the currency switcher.' => __( 'Choose where to display the currency switcher.', 'yay-currency' ),
			'Before short description'                   => __( 'Before short description', 'yay-currency' ),
			'After short description'                    => __( 'After short description', 'yay-currency' ),
			'Shortcode'                                  => __( 'Shortcode', 'yay-currency' ),
			'Copy this shortcode to display currency switcher anywhere you want.' => __( 'Copy this shortcode to display currency switcher anywhere you want.', 'yay-currency' ),
			'Switcher Customizer'                        => __( 'Switcher Customizer', 'yay-currency' ),
			'Customize the currency switcher used at the above positions.' => __( 'Customize the currency switcher used at the above positions.', 'yay-currency' ),
			'Switcher size'                              => __( 'Switcher size', 'yay-currency' ),
			'Small'                                      => __( 'Small', 'yay-currency' ),
			'Medium'                                     => __( 'Medium', 'yay-currency' ),
			'Symbol'                                     => __( 'Symbol', 'yay-currency' ),
			'Code'                                       => __( 'Code', 'yay-currency' ),
			'Show on Single Product Page'                => __( 'Show on Single Product Page', 'yay-currency' ),
			'Show flag'                                  => __( 'Show flag', 'yay-currency' ),
			'Show currency name'                         => __( 'Show currency name', 'yay-currency' ),
			'Show currency symbol'                       => __( 'Show currency symbol', 'yay-currency' ),
			'Show currency code'                         => __( 'Show currency code', 'yay-currency' ),
			'Manage Currency'                            => __( 'Manage Currency', 'yay-currency' ),
			'Checkout Options'                           => __( 'Checkout Options', 'yay-currency' ),
			'Display Options'                            => __( 'Display Options', 'yay-currency' ),
			'Advanced Settings'                          => __( 'Advanced Settings', 'yay-currency' ),
			'Save Changes'                               => __( 'Save Changes', 'yay-currency' ),
			'Exchange rate is required!'                 => __( 'Exchange rate is required!', 'yay-currency' ),
			'Fix it now'                                 => __( 'Fix it now', 'yay-currency' ),
			'Settings saved!'                            => __( 'Settings saved!', 'yay-currency' ),
			'Exchange rate updated!'                     => __( 'Exchange rate updated!', 'yay-currency' ),
			'Successfully deleted!'                      => __( 'Successfully deleted!', 'yay-currency' ),
			'Unable to update exchange rate.'            => __( 'Unable to update exchange rate.', 'yay-currency' ),
			'Oops! Something went wrong!'                => __( 'Oops! Something went wrong!', 'yay-currency' ),
			'Contact us'                                 => __( 'Contact us', 'yay-currency' ),
			'Display current currency notice on product page' => __( 'Display current currency notice on product page', 'yay-currency' ),
			'You can include these shortcodes'           => __( 'You can include these shortcodes', 'yay-currency' ),
			'Fixed Product Price for Each Currency'      => __( 'Fixed Product Price for Each Currency', 'yay-currency' ),
			'By enabling this option, you can go to <b>Products</b> settings to set up fixed product prices based on currency.' => __( 'By enabling this option, you can go to <b>Products</b> settings to set up fixed product prices based on currency.', 'yay-currency' ),
			'Update Exchange Rate Automatically'         => __( 'Update Exchange Rate Automatically', 'yay-currency' ),
			'This sets the interval of update exchange rate automation.' => __( 'This sets the interval of update exchange rate automation.', 'yay-currency' ),
			'Auto Select Currency by Countries'          => __( 'Auto Select Currency by Countries', 'yay-currency' ),
			'This sets the display currency depends on the customer\'s country.' => __( 'This sets the display currency depends on the customer\'s country.', 'yay-currency' ),
			'WPML Compatible'                            => __( 'WPML Compatible', 'yay-currency' ),
			'Polylang Compatible'                        => __( 'Polylang Compatible', 'yay-currency' ),
			'Minute(s)'                                  => __( 'Minute(s)', 'yay-currency' ),
			'Hour(s)'                                    => __( 'Hour(s)', 'yay-currency' ),
			'Day(s)'                                     => __( 'Day(s)', 'yay-currency' ),
			'Countries'                                  => __( 'Countries', 'yay-currency' ),
			'Language'                                   => __( 'Language', 'yay-currency' ),
			'Default (Auto detect)'                      => __( 'Default (Auto detect)', 'yay-currency' ),
			'Update all currencies\'s rate'              => __( 'Update all currencies\'s rate', 'yay-currency' ),
			'Copied!'                                    => __( 'Copied!', 'yay-currency' ),
			'Click to copy'                              => __( 'Click to copy', 'yay-currency' ),
		);
	}

}
