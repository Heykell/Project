<?php
namespace Yay_Currency\Helpers;

use Yay_Currency\Utils\SingletonTrait;
class SupportHelper {

	use SingletonTrait;

	protected function __construct() {}

	public static function get_price_options_by_3rd_plugin( $product ) {
		$price_options = apply_filters( 'yay_currency_price_options', 0, $product );
		return $price_options;
	}

	public static function get_product_subtotal_fixed_by_3rd_plugin( $fixed_product_price, $product, $quantity, $apply_currency ) {
		$fixed_product_price          = apply_filters( 'yay_currency_get_fixed_product_price_3rd_plugin', $fixed_product_price, $product, $apply_currency );
		$fixed_product_subtotal_price = $fixed_product_price * $quantity;
		return apply_filters( 'yay_currency_get_fixed_product_subtotal_price_3rd_plugin', $fixed_product_subtotal_price, $product, $apply_currency );

	}

	public static function product_is_set_fixed_price( $apply_currency, $product_id ) {
		$price = false;
		if ( FixedPriceHelper::is_set_fixed_price() ) {
			$custom_fixed_prices = get_post_meta( $product_id, 'yay_currency_custom_fixed_prices', true );
			if ( ! empty( $custom_fixed_prices ) && isset( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
				if ( ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['price'] ) ) {
					$sale_price_original_currency = get_post_meta( $product_id, '_sale_price', true );
					if ( ! empty( $sale_price_original_currency ) ) {
						$price = $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] ? (float) $custom_fixed_prices[ $apply_currency['currency'] ]['sale_price'] : $price;
					} else {
						$price = $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] ? (float) $custom_fixed_prices[ $apply_currency['currency'] ]['regular_price'] : $price;
					}
				}
			}
		}
		return $price;
	}

	public static function get_product_price( $product_id, $apply_currency = false ) {
		$_product      = wc_get_product( $product_id );
		$product_price = $_product->get_price( 'edit' );
		if ( $apply_currency ) {
			$product_price = YayCurrencyHelper::calculate_price_by_currency( $product_price, false, $apply_currency );
			$product_price = FixedPriceHelper::get_price_fixed_by_apply_currency( $_product, $product_price, $apply_currency );
		}
		return $product_price;
	}

	public static function woo_discount_rules_active() {
		return apply_filters( 'yay_currency_active_woo_discount_rules', false );
	}

	// Get product price by Woo Discount Rules plugin
	public static function get_product_fixed_price_by_discount_type( $price, $product, $apply_currency ) {
		//Support a few plugin like Extra, Add-ons
		$discount_type = isset( $product->awdr_product_get_discount_type ) ? $product->awdr_product_get_discount_type : false;
		if ( $discount_type ) {
			$discount_value = $product->awdr_product_get_discount_value;
			$quantity       = $product->awdr_product_get_quantity;
			switch ( $discount_type ) {
				case 'fixed_price':
					$price = YayCurrencyHelper::calculate_price_by_currency( $discount_value, true, $apply_currency ) * $quantity;
					break;
				case 'flat':
					$price = ( $price - YayCurrencyHelper::calculate_price_by_currency( $discount_value, true, $apply_currency ) ) * $quantity;
					break;
				default:
					$price = ( $price - ( $discount_value / 100 ) * floatval( $price ) ) * $quantity;
					break;
			}
		}

		return $price;
	}

	// Get original price by Woo Discount Rules plugin
	public static function get_product_price_default_by_discount_type( $price, $product ) {
		//Support a few plugin like Extra, Add-ons
		$discount_type = isset( $product->awdr_product_get_discount_type ) ? $product->awdr_product_get_discount_type : false;
		if ( $discount_type ) {
			$discount_value = $product->awdr_product_get_discount_value;
			switch ( $discount_type ) {
				case 'fixed_price':
					$price = $discount_value;
					break;
				case 'flat':
					$price = ( $price - $discount_value );
					break;
				default:
					$price = ( $price - ( $discount_value / 100 ) * floatval( $price ) );
					break;
			}
		}

		return $price;
	}

	// SUPPORT FOR Woo Discount Rules PRO
	public static function calculate_discount_from() {
		$calculate_discount_from = 'sale_price';
		if ( self::woo_discount_rules_active() && class_exists( '\Wdr\App\Controllers\DiscountCalculator' ) ) {
			$calculate_discount_from = \Wdr\App\Controllers\DiscountCalculator::$config->getConfig( 'calculate_discount_from', 'sale_price' );
		}
		return $calculate_discount_from;
	}

	public static function get_original_price_apply_discount_pro( $product_id ) {
		$calculate_discount_from = self::calculate_discount_from();
		if ( 'sale_price' === $calculate_discount_from ) {
			$original_price = (float) get_post_meta( $product_id, '_sale_price', true );
		} else {
			$original_price = (float) get_post_meta( $product_id, '_regular_price', true );
		}
		return (float) $original_price;
	}

	public static function product_fixed_price_apply_discount_pro_by_currency( $price_fixed, $product, $apply_currency ) {
		if ( FixedPriceHelper::is_set_fixed_price() ) {
			$custom_fixed_prices = get_post_meta( $product->get_id(), 'yay_currency_custom_fixed_prices', true );
			$currency_code       = isset( $apply_currency['currency'] ) ? $apply_currency['currency'] : '';
			if ( ! empty( $custom_fixed_prices ) && isset( $custom_fixed_prices[ $currency_code ] ) && $custom_fixed_prices[ $currency_code ] ) {
				$calculate_discount_from = self::calculate_discount_from();
				$regular_price           = Helper::get_value_variable( $custom_fixed_prices[ $currency_code ]['regular_price'], $price_fixed );
				if ( 'sale_price' === $calculate_discount_from ) {
					$price_fixed = Helper::get_value_variable( $custom_fixed_prices[ $currency_code ]['sale_price'], $regular_price );
				} else {
					$price_fixed = $regular_price;
				}
			}
		}
		return (float) $price_fixed;
	}

	public static function calculate_subtotal_apply_discount( $price, $discount_amount, $products_ids, $apply_currency ) {
		$subtotal = apply_filters( 'yay_currency_discount_rules_get_cart_subtotal_apply_coupon_as_cart_rule', $price, $discount_amount, $products_ids, $apply_currency );
		return $subtotal;
	}

	// Get Original Price by Cart Item
	public static function get_product_price_by_cart_item( $cart_item, $apply_currency ) {
		$product_id    = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
		$product_price = self::get_product_price( $product_id, $apply_currency );
		$product_price = apply_filters( 'yay_currency_get_product_price_by_cart_item', $product_price, $cart_item, $apply_currency );
		$price_options = apply_filters( 'yay_currency_get_price_options_by_cart_item', 0, $cart_item, $product_id, $product_price, $apply_currency );
		return $price_options ? $product_price + $price_options : $product_price;
	}

	public static function get_cart_subtotal( $apply_currency = false ) {
		$subtotal      = 0;
		$cart_contents = WC()->cart->get_cart_contents();
		foreach ( $cart_contents  as $cart_item ) {
			$product_price    = self::get_product_price_by_cart_item( $cart_item, $apply_currency );
			$product_price    = apply_filters( 'yay_currency_get_product_price_apply_currency', $product_price, $cart_item['data'], 1 );
			$product_subtotal = $product_price * $cart_item['quantity'];
			$subtotal         = $subtotal + $product_subtotal;
		}

		return $subtotal;
	}

	// RELATE FIXED SIGNUP FEE
	public static function is_fixed_sing_up_fee_price( $product, $apply_currency ) {
		$signup_fee_price = false;
		if ( ! FixedPriceHelper::is_set_fixed_price() || Helper::default_currency_code() === $apply_currency['currency'] ) {
			return $signup_fee_price;
		}

		$product_id          = $product->get_id();
		$custom_fixed_prices = get_post_meta( $product_id, 'yay_currency_custom_fixed_sign_up_fee_prices', true );
		if ( ! empty( $custom_fixed_prices ) && isset( $custom_fixed_prices[ $apply_currency['currency'] ] ) ) {
			$signup_fee_price = ! empty( $custom_fixed_prices[ $apply_currency['currency'] ]['signup_fee_price'] ) ? (float) $custom_fixed_prices[ $apply_currency['currency'] ]['signup_fee_price'] : $signup_fee_price;
		}

		return $signup_fee_price;
	}

	public static function get_fixed_signup_fee_price_by_currency( $product, $signup_fee_price, $apply_currency ) {
		$fixed_signup_fee_price = self::is_fixed_sing_up_fee_price( $product, $apply_currency );
		return $fixed_signup_fee_price ? $fixed_signup_fee_price : $signup_fee_price;
	}

	// DISABLE : Checkout in different currency option

	public static function get_product_price_default_by_cart_item( $cart_item ) {
		$product_id    = $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
		$product_price = self::get_product_price( $product_id );
		$product_price = apply_filters( 'yay_currency_get_product_price_default_by_cart_item', $product_price, $cart_item );
		$price_options = apply_filters( 'yay_currency_get_price_options_default_by_cart_item', 0, $cart_item, $product_id, $product_price );
		return $price_options ? $product_price + $price_options : $product_price;
	}

	public static function get_cart_subtotal_default() {
		$subtotal      = 0;
		$cart_contents = WC()->cart->get_cart_contents();
		foreach ( $cart_contents  as $cart_item ) {
			$product_price    = self::get_product_price_default_by_cart_item( $cart_item );
			$product_subtotal = $product_price * $cart_item['quantity'];
			$subtotal         = $subtotal + $product_subtotal;
		}

		return $subtotal;
	}

	public static function get_total_coupons( $cart_subtotal = 0, $apply_currency = false ) {
		$total_coupon_applies = 0;
		if ( WC()->cart->applied_coupons ) {
			$applied_coupons = WC()->cart->applied_coupons;
			foreach ( $applied_coupons  as $coupon_code ) {
				$coupon          = new \WC_Coupon( $coupon_code );
				$discount_type   = $coupon->get_discount_type();
				$coupon_data     = $coupon->get_data();
				$discount_amount = (float) $coupon_data['amount'];

				if ( 'percent' !== $discount_type ) {

					if ( 'fixed_product' === $discount_type ) {
						$discount_amount *= self::get_product_quantity_item_qty( true );
					}

					if ( apply_filters( 'yay_currency_incl_tax_enable', false ) ) {
						$discount_totals     = WC()->cart->get_coupon_discount_totals();
						$discount_tax_totals = WC()->cart->get_coupon_discount_tax_totals();
						$discount_totals     = wc_array_merge_recursive_numeric( $discount_totals, $discount_tax_totals );
						$discount_amount     = $discount_totals[ $coupon->get_code() ];
					}

					if ( apply_filters( 'yay_currency_excl_tax_enable', false ) ) {
						$tax_rate_percent = apply_filters( 'yay_currency_get_rate_percent_in_cart', false );
						if ( $tax_rate_percent ) {
							$discount_amount = $discount_amount / ( 1 + $tax_rate_percent );
						}
					}

					if ( $apply_currency ) {
						$discount_amount = YayCurrencyHelper::calculate_price_by_currency( $discount_amount, true, $apply_currency );
					}

					$total_coupon_applies += $discount_amount;
				} else {
					$total_coupon_applies += ( $cart_subtotal * $discount_amount ) / 100;
				}
			}
		}
		return $total_coupon_applies;
	}

	public static function get_total_fees( $apply_currency, $calculate_include_total = false, $calculate_default = false ) {
		$total_fees = 0;
		foreach ( WC()->cart->get_fees() as $fee ) {
			if ( $fee->taxable || $calculate_include_total ) {
				$fee_amount = $fee->amount;
				if ( ! $calculate_default ) {
					$fee_amount = YayCurrencyHelper::calculate_price_by_currency( $fee_amount, true, $apply_currency );
				} else {
					$apply_currency = $apply_currency ? $apply_currency : YayCurrencyHelper::detect_current_currency();
					if ( Helper::default_currency_code() !== $apply_currency['currency'] ) {
						$fee_amount = $fee_amount / YayCurrencyHelper::get_rate_fee( $apply_currency );
					}
				}
				$fee_amount  = apply_filters( 'yay_currency_recalculate_fee_incl_tax', $fee_amount, $fee );
				$total_fees += $fee_amount;
			}
		}
		return $total_fees;
	}

	public static function get_total_tax( $apply_currency ) {
		$total_tax = 0;
		if ( 'yes' === get_option( 'woocommerce_calc_taxes' ) ) {
			$total_tax = self::get_cart_subtotal_by_fixed_include_tax( $apply_currency );
		}
		return $total_tax;
	}

	public static function get_total_tax_is_fallback( $apply_currency ) {
		$total_tax = 0;
		if ( 'yes' === get_option( 'woocommerce_calc_taxes' ) ) {
			$shipping_total = self::get_shipping_total_selected( $apply_currency, false, true, true );
			$taxes_in_cart  = TaxHelper::get_info_taxes_include_in_cart( $apply_currency, $shipping_total, false );
			$total_tax      = $taxes_in_cart ? $taxes_in_cart['total_tax'] : 0;
			if ( TaxHelper::is_apply_multiple_taxes() ) {
				$total_tax = TaxHelper::recalculate_excl_total_taxes_in_cart( $total_tax, $apply_currency );
			}
		}
		return $total_tax;
	}

	public static function get_cart_subtotal_by_fixed_include_tax( $apply_currency ) {
		$calculate_default = $apply_currency ? false : true;
		$shipping_total    = self::get_shipping_total_selected( $apply_currency, $calculate_default, true );
		$taxes_in_cart     = TaxHelper::get_info_taxes_include_in_cart( $apply_currency, $shipping_total, $calculate_default );
		$subtotal          = $taxes_in_cart ? $taxes_in_cart['total_tax'] : 0;
		if ( TaxHelper::is_apply_multiple_taxes() ) {
			$subtotal = TaxHelper::recalculate_excl_total_taxes_in_cart( $subtotal, $apply_currency );
		}
		return $subtotal;
	}

	public static function get_product_quantity_item_qty( $include_all_products = false ) {

		$total_quantity = 0;

		$cart_contents = WC()->cart->get_cart_contents();

		if ( $cart_contents ) {
			foreach ( $cart_contents as $cart_item ) {
				if ( $cart_item['quantity'] > 0 ) {
					$quantity        = ! $include_all_products ? ( $cart_item['data']->needs_shipping() ? $cart_item['quantity'] : 0 ) : $cart_item['quantity'];
					$total_quantity += $quantity;
				}
			}
		}

		return $total_quantity;
	}

	public static function get_shipping_flat_rate_fee_total_selected( $apply_currency = array(), $calculate_default = false, $calculate_tax = false, $is_fallback = false ) {
		$shipping = WC()->session->get( 'shipping_for_package_0' );
		if ( ! $shipping || ! isset( $shipping['rates'] ) ) {
			return false;
		}
		$shipping_fee = false;
		foreach ( $shipping['rates'] as $method_id => $method ) {
			if ( WC()->session->get( 'chosen_shipping_methods' )[0] == $method_id ) {
				if ( 'local_pickup' == $method->method_id ) {
					$shipping = new \WC_Shipping_Local_Pickup( $method->instance_id );
					if ( $calculate_tax && 'taxable' != $shipping->tax_status ) {
						$shipping_fee = -1;
						break;
					}
				}

				if ( 'flat_rate' == $method->method_id ) {

					$shipping = new \WC_Shipping_Flat_Rate( $method->instance_id );

					if ( $calculate_tax && 'taxable' != $shipping->tax_status ) {
						$shipping_fee = -1;
						break;
					}

					$cost = $shipping->get_option( 'cost' );

					if ( ! empty( $cost ) && ! is_numeric( $cost ) ) {
						if ( ! $calculate_default ) {
							$args         = array(
								'qty'  => self::get_product_quantity_item_qty(),
								'cost' => apply_filters( 'yay_currency_get_cart_subtotal', 0, $apply_currency ),
							);
							$str_replace  = $is_fallback ? '[yaycurrency-fee-fallback' : '[yaycurrency-fee';
							$cost         = str_replace( '[fee', $str_replace, $cost );
							$shipping_fee = self::evaluate_cost( $cost, $args );

						} else {
							$args         = array(
								'qty'  => self::get_product_quantity_item_qty(),
								'cost' => apply_filters( 'yay_currency_get_cart_subtotal_default', 0 ),
							);
							$shipping_fee = self::evaluate_cost( $cost, $args, true );
						}

						break;
					} else {
						$cost         = ! $calculate_default ? YayCurrencyHelper::calculate_price_by_currency( $cost, true, $apply_currency ) : $cost;
						$shipping_fee = apply_filters( 'yay_currency_recalculate_shipping_fee_incl_tax', $cost, $method, $apply_currency );
					}
				}
			}
		}

		return $shipping_fee;
	}

	public static function get_shipping_total_selected( $apply_currency, $calculate_default = false, $calculate_tax = false, $is_fallback = false ) {
		$shipping_total = WC()->cart->shipping_total;

		if ( ! $shipping_total ) {
			return 0;
		}

		if ( ! $calculate_default ) {
			$shipping_total = YayCurrencyHelper::calculate_price_by_currency( WC()->cart->shipping_total, true, $apply_currency );
		}

		$shipping_total = apply_filters( 'yay_currency_shipping_total_incl_tax', $shipping_total, $apply_currency );

		$shipping_flat_fee_total = self::get_shipping_flat_rate_fee_total_selected( $apply_currency, $calculate_default, $calculate_tax, $is_fallback );

		if ( $shipping_flat_fee_total ) {
			$shipping_total = -1 == $shipping_flat_fee_total ? 0 : $shipping_flat_fee_total;
		}

		return $shipping_total;

	}

	public static function evaluate_cost( $sum, $args = array(), $calculate_default = false, $is_fallback = false ) {
		// Add warning for subclasses.
		if ( ! is_array( $args ) || ! array_key_exists( 'qty', $args ) || ! array_key_exists( 'cost', $args ) ) {
			wc_doing_it_wrong( __FUNCTION__, '$args must contain `cost` and `qty` keys.', '4.0.1' );
		}

		include_once WC()->plugin_path() . '/includes/libraries/class-wc-eval-math.php';

		$locale   = localeconv();
		$decimals = array( wc_get_price_decimal_separator(), $locale['decimal_point'], $locale['mon_decimal_point'], ',' );
		if ( $calculate_default ) {
			$sum = str_replace( '[yaycurrency-fee', '[yaycurrency-fee-default', $sum );
			$sum = str_replace( '[fee', '[yaycurrency-fee-default', $sum );
		} else {
			$sum         = str_replace( '[yaycurrency-fee-default', '[yaycurrency-fee', $sum );
			$str_replace = $is_fallback ? '[yaycurrency-fee-fallback' : '[yaycurrency-fee';
			$sum         = str_replace( '[fee', $str_replace, $sum );
		}

		$sum = do_shortcode(
			str_replace(
				array(
					'[qty]',
					'[cost]',
				),
				array(
					$args['qty'],
					$args['cost'],
				),
				$sum
			)
		);

		// Remove whitespace from string.
		$sum = preg_replace( '/\s+/', '', $sum );

		// Remove locale from string.
		$sum = str_replace( $decimals, '.', $sum );

		// Trim invalid start/end characters.
		$sum = rtrim( ltrim( $sum, "\t\n\r\0\x0B+*/" ), "\t\n\r\0\x0B+-*/" );

		// Do the math.
		return $sum ? \WC_Eval_Math::evaluate( $sum ) : 0;
	}

	public static function get_cart_total( $apply_currency, $is_fallback = false ) {
		if ( $apply_currency ) {
			$calculate_default = false;
			$cart_subtotal     = apply_filters( 'yay_currency_get_cart_subtotal', 0, $apply_currency );
		} else {
			$calculate_default = true;
			$cart_subtotal     = apply_filters( 'yay_currency_get_cart_subtotal_default', 0 );
		}
		$shipping_total       = self::get_shipping_total_selected( $apply_currency, $calculate_default, false, $is_fallback );
		$total_coupon_applies = self::get_total_coupons( $cart_subtotal, $apply_currency );
		$total_fees           = self::get_total_fees( $apply_currency, true, $calculate_default );
		$total_tax            = 0;

		if ( apply_filters( 'yay_currency_is_recalculate_tax', false ) ) {
			$total_tax = ! $is_fallback ? self::get_total_tax( $apply_currency ) : self::get_total_tax_is_fallback( $apply_currency );
		}

		$total = ( $cart_subtotal - $total_coupon_applies ) + $total_tax + $shipping_total + $total_fees;
		return $total;
	}

	// CHECKOUT CART TOTAL RECALCULATE
	public static function recalculate_shipping_total( $apply_currency, $shipping_total ) {
		if ( WC()->cart->get_taxes() ) {
			$rateId        = key( WC()->cart->get_taxes() );
			$taxes_in_cart = TaxHelper::get_info_taxes_include_in_cart( $apply_currency, $shipping_total );
			if ( in_array( $rateId, array_keys( $taxes_in_cart['taxes'] ), true ) ) {
				$is_virtual = isset( $taxes_in_cart['taxes'][ $rateId ]['is_virtual'] ) ? $taxes_in_cart['taxes'][ $rateId ]['is_virtual'] : false;
				if ( $is_virtual ) {
					$shipping_total = 0;
				}
			}
		}
		return $shipping_total;
	}

	public static function recalculate_checkout_cart_total( $apply_currency ) {
		$cart_subtotal        = apply_filters( 'yay_currency_get_cart_subtotal', 0, $apply_currency );
		$shipping_total       = apply_filters( 'yay_currency_get_shipping_total', 0, $apply_currency, false );
		$total_tax_fees       = self::get_total_fees( $apply_currency, true );
		$total_coupon_applies = apply_filters( 'yay_currency_get_discount_total', 0, $apply_currency );
		$total_tax            = 0;

		if ( apply_filters( 'yay_currency_is_recalculate_tax', false ) ) {
			$total_tax = TaxHelper::get_cart_subtotal_by_fixed_include_tax( $apply_currency );
			if ( apply_filters( 'yay_currency_excl_tax_enable', false ) ) {
				if ( apply_filters( 'yay_currency_is_more_one_tax_apply_in_cart', false ) ) {
					$total_tax = apply_filters( 'yay_currency_recalculate_excl_total_taxes_in_cart', $total_tax, $apply_currency );
				} else {
					$total_tax = apply_filters( 'yay_currency_recalculate_total_tax', $total_tax, $apply_currency );
				}
			}
			$shipping_total = self::recalculate_shipping_total( $apply_currency, $shipping_total );
		}

		$cart_total = ( $cart_subtotal - $total_coupon_applies ) + $total_tax + $shipping_total + $total_tax_fees;
		return $cart_total;
	}
	// CALCULATE PRODUCT INFO
	public static function get_product_subtotal_info( $product, $quantity = 1, $apply_currency = array() ) {
		$product_price    = self::get_product_price( $product->get_id(), $apply_currency );
		$product_subtotal = $product_price * $quantity;
		$data             = array(
			'subtotal'     => $product_subtotal,
			'subtotal_tax' => 0,
		);

		if ( 'yes' === get_option( 'woocommerce_calc_taxes' ) ) {
			if ( 'taxable' === $product->get_tax_status() ) {
				$rateId               = key( \WC_Tax::get_rates( $product->get_tax_class() ) );
				$tax_rate_percent     = \WC_Tax::get_rate_percent_value( $rateId );
				$data['subtotal_tax'] = $product_subtotal * $tax_rate_percent / 100;
			}
		}
		return $data;
	}
}
